package com.noura.carwash.pos;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.RemoteException;

import com.sunmi.peripheral.printer.InnerPrinterCallback;
import com.sunmi.peripheral.printer.InnerPrinterException;
import com.sunmi.peripheral.printer.InnerPrinterManager;
import com.sunmi.peripheral.printer.SunmiPrinterService;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SunmiPrinterBridge {
    private SunmiPrinterService service;
    private final Context context;
    private boolean connected = false;

    public SunmiPrinterBridge(Context context) { this.context = context.getApplicationContext(); }

    private final InnerPrinterCallback callback = new InnerPrinterCallback() {
        @Override protected void onConnected(SunmiPrinterService s) {
            service = s;
            connected = true;
        }
        @Override protected void onDisconnected() {
            service = null;
            connected = false;
        }
    };

    public void connect() {
        try { InnerPrinterManager.getInstance().bindService(context, callback); }
        catch (InnerPrinterException ignored) { connected = false; }
    }

    public void disconnect() {
        try { InnerPrinterManager.getInstance().unBindService(context, callback); }
        catch (InnerPrinterException ignored) { }
    }

    public boolean isConnected() { return connected && service != null; }

    public boolean printReceipt(DBHelper.Sale sale) {
        if (!isConnected() || sale == null) return false;
        try {
            Bitmap receipt = buildReceiptBitmap(sale);
            service.printBitmap(receipt, null);
            service.lineWrap(4, null);
            return true;
        } catch (RemoteException e) {
            return false;
        }
    }

    private Bitmap buildReceiptBitmap(DBHelper.Sale sale) {
        final int width = 384;
        int rows = 14 + (sale.items == null ? 0 : sale.items.size());
        int height = Math.max(560, rows * 34 + 120);
        Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        c.drawColor(Color.WHITE);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.BLACK);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        p.setTextAlign(Paint.Align.CENTER);
        int y = 38;
        p.setTextSize(28); p.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("مغسلة نورة", width/2f, y, p); y += 32;
        p.setTextSize(19); c.drawText("NOURA CAR WASH", width/2f, y, p); y += 28;
        p.setStrokeWidth(2); c.drawLine(14,y,width-14,y,p); y += 28;
        p.setTextSize(18); p.setTypeface(Typeface.DEFAULT);
        c.drawText("Invoice #" + sale.id, width/2f, y, p); y += 28;
        c.drawText(new SimpleDateFormat("yyyy-MM-dd  HH:mm", Locale.US).format(new Date(sale.createdAt)), width/2f, y, p); y += 30;
        p.setTextAlign(Paint.Align.LEFT);
        c.drawText("Plate / اللوحة: " + sale.plate, 18, y, p); y += 28;
        c.drawText("Worker / العامل: " + sale.workerName, 18, y, p); y += 28;
        c.drawText("Car / السيارة: " + sale.carSize + "   " + money(sale.basePrice), 18, y, p); y += 28;
        if (sale.items != null) {
            for (DBHelper.Product item : sale.items) {
                c.drawText(item.nameEn + " / " + item.nameAr + "   " + money(item.price), 18, y, p); y += 28;
            }
        }
        c.drawLine(14,y,width-14,y,p); y += 30;
        if (sale.discountAmount > 0) {
            p.setTypeface(Typeface.DEFAULT); p.setTextSize(18);
            c.drawText("SUBTOTAL / قبل الخصم: " + money(sale.subtotal), 18, y, p); y += 28;
            String discountLabel = "percent".equals(sale.discountType)
                    ? String.format(Locale.US, "%.0f%%", sale.discountValue)
                    : money(sale.discountValue);
            c.drawText("DISCOUNT / الخصم: " + discountLabel + "  (-" + money(sale.discountAmount) + ")", 18, y, p); y += 30;
        }
        p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(23);
        c.drawText("TOTAL / الإجمالي: " + money(sale.total), 18, y, p); y += 34;
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(17);
        c.drawText("Payment / الدفع: " + sale.paymentMethod, 18, y, p); y += 34;
        p.setTextAlign(Paint.Align.CENTER);
        c.drawText("شكراً لزيارتكم - Thank you", width/2f, y, p);
        return bmp;
    }

    private String money(double v) { return String.format(Locale.US, "%.2f SAR", v); }
}
