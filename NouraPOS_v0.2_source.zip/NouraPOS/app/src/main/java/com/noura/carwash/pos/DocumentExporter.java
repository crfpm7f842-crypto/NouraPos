package com.noura.carwash.pos;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;

import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DocumentExporter {
    private static final String AUTHORITY = "com.noura.carwash.pos.fileprovider";


    @SuppressWarnings("deprecation")
    private static File outputDirectory(Context context, String type) {
        File base = null;
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            base = Environment.getExternalStoragePublicDirectory(type);
        }
        if (base == null) base = context.getExternalFilesDir(type);
        if (base == null) base = context.getFilesDir();
        File dir = new File(base, "NouraPOS");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    public static Bitmap buildReceiptBitmap(DBHelper.Sale sale) {
        final int width = 720;
        int rows = 18 + (sale.items == null ? 0 : sale.items.size());
        int height = Math.max(980, rows * 54 + 160);
        Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        c.drawColor(Color.WHITE);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.BLACK);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        p.setTextAlign(Paint.Align.CENTER);
        int y = 62;
        p.setTextSize(42); p.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("مغسلة نوره", width/2f, y, p); y += 48;
        p.setTextSize(28); c.drawText("NOURA CAR WASH", width/2f, y, p); y += 42;
        if (sale.refunded) {
            p.setColor(Color.DKGRAY); p.setTextSize(34);
            c.drawText("مرتجع  •  REFUNDED", width/2f, y, p); y += 46;
            p.setColor(Color.BLACK);
        }
        p.setStrokeWidth(2); c.drawLine(24,y,width-24,y,p); y += 42;
        p.setTextSize(26); p.setTypeface(Typeface.DEFAULT);
        c.drawText("Invoice #" + sale.id, width/2f, y, p); y += 38;
        c.drawText(new SimpleDateFormat("yyyy-MM-dd  HH:mm", Locale.US).format(new Date(sale.createdAt)), width/2f, y, p); y += 44;
        p.setTextAlign(Paint.Align.LEFT);
        c.drawText("Plate / اللوحة: " + sale.plate, 32, y, p); y += 40;
        c.drawText("Worker / العامل: " + sale.workerName, 32, y, p); y += 40;
        c.drawText("Car / السيارة: " + sale.carSize + "   " + money(sale.basePrice), 32, y, p); y += 40;
        if (sale.items != null) {
            for (DBHelper.Product item : sale.items) {
                c.drawText("• " + item.nameEn + " / " + item.nameAr + "   " + money(item.price), 32, y, p); y += 40;
            }
        }
        c.drawLine(24,y,width-24,y,p); y += 44;
        if (sale.discountAmount > 0) {
            c.drawText("SUBTOTAL / قبل الخصم: " + money(sale.subtotal), 32, y, p); y += 40;
            String discountLabel = "percent".equals(sale.discountType)
                    ? String.format(Locale.US, "%.0f%%", sale.discountValue)
                    : money(sale.discountValue);
            c.drawText("DISCOUNT / الخصم: " + discountLabel + "  (-" + money(sale.discountAmount) + ")", 32, y, p); y += 42;
        }
        p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(34);
        c.drawText("TOTAL / الإجمالي: " + money(sale.total), 32, y, p); y += 48;
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(25);
        c.drawText("Payment / الدفع: " + sale.paymentMethod, 32, y, p); y += 42;
        if (sale.refunded) {
            c.drawText("Refunded / وقت المرتجع: " + new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date(sale.refundedAt)), 32, y, p); y += 38;
            if (sale.refundReason != null && !sale.refundReason.trim().isEmpty()) {
                c.drawText("Reason / السبب: " + sale.refundReason, 32, y, p); y += 38;
            }
        }
        p.setTextAlign(Paint.Align.CENTER);
        c.drawText("شكراً لزيارتكم - Thank you", width/2f, y + 10, p);
        return bmp;
    }

    public static File saveReceiptImage(Context context, DBHelper.Sale sale) throws IOException {
        File dir = outputDirectory(context, Environment.DIRECTORY_PICTURES);
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Could not create receipt directory");
        File file = new File(dir, "Noura_Invoice_" + sale.id + ".png");
        Bitmap bmp = buildReceiptBitmap(sale);
        try (FileOutputStream out = new FileOutputStream(file)) {
            if (!bmp.compress(Bitmap.CompressFormat.PNG, 100, out)) throw new IOException("Could not save image");
        }
        bmp.recycle();
        return file;
    }

    public static File createReportPdf(Context context, DBHelper db, long start, long end, String title, boolean arabic) throws IOException {
        File dir = outputDirectory(context, Environment.DIRECTORY_DOCUMENTS);
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Could not create report directory");
        String stamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date());
        File file = new File(dir, "Noura_Report_" + stamp + ".pdf");

        DBHelper.DailySummary summary = db.getSummary(start, end);
        List<DBHelper.WorkerCount> workers = summary.workerCounts;
        List<DBHelper.DaySummary> days = db.getDailyBreakdown(start, end);

        PdfDocument doc = new PdfDocument();
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int pageNo = 1;
        PdfDocument.Page page = newPage(doc, pageNo);
        Canvas canvas = page.getCanvas();
        int y = drawReportHeader(canvas, p, title, start, end, summary, arabic);

        y = drawSectionTitle(canvas, p, y, arabic ? "أداء العمال" : "Worker performance");
        for (DBHelper.WorkerCount w : workers) {
            if (y > 790) { doc.finishPage(page); pageNo++; page = newPage(doc,pageNo); canvas=page.getCanvas(); y=50; }
            p.setTypeface(Typeface.DEFAULT); p.setTextSize(11); p.setTextAlign(Paint.Align.LEFT); p.setColor(Color.DKGRAY);
            String row = w.name + "   |   " + (arabic ? "الغسلات: " : "Washes: ") + w.count;
            if (w.refundCount > 0) row += "   |   " + (arabic ? "مرتجع: " : "Refunded: ") + w.refundCount;
            canvas.drawText(row, 42, y, p); y += 22;
        }
        if (workers.isEmpty()) { p.setTextSize(11); canvas.drawText(arabic?"لا توجد عمليات":"No sales",42,y,p); y+=22; }

        y = drawSectionTitle(canvas, p, y + 6, arabic ? "الأيام" : "Daily breakdown");
        SimpleDateFormat dayFmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        for (DBHelper.DaySummary day : days) {
            if (y > 790) { doc.finishPage(page); pageNo++; page = newPage(doc,pageNo); canvas=page.getCanvas(); y=50; }
            DBHelper.DailySummary d = day.summary;
            p.setTypeface(Typeface.DEFAULT); p.setTextSize(10); p.setTextAlign(Paint.Align.LEFT); p.setColor(Color.DKGRAY);
            String row = dayFmt.format(new Date(day.dayStart)) + "   |   " +
                    (arabic?"سيارات ":"Cars ") + d.cars + "   |   " +
                    (arabic?"إجمالي ":"Gross ") + money(d.grossSales) + "   |   " +
                    (arabic?"مرتجع ":"Refunds ") + money(d.refunds) + "   |   " +
                    (arabic?"صافي ":"Net ") + money(d.sales);
            canvas.drawText(row, 42, y, p); y += 20;
        }

        doc.finishPage(page);
        try (FileOutputStream out = new FileOutputStream(file)) { doc.writeTo(out); }
        doc.close();
        return file;
    }

    private static PdfDocument.Page newPage(PdfDocument doc, int pageNo) {
        PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(595, 842, pageNo).create();
        PdfDocument.Page page = doc.startPage(info);
        page.getCanvas().drawColor(Color.WHITE);
        return page;
    }

    private static int drawReportHeader(Canvas c, Paint p, String title, long start, long end, DBHelper.DailySummary s, boolean arabic) {
        p.setTextAlign(Paint.Align.CENTER); p.setColor(Color.BLACK); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(22);
        c.drawText("NOURA CAR WASH", 297, 48, p);
        p.setTextSize(15); c.drawText(title, 297, 73, p);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(10);
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        c.drawText(f.format(new Date(start)) + "  →  " + f.format(new Date(Math.max(start, end - 1))), 297, 92, p);
        p.setTextAlign(Paint.Align.LEFT); p.setTextSize(12); p.setTypeface(Typeface.DEFAULT_BOLD);
        int y = 124;
        c.drawText((arabic?"إجمالي المبيعات قبل المرتجع: ":"Gross sales: ") + money(s.grossSales), 42, y, p); y += 24;
        c.drawText((arabic?"المرتجعات: ":"Refunds: ") + money(s.refunds), 42, y, p); y += 24;
        c.drawText((arabic?"صافي المبيعات: ":"Net sales: ") + money(s.sales), 42, y, p); y += 24;
        c.drawText((arabic?"عدد السيارات المغسولة: ":"Cars washed: ") + s.cars, 42, y, p); y += 24;
        String topAddon = arabic ? s.topAddOnAr : s.topAddOnEn;
        c.drawText((arabic?"أكثر إضافة طلباً: ":"Top add-on: ") + (topAddon == null || topAddon.isEmpty() ? "-" : topAddon + " × " + s.topAddOnCount), 42, y, p); y += 24;
        c.drawText((arabic?"أكثر حجم سيارة: ":"Top car size: ") + (s.topCarSize == null || s.topCarSize.isEmpty() ? "-" : s.topCarSize + " × " + s.topCarSizeCount), 42, y, p); y += 22;
        return y;
    }

    private static int drawSectionTitle(Canvas c, Paint p, int y, String title) {
        p.setTextAlign(Paint.Align.LEFT); p.setColor(Color.BLACK); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(13);
        c.drawText(title, 42, y, p);
        c.drawLine(42, y + 5, 553, y + 5, p);
        return y + 24;
    }

    public static void shareFile(Context context, File file, String mimeType, String chooserTitle) {
        Uri uri = FileProvider.getUriForFile(context, AUTHORITY, file);
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType(mimeType);
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        context.startActivity(Intent.createChooser(i, chooserTitle));
    }

    public static void printPdf(Activity activity, File file, String jobName) {
        PrintManager manager = (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
        if (manager == null) return;
        PrintAttributes attrs = new PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                .build();
        manager.print(jobName, new PdfFileAdapter(file), attrs);
    }

    private static class PdfFileAdapter extends PrintDocumentAdapter {
        private final File file;
        PdfFileAdapter(File file){ this.file=file; }

        @Override public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                                       CancellationSignal cancellationSignal, LayoutResultCallback callback, android.os.Bundle extras) {
            if (cancellationSignal.isCanceled()) { callback.onLayoutCancelled(); return; }
            PrintDocumentInfo info = new PrintDocumentInfo.Builder(file.getName())
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN).build();
            callback.onLayoutFinished(info, true);
        }

        @Override public void onWrite(PageRange[] pages, ParcelFileDescriptor destination,
                                      CancellationSignal cancellationSignal, WriteResultCallback callback) {
            try (FileInputStream in = new FileInputStream(file); FileOutputStream out = new FileOutputStream(destination.getFileDescriptor())) {
                byte[] buffer = new byte[8192];
                int n;
                while ((n=in.read(buffer)) >= 0) {
                    if (cancellationSignal.isCanceled()) { callback.onWriteCancelled(); return; }
                    out.write(buffer,0,n);
                }
                callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
            } catch (IOException e) { callback.onWriteFailed(e.getMessage()); }
        }
    }

    private static String money(double v) { return String.format(Locale.US, "%.2f SAR", v); }
}
