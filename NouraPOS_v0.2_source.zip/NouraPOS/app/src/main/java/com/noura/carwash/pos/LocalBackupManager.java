package com.noura.carwash.pos;

import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;

public class LocalBackupManager {
    public static void backup(Context context, DBHelper db) {
        try {
            File dir = new File(context.getFilesDir(), "backups");
            if (!dir.exists()) dir.mkdirs();
            String date = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date());
            File file = new File(dir, "noura-backup-" + date + ".json");
            try (FileOutputStream out = new FileOutputStream(file)) {
                out.write(db.exportAllJson().getBytes(StandardCharsets.UTF_8));
            }
            File[] files = dir.listFiles();
            if (files != null && files.length > 30) {
                Arrays.sort(files, Comparator.comparingLong(File::lastModified));
                for (int i=0;i<files.length-30;i++) files[i].delete();
            }
        } catch (Exception ignored) { }
    }
}
