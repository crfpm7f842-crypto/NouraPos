package com.noura.carwash.pos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "noura_pos.db";
    private static final int DB_VERSION = 3;

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE employees (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1)");
        db.execSQL("CREATE TABLE products (id INTEGER PRIMARY KEY AUTOINCREMENT, name_ar TEXT NOT NULL, name_en TEXT NOT NULL, price REAL NOT NULL, active INTEGER NOT NULL DEFAULT 1)");
        db.execSQL("CREATE TABLE sales (id INTEGER PRIMARY KEY AUTOINCREMENT, created_at INTEGER NOT NULL, plate TEXT NOT NULL, phone TEXT, customer_leaving INTEGER NOT NULL DEFAULT 0, car_size TEXT NOT NULL, base_price REAL NOT NULL, subtotal REAL NOT NULL DEFAULT 0, discount_type TEXT NOT NULL DEFAULT 'none', discount_value REAL NOT NULL DEFAULT 0, discount_amount REAL NOT NULL DEFAULT 0, total REAL NOT NULL, worker_id INTEGER, worker_name TEXT NOT NULL, payment_method TEXT NOT NULL, refunded INTEGER NOT NULL DEFAULT 0, refunded_at INTEGER NOT NULL DEFAULT 0, refund_reason TEXT NOT NULL DEFAULT '')");
        db.execSQL("CREATE TABLE sale_items (id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL, product_id INTEGER, name_ar TEXT NOT NULL, name_en TEXT NOT NULL, price REAL NOT NULL)");
        db.execSQL("CREATE INDEX idx_sales_created_at ON sales(created_at)");
        db.execSQL("CREATE INDEX idx_sales_worker ON sales(worker_id, created_at)");
        db.execSQL("CREATE INDEX idx_sale_items_sale ON sale_items(sale_id)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE sales ADD COLUMN subtotal REAL NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE sales ADD COLUMN discount_type TEXT NOT NULL DEFAULT 'none'");
            db.execSQL("ALTER TABLE sales ADD COLUMN discount_value REAL NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE sales ADD COLUMN discount_amount REAL NOT NULL DEFAULT 0");
            db.execSQL("UPDATE sales SET subtotal=total WHERE subtotal=0");
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE sales ADD COLUMN refunded INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE sales ADD COLUMN refunded_at INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE sales ADD COLUMN refund_reason TEXT NOT NULL DEFAULT ''");
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_sales_created_at ON sales(created_at)");
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_sales_worker ON sales(worker_id, created_at)");
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_sale_items_sale ON sale_items(sale_id)");
        }
    }

    public long addEmployee(String name) {
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        return getWritableDatabase().insert("employees", null, v);
    }

    public void updateEmployee(long id, String name) {
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        getWritableDatabase().update("employees", v, "id=?", new String[]{String.valueOf(id)});
    }

    public void setEmployeeActive(long id, boolean active) {
        ContentValues v = new ContentValues();
        v.put("active", active ? 1 : 0);
        getWritableDatabase().update("employees", v, "id=?", new String[]{String.valueOf(id)});
    }

    public List<Employee> getEmployees(boolean onlyActive) {
        ArrayList<Employee> out = new ArrayList<>();
        Cursor c = getReadableDatabase().query("employees", null, onlyActive ? "active=1" : null, null, null, null, "name COLLATE NOCASE");
        while (c.moveToNext()) out.add(new Employee(c.getLong(c.getColumnIndexOrThrow("id")), c.getString(c.getColumnIndexOrThrow("name")), c.getInt(c.getColumnIndexOrThrow("active")) == 1));
        c.close();
        return out;
    }

    public long addProduct(String ar, String en, double price) {
        ContentValues v = new ContentValues();
        v.put("name_ar", ar.trim());
        v.put("name_en", en.trim());
        v.put("price", price);
        return getWritableDatabase().insert("products", null, v);
    }

    public void updateProduct(long id, String ar, String en, double price) {
        ContentValues v = new ContentValues();
        v.put("name_ar", ar.trim());
        v.put("name_en", en.trim());
        v.put("price", price);
        getWritableDatabase().update("products", v, "id=?", new String[]{String.valueOf(id)});
    }

    public void setProductActive(long id, boolean active) {
        ContentValues v = new ContentValues();
        v.put("active", active ? 1 : 0);
        getWritableDatabase().update("products", v, "id=?", new String[]{String.valueOf(id)});
    }

    public List<Product> getProducts(boolean onlyActive) {
        ArrayList<Product> out = new ArrayList<>();
        Cursor c = getReadableDatabase().query("products", null, onlyActive ? "active=1" : null, null, null, null, "id DESC");
        while (c.moveToNext()) out.add(new Product(
                c.getLong(c.getColumnIndexOrThrow("id")),
                c.getString(c.getColumnIndexOrThrow("name_ar")),
                c.getString(c.getColumnIndexOrThrow("name_en")),
                c.getDouble(c.getColumnIndexOrThrow("price")),
                c.getInt(c.getColumnIndexOrThrow("active")) == 1));
        c.close();
        return out;
    }

    public long createSale(String plate, String phone, boolean leaving, String carSize, double basePrice,
                           long workerId, String workerName, String paymentMethod, List<Product> items,
                           String discountType, double discountValue) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            double subtotal = basePrice;
            for (Product p : items) subtotal += p.price;
            String type = discountType == null ? "none" : discountType;
            double amount = 0;
            if ("percent".equals(type)) amount = subtotal * Math.max(0, Math.min(100, discountValue)) / 100.0;
            else if ("fixed".equals(type)) amount = Math.max(0, Math.min(subtotal, discountValue));
            else { type = "none"; discountValue = 0; }
            double total = Math.max(0, subtotal - amount);
            ContentValues v = new ContentValues();
            v.put("created_at", System.currentTimeMillis());
            v.put("plate", plate.trim().toUpperCase());
            v.put("phone", phone == null ? "" : phone.trim());
            v.put("customer_leaving", leaving ? 1 : 0);
            v.put("car_size", carSize);
            v.put("base_price", basePrice);
            v.put("subtotal", subtotal);
            v.put("discount_type", type);
            v.put("discount_value", discountValue);
            v.put("discount_amount", amount);
            v.put("total", total);
            v.put("worker_id", workerId);
            v.put("worker_name", workerName);
            v.put("payment_method", paymentMethod);
            long saleId = db.insertOrThrow("sales", null, v);
            for (Product p : items) {
                ContentValues i = new ContentValues();
                i.put("sale_id", saleId);
                i.put("product_id", p.id);
                i.put("name_ar", p.nameAr);
                i.put("name_en", p.nameEn);
                i.put("price", p.price);
                db.insertOrThrow("sale_items", null, i);
            }
            db.setTransactionSuccessful();
            return saleId;
        } finally {
            db.endTransaction();
        }
    }

    public Sale getSale(long id) {
        Cursor c = getReadableDatabase().query("sales", null, "id=?", new String[]{String.valueOf(id)}, null, null, null);
        Sale s = null;
        if (c.moveToFirst()) s = readSale(c);
        c.close();
        if (s != null) s.items = getSaleItems(id);
        return s;
    }

    public boolean refundSale(long id, String reason) {
        ContentValues v = new ContentValues();
        v.put("refunded", 1);
        v.put("refunded_at", System.currentTimeMillis());
        v.put("refund_reason", reason == null ? "" : reason.trim());
        return getWritableDatabase().update("sales", v, "id=? AND refunded=0", new String[]{String.valueOf(id)}) > 0;
    }

    public List<Product> getSaleItems(long saleId) {
        ArrayList<Product> out = new ArrayList<>();
        Cursor c = getReadableDatabase().query("sale_items", null, "sale_id=?", new String[]{String.valueOf(saleId)}, null, null, "id");
        while (c.moveToNext()) out.add(new Product(c.getLong(c.getColumnIndexOrThrow("product_id")), c.getString(c.getColumnIndexOrThrow("name_ar")), c.getString(c.getColumnIndexOrThrow("name_en")), c.getDouble(c.getColumnIndexOrThrow("price")), true));
        c.close();
        return out;
    }

    public List<Sale> searchSales(String query, int limit) {
        ArrayList<Sale> out = new ArrayList<>();
        String q = "%" + query.trim() + "%";
        Cursor c = getReadableDatabase().query("sales", null,
                "plate LIKE ? OR phone LIKE ? OR CAST(id AS TEXT) LIKE ?",
                new String[]{q, q, q}, null, null, "created_at DESC", String.valueOf(limit));
        while (c.moveToNext()) out.add(readSale(c));
        c.close();
        return out;
    }

    public List<Sale> getSalesInRange(long start, long end, int limit) {
        ArrayList<Sale> out = new ArrayList<>();
        Cursor c = getReadableDatabase().query("sales", null, "created_at>=? AND created_at<?",
                new String[]{String.valueOf(start), String.valueOf(end)}, null, null, "created_at DESC", limit > 0 ? String.valueOf(limit) : null);
        while (c.moveToNext()) out.add(readSale(c));
        c.close();
        return out;
    }

    public DailySummary getSummary(long start, long end) {
        DailySummary s = new DailySummary();
        String[] args = {String.valueOf(start), String.valueOf(end)};

        Cursor sales = getReadableDatabase().rawQuery(
                "SELECT COUNT(*), COALESCE(SUM(total),0) FROM sales WHERE created_at>=? AND created_at<?", args);
        if (sales.moveToFirst()) {
            s.totalCars = sales.getInt(0);
            s.cars = s.totalCars;
            s.grossSales = sales.getDouble(1);
        }
        sales.close();

        Cursor refunds = getReadableDatabase().rawQuery(
                "SELECT COUNT(*), COALESCE(SUM(total),0) FROM sales WHERE refunded=1 AND refunded_at>=? AND refunded_at<?", args);
        if (refunds.moveToFirst()) {
            s.refundedCars = refunds.getInt(0);
            s.refunds = refunds.getDouble(1);
        }
        refunds.close();
        s.sales = s.grossSales - s.refunds;

        Cursor w = getReadableDatabase().rawQuery(
                "SELECT COALESCE(e.name, x.worker_name) worker_display_name, " +
                        "SUM(CASE WHEN x.created_at>=? AND x.created_at<? THEN 1 ELSE 0 END) wash_count, " +
                        "SUM(CASE WHEN x.refunded=1 AND x.refunded_at>=? AND x.refunded_at<? THEN 1 ELSE 0 END) refund_count " +
                        "FROM sales x LEFT JOIN employees e ON e.id=x.worker_id " +
                        "WHERE (x.created_at>=? AND x.created_at<?) OR (x.refunded=1 AND x.refunded_at>=? AND x.refunded_at<?) " +
                        "GROUP BY x.worker_id, worker_display_name ORDER BY wash_count DESC, worker_display_name COLLATE NOCASE",
                new String[]{String.valueOf(start),String.valueOf(end),String.valueOf(start),String.valueOf(end),
                        String.valueOf(start),String.valueOf(end),String.valueOf(start),String.valueOf(end)});
        while (w.moveToNext()) {
            int washes = w.getInt(1);
            int refundCount = w.getInt(2);
            s.workerCounts.add(new WorkerCount(w.getString(0), washes, refundCount, washes));
        }
        w.close();

        Cursor addon = getReadableDatabase().rawQuery(
                "SELECT si.name_ar, si.name_en, COUNT(*) c FROM sale_items si " +
                        "JOIN sales x ON x.id=si.sale_id " +
                        "WHERE x.created_at>=? AND x.created_at<? " +
                        "GROUP BY si.name_ar, si.name_en ORDER BY c DESC, si.name_en LIMIT 1", args);
        if (addon.moveToFirst()) {
            s.topAddOnAr = addon.getString(0);
            s.topAddOnEn = addon.getString(1);
            s.topAddOnCount = addon.getInt(2);
        }
        addon.close();

        Cursor car = getReadableDatabase().rawQuery(
                "SELECT car_size, COUNT(*) c FROM sales WHERE created_at>=? AND created_at<? " +
                        "GROUP BY car_size ORDER BY c DESC, car_size LIMIT 1", args);
        if (car.moveToFirst()) {
            s.topCarSize = car.getString(0);
            s.topCarSizeCount = car.getInt(1);
        }
        car.close();
        return s;
    }

    public List<DaySummary> getDailyBreakdown(long start, long end) {
        ArrayList<DaySummary> out = new ArrayList<>();
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(start);
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        while (c.getTimeInMillis() < end) {
            long dayStart = c.getTimeInMillis();
            c.add(Calendar.DATE, 1);
            long dayEnd = Math.min(c.getTimeInMillis(), end);
            DailySummary summary = getSummary(Math.max(dayStart, start), dayEnd);
            if (summary.totalCars > 0 || dayStart >= start) out.add(new DaySummary(dayStart, summary));
        }
        return out;
    }

    public String exportAllJson() throws Exception {
        JSONObject root = new JSONObject();
        root.put("version", 2);
        root.put("exported_at", System.currentTimeMillis());
        root.put("employees", tableToJson("SELECT * FROM employees ORDER BY id"));
        root.put("products", tableToJson("SELECT * FROM products ORDER BY id"));
        root.put("sales", tableToJson("SELECT * FROM sales ORDER BY id"));
        root.put("sale_items", tableToJson("SELECT * FROM sale_items ORDER BY id"));
        return root.toString(2);
    }

    private JSONArray tableToJson(String sql) throws Exception {
        JSONArray arr = new JSONArray();
        Cursor c = getReadableDatabase().rawQuery(sql, null);
        String[] cols = c.getColumnNames();
        while (c.moveToNext()) {
            JSONObject row = new JSONObject();
            for (int i=0;i<cols.length;i++) {
                int type = c.getType(i);
                if (type == Cursor.FIELD_TYPE_INTEGER) row.put(cols[i], c.getLong(i));
                else if (type == Cursor.FIELD_TYPE_FLOAT) row.put(cols[i], c.getDouble(i));
                else if (type == Cursor.FIELD_TYPE_NULL) row.put(cols[i], JSONObject.NULL);
                else row.put(cols[i], c.getString(i));
            }
            arr.put(row);
        }
        c.close();
        return arr;
    }

    private Sale readSale(Cursor c) {
        Sale s = new Sale();
        s.id = c.getLong(c.getColumnIndexOrThrow("id"));
        s.createdAt = c.getLong(c.getColumnIndexOrThrow("created_at"));
        s.plate = c.getString(c.getColumnIndexOrThrow("plate"));
        s.phone = c.getString(c.getColumnIndexOrThrow("phone"));
        s.leaving = c.getInt(c.getColumnIndexOrThrow("customer_leaving")) == 1;
        s.carSize = c.getString(c.getColumnIndexOrThrow("car_size"));
        s.basePrice = c.getDouble(c.getColumnIndexOrThrow("base_price"));
        int subtotalIndex = c.getColumnIndex("subtotal");
        s.subtotal = subtotalIndex >= 0 ? c.getDouble(subtotalIndex) : s.basePrice;
        int discountTypeIndex = c.getColumnIndex("discount_type");
        s.discountType = discountTypeIndex >= 0 ? c.getString(discountTypeIndex) : "none";
        int discountValueIndex = c.getColumnIndex("discount_value");
        s.discountValue = discountValueIndex >= 0 ? c.getDouble(discountValueIndex) : 0;
        int discountAmountIndex = c.getColumnIndex("discount_amount");
        s.discountAmount = discountAmountIndex >= 0 ? c.getDouble(discountAmountIndex) : 0;
        s.total = c.getDouble(c.getColumnIndexOrThrow("total"));
        s.workerId = c.getLong(c.getColumnIndexOrThrow("worker_id"));
        s.workerName = c.getString(c.getColumnIndexOrThrow("worker_name"));
        s.paymentMethod = c.getString(c.getColumnIndexOrThrow("payment_method"));
        int refundedIndex = c.getColumnIndex("refunded");
        s.refunded = refundedIndex >= 0 && c.getInt(refundedIndex) == 1;
        int refundedAtIndex = c.getColumnIndex("refunded_at");
        s.refundedAt = refundedAtIndex >= 0 ? c.getLong(refundedAtIndex) : 0;
        int refundReasonIndex = c.getColumnIndex("refund_reason");
        s.refundReason = refundReasonIndex >= 0 ? c.getString(refundReasonIndex) : "";
        return s;
    }

    public static long startOfToday() { return startOfDay(System.currentTimeMillis()); }

    public static long startOfTomorrow() {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(startOfToday());
        c.add(Calendar.DATE, 1);
        return c.getTimeInMillis();
    }

    public static long startOfDay(long time) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(time);
        c.set(Calendar.HOUR_OF_DAY,0); c.set(Calendar.MINUTE,0); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0);
        return c.getTimeInMillis();
    }

    public static long startOfMonth() { return startOfMonth(System.currentTimeMillis()); }

    public static long startOfMonth(long time) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(time);
        c.set(Calendar.DAY_OF_MONTH,1); c.set(Calendar.HOUR_OF_DAY,0); c.set(Calendar.MINUTE,0); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0);
        return c.getTimeInMillis();
    }

    public static long startOfNextMonth() { return startOfNextMonth(System.currentTimeMillis()); }

    public static long startOfNextMonth(long time) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(startOfMonth(time));
        c.add(Calendar.MONTH,1);
        return c.getTimeInMillis();
    }

    public static class Employee {
        public long id; public String name; public boolean active;
        public Employee(long id, String name, boolean active){this.id=id;this.name=name;this.active=active;}
        @Override public String toString(){return name;}
    }
    public static class Product {
        public long id; public String nameAr,nameEn; public double price; public boolean active;
        public Product(long id,String ar,String en,double price,boolean active){this.id=id;nameAr=ar;nameEn=en;this.price=price;this.active=active;}
    }
    public static class Sale {
        public long id,createdAt,workerId,refundedAt;
        public String plate,phone,carSize,workerName,paymentMethod,discountType,refundReason;
        public boolean leaving,refunded;
        public double basePrice,subtotal,discountValue,discountAmount,total;
        public List<Product> items = new ArrayList<>();
    }
    public static class WorkerCount {
        public String name; public int count,refundCount,totalCount;
        public WorkerCount(String n,int c){this(n,c,0,c);}
        public WorkerCount(String n,int c,int r,int total){name=n;count=c;refundCount=r;totalCount=total;}
    }
    public static class DailySummary {
        public int cars,totalCars,refundedCars;
        public double sales,grossSales,refunds;
        public String topAddOnAr="",topAddOnEn="",topCarSize="";
        public int topAddOnCount,topCarSizeCount;
        public List<WorkerCount> workerCounts = new ArrayList<>();
    }
    public static class DaySummary {
        public long dayStart; public DailySummary summary;
        public DaySummary(long dayStart, DailySummary summary){this.dayStart=dayStart;this.summary=summary;}
    }
}
