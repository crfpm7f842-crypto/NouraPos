package com.noura.carwash.pos;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Switch;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int RED = Color.rgb(236,34,36);
    private static final int GRAY = Color.rgb(51,51,51);
    private static final int SMOKE = Color.rgb(242,242,242);

    private DBHelper db;
    private SharedPreferences prefs;
    private SunmiPrinterBridge printer;
    private boolean arabic = true;
    private LinearLayout root;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new DBHelper(this);
        prefs = getSharedPreferences("noura_settings", MODE_PRIVATE);
        arabic = prefs.getBoolean("arabic", true);
        printer = new SunmiPrinterBridge(this);
        printer.connect();
        requestLegacyStoragePermissionIfNeeded();
        showHome();
    }


    private void requestLegacyStoragePermissionIfNeeded() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1001);
        }
    }

    @Override protected void onDestroy() {
        printer.disconnect();
        db.close();
        super.onDestroy();
    }

    private String t(String ar, String en) { return arabic ? ar : en; }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void baseScreen(boolean home) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        root.setPadding(dp(12), dp(10), dp(12), dp(12));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);

        if (!home) {
            Button back = smallButton("‹");
            back.setOnClickListener(v -> showHome());
            header.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        }

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.noura.carwash.pos.R.drawable.noura_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams lpLogo = new LinearLayout.LayoutParams(0, dp(66), 1);
        lpLogo.setMargins(dp(6),0,dp(6),0);
        header.addView(logo, lpLogo);

        Button lang = smallButton(arabic ? "EN" : "عربي");
        lang.setOnClickListener(v -> {
            arabic = !arabic;
            prefs.edit().putBoolean("arabic", arabic).apply();
            showHome();
        });
        header.addView(lang, new LinearLayout.LayoutParams(dp(68), dp(46)));
        root.addView(header);

        setContentView(root);
    }

    private ScrollView contentScroll() {
        ScrollView sv = new ScrollView(this);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1);
        root.addView(sv, p);
        return sv;
    }

    private LinearLayout stack(ScrollView sv) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(8), 0, dp(18));
        sv.addView(box, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return box;
    }

    private void showHome() {
        baseScreen(true);
        ScrollView sv = contentScroll();
        LinearLayout box = stack(sv);
        TextView title = heading(t("كاشير مغسلة نوره", "NOURA Car Wash POS"));
        box.addView(title);
        TextView sub = text(t("اختر العملية", "Choose an action"), 16, Color.DKGRAY);
        sub.setGravity(arabic ? Gravity.RIGHT : Gravity.LEFT);
        box.addView(sub);

        LinearLayout todayCard = summaryCard(t("غسيل السيارات اليوم", "Cars Washed Today"),
                String.valueOf(db.getTodayWashCount()), t("يتجدد العداد تلقائياً كل يوم", "Counter resets automatically every day"));
        box.addView(todayCard);

        Button order = menuButton("🚗  " + t("فاتورة جديدة", "New Order"));
        order.setOnClickListener(v -> showOrder()); box.addView(order);
        Button invoices = menuButton("🧾  " + t("عرض فواتير اليوم", "View Today's Invoices"));
        invoices.setOnClickListener(v -> showInvoices()); box.addView(invoices);
        Button reports = menuButton("📊  " + t("التقارير وترتيب العمال", "Reports & Worker Ranking"));
        reports.setOnClickListener(v -> showReports()); box.addView(reports);
        Button search = menuButton("🔎  " + t("البحث عن فاتورة", "Find an Invoice"));
        search.setOnClickListener(v -> showSearch()); box.addView(search);
        Button admin = menuButton("⚙  " + t("الإدارة", "Admin"));
        admin.setOnClickListener(v -> requestAdmin()); box.addView(admin);

        TextView printerState = text((printer.isConnected() ? "✓ " : "• ") + t(
                printer.isConnected() ? "طابعة SUNMI متصلة" : "سيتم الاتصال بطابعة SUNMI عند توفرها",
                printer.isConnected() ? "SUNMI printer connected" : "SUNMI printer will connect when available"), 14, Color.GRAY);
        printerState.setPadding(dp(8),dp(20),dp(8),0);
        box.addView(printerState);
    }

    private void showOrder() {
        baseScreen(false);
        ScrollView sv = contentScroll();
        LinearLayout box = stack(sv);
        box.addView(heading(t("طلب جديد", "New Order")));

        box.addView(sectionTitle(t("بيانات السيارة والعميل", "Car & Customer")));
        EditText plate = field(t("رقم اللوحة *", "Plate number *"), false);
        box.addView(plate);
        RadioGroup stayGroup = new RadioGroup(this);
        stayGroup.setOrientation(LinearLayout.HORIZONTAL);
        RadioButton waiting = radio(t("العميل ينتظر", "Customer waiting"));
        RadioButton leaving = radio(t("العميل سيغادر", "Customer leaving"));
        stayGroup.addView(waiting, new RadioGroup.LayoutParams(0, dp(52), 1));
        stayGroup.addView(leaving, new RadioGroup.LayoutParams(0, dp(52), 1));
        waiting.setChecked(true);
        box.addView(stayGroup);
        EditText phone = field(t("رقم العميل (إلزامي عند المغادرة)", "Customer phone (required if leaving)"), true);
        box.addView(phone);

        box.addView(sectionTitle(t("نوع الغسيل", "Wash Type")));
        List<DBHelper.WashType> washTypes = db.getWashTypes(true);
        RadioGroup carGroup = new RadioGroup(this);
        carGroup.setOrientation(LinearLayout.VERTICAL);
        if (washTypes.isEmpty()) {
            TextView emptyWash = text(t("لا توجد أنواع غسيل مفعلة. أضف نوع غسيل من الإدارة.", "No active wash types. Add a wash type from Admin."), 14, RED);
            emptyWash.setPadding(dp(6),dp(4),dp(6),dp(8));
            box.addView(emptyWash);
        } else {
            for (int i = 0; i < washTypes.size(); i++) {
                DBHelper.WashType wt = washTypes.get(i);
                String displayName = arabic ? wt.nameAr : wt.nameEn;
                if (displayName == null || displayName.trim().isEmpty()) displayName = arabic ? wt.nameEn : wt.nameAr;
                RadioButton wash = radio(displayName + " - " + money(wt.price));
                wash.setTag(wt);
                carGroup.addView(wash);
                if (i == 0) wash.setChecked(true);
            }
        }
        box.addView(carGroup);

        box.addView(sectionTitle(t("العامل المسؤول", "Responsible Worker")));
        List<DBHelper.Employee> employees = db.getEmployees(true);
        Spinner worker = new Spinner(this);
        ArrayAdapter<DBHelper.Employee> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, employees);
        worker.setAdapter(adapter); box.addView(worker, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        if (employees.isEmpty()) {
            TextView warn = text(t("لا يوجد عمال مضافون. أضف العمال من الإدارة أولاً.", "No workers yet. Add workers from Admin first."), 14, RED);
            warn.setPadding(dp(6),dp(4),dp(6),dp(8)); box.addView(warn);
        }

        box.addView(sectionTitle(t("خدمات إضافية", "Additional Services")));
        List<DBHelper.Product> products = db.getProducts(true);
        List<CheckBox> productChecks = new ArrayList<>();
        if (products.isEmpty()) {
            TextView empty = text(t("لا توجد خدمات إضافية حالياً", "No additional services yet"), 14, Color.GRAY);
            box.addView(empty);
        } else {
            for (DBHelper.Product p : products) {
                CheckBox cb = new CheckBox(this);
                cb.setText((arabic ? p.nameAr : p.nameEn) + "  •  " + money(p.price));
                cb.setTextSize(17); cb.setTag(p); cb.setPadding(dp(8),dp(4),dp(8),dp(4));
                box.addView(cb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
                productChecks.add(cb);
            }
        }

        box.addView(sectionTitle(t("الخصم", "Discount")));
        final String[] discountType = {"none"};
        final double[] discountValue = {0};
        final String[] discountReason = {""};
        TextView discountStatus = text(t("بدون خصم", "No discount"), 16, Color.GRAY);
        discountStatus.setPadding(dp(8), dp(4), dp(8), dp(4));
        box.addView(discountStatus);
        Button discountButton = menuButton(t("إضافة / تعديل الخصم", "Add / Edit Discount"));
        discountButton.setOnClickListener(v -> requestDiscount(discountType, discountValue, discountReason, discountStatus));
        box.addView(discountButton);
        Button clearDiscount = smallButton(t("إلغاء الخصم", "Clear Discount"));
        clearDiscount.setOnClickListener(v -> {
            discountType[0] = "none"; discountValue[0] = 0; discountReason[0] = "";
            discountStatus.setText(t("بدون خصم", "No discount"));
        });
        box.addView(clearDiscount, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        box.addView(sectionTitle(t("طريقة الدفع", "Payment Method")));
        LinearLayout pay = new LinearLayout(this); pay.setOrientation(LinearLayout.VERTICAL);
        Button cash = primaryButton(t("نقدي", "Cash"));
        cash.setOnClickListener(v -> completeSale(plate, phone, leaving, carGroup, employees, worker,
                productChecks, discountType, discountValue, discountReason, "Cash", -1, -1));
        pay.addView(cash);
        Button card = primaryButton(t("شبكة", "Card"));
        card.setOnClickListener(v -> completeSale(plate, phone, leaving, carGroup, employees, worker,
                productChecks, discountType, discountValue, discountReason, "Card", -1, -1));
        pay.addView(card);
        Button split = primaryButton(t("دفع جزء كاش وجزء شبكة", "Split Cash + Card"));
        split.setOnClickListener(v -> completeSale(plate, phone, leaving, carGroup, employees, worker,
                productChecks, discountType, discountValue, discountReason, "Split", -1, -1));
        pay.addView(split);
        box.addView(pay);
    }

    private RadioButton findChecked(RadioGroup g) {
        int id = g.getCheckedRadioButtonId();
        return id == -1 ? null : g.findViewById(id);
    }

    private interface SplitPaymentPicked { void onPicked(double cash, double card); }

    private void completeSale(EditText plate, EditText phone, RadioButton leaving, RadioGroup carGroup,
                              List<DBHelper.Employee> employees, Spinner worker,
                              List<CheckBox> productChecks, String[] discountType, double[] discountValue,
                              String[] discountReason, String paymentMethod, double splitCash, double splitCard) {
        RadioButton selectedCar = findChecked(carGroup);
        if (plate.getText().toString().trim().isEmpty()) { toast(t("أدخل رقم اللوحة", "Enter plate number")); return; }
        if (leaving.isChecked() && phone.getText().toString().trim().isEmpty()) { toast(t("رقم العميل مطلوب لأنه سيغادر", "Customer phone is required when leaving")); return; }
        if (employees.isEmpty() || worker.getSelectedItem() == null) { toast(t("أضف العامل المسؤول أولاً", "Add/select a responsible worker first")); return; }
        if (selectedCar == null) { toast(t("اختر نوع الغسيل", "Choose a wash type")); return; }

        DBHelper.WashType selectedWash = (DBHelper.WashType) selectedCar.getTag();
        String size = selectedWash.nameAr;
        if (size == null || size.trim().isEmpty()) size = selectedWash.nameEn;
        double base = selectedWash.price;
        List<DBHelper.Product> selectedProducts = new ArrayList<>();
        for (CheckBox cb : productChecks) if (cb.isChecked()) selectedProducts.add((DBHelper.Product) cb.getTag());

        double subtotal = base;
        for (DBHelper.Product product : selectedProducts) subtotal += product.price;
        double discountAmount = 0;
        if ("percent".equals(discountType[0])) discountAmount = subtotal * Math.max(0, Math.min(100, discountValue[0])) / 100.0;
        else if ("fixed".equals(discountType[0])) discountAmount = Math.max(0, Math.min(subtotal, discountValue[0]));
        double total = Math.max(0, subtotal - discountAmount);

        if ("Split".equals(paymentMethod) && splitCash < 0 && splitCard < 0) {
            requestSplitPayment(total, (cash, card) -> completeSale(plate, phone, leaving, carGroup, employees, worker,
                    productChecks, discountType, discountValue, discountReason,
                    "Split", cash, card));
            return;
        }

        DBHelper.Employee emp = (DBHelper.Employee) worker.getSelectedItem();
        try {
            long id = db.createSale(plate.getText().toString(), phone.getText().toString(), leaving.isChecked(), size, base,
                    emp.id, emp.name, paymentMethod, splitCash, splitCard, selectedProducts,
                    discountType[0], discountValue[0], discountReason[0]);
            LocalBackupManager.backup(this, db);
            DBHelper.Sale sale = db.getSale(id);
            showPaidDialog(sale);
        } catch (Exception e) {
            toast(t("تعذر حفظ العملية، تحقق من مبالغ الدفع", "Could not save sale; check payment amounts"));
        }
    }

    private void requestSplitPayment(double total, SplitPaymentPicked callback) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18), dp(8), dp(18), 0);
        TextView totalView = text(t("الإجمالي: ", "Total: ") + money(total), 19, GRAY);
        totalView.setTypeface(Typeface.DEFAULT_BOLD);
        totalView.setPadding(0, dp(4), 0, dp(10));
        form.addView(totalView);
        EditText cash = numberField(""); cash.setHint(t("المبلغ كاش", "Cash amount")); form.addView(cash);
        EditText card = numberField(""); card.setHint(t("المبلغ شبكة", "Card amount")); form.addView(card);

        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle(t("تقسيم الدفع", "Split Payment"))
                .setView(form)
                .setPositiveButton(t("حفظ", "Save"), null)
                .setNegativeButton(t("إلغاء", "Cancel"), null)
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try {
                double cashValue = Double.parseDouble(cash.getText().toString().trim());
                double cardValue = Double.parseDouble(card.getText().toString().trim());
                if (cashValue < 0 || cardValue < 0 || Math.abs((cashValue + cardValue) - total) > 0.01) {
                    toast(t("مجموع الكاش والشبكة يجب أن يساوي الإجمالي", "Cash + card must equal the total"));
                    return;
                }
                callback.onPicked(cashValue, cardValue);
                d.dismiss();
            } catch (Exception e) {
                toast(t("أدخل مبلغ الكاش ومبلغ الشبكة", "Enter cash and card amounts"));
            }
        }));
        d.show();
    }

    private void showPaidDialog(DBHelper.Sale sale) {
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle(t("تم تسجيل العملية ✓", "Payment saved ✓"))
                .setMessage(t("رقم الفاتورة: ", "Invoice #: ") + sale.invoiceNo + "\n" +
                        (sale.discountAmount > 0 ? t("الخصم: ", "Discount: ") + money(sale.discountAmount) + "\n" : "") +
                        ("Split".equals(sale.paymentMethod) ? t("كاش: ", "Cash: ") + money(sale.cashAmount) + "  •  " + t("شبكة: ", "Card: ") + money(sale.cardAmount) + "\n" : "") +
                        t("الإجمالي: ", "Total: ") + money(sale.total))
                .setPositiveButton(t("طباعة الفاتورة", "Print Receipt"), null)
                .setNegativeButton(t("طلب جديد بدون طباعة", "New Order - No Print"), (x,w) -> showOrder())
                .setNeutralButton(t("حفظ كصورة", "Save as Image"), null)
                .create();
        d.setOnShowListener(x -> {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                if (printer.printReceipt(sale)) toast(t("تم إرسال الفاتورة للطابعة", "Receipt sent to printer"));
                else toast(t("الطابعة غير متصلة حالياً", "Printer is not connected"));
            });
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> saveInvoiceImage(sale, false));
        });
        d.show();
    }

    private void showReports() {
        baseScreen(false);
        ScrollView sv = contentScroll();
        LinearLayout box = stack(sv);
        box.addView(heading(t("التقارير", "Reports")));

        final long[] range = {DBHelper.startOfMonth(), DBHelper.startOfNextMonth()};
        final long[] custom = {DBHelper.startOfToday(), DBHelper.startOfTomorrow() - 60_000L};
        final Calendar monthCursor = Calendar.getInstance();
        monthCursor.setTimeInMillis(range[0]);

        TextView period = text("", 16, GRAY);
        period.setTypeface(Typeface.DEFAULT_BOLD);
        period.setGravity(Gravity.CENTER);
        period.setPadding(dp(4),dp(8),dp(4),dp(8));
        box.addView(period);

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        Button prev = smallButton(t("‹ شهر", "‹ Month"));
        Button today = smallButton(t("اليوم", "Today"));
        Button current = smallButton(t("هذا الشهر", "This Month"));
        Button next = smallButton(t("شهر ›", "Month ›"));
        nav.addView(prev,new LinearLayout.LayoutParams(0,dp(52),1));
        nav.addView(today,new LinearLayout.LayoutParams(0,dp(52),1));
        nav.addView(current,new LinearLayout.LayoutParams(0,dp(52),1));
        nav.addView(next,new LinearLayout.LayoutParams(0,dp(52),1));
        box.addView(nav);

        box.addView(sectionTitle(t("بحث بالتاريخ والوقت", "Search by Date & Time")));
        LinearLayout customRow = new LinearLayout(this);
        customRow.setOrientation(LinearLayout.HORIZONTAL);
        Button from = smallButton("");
        Button to = smallButton("");
        customRow.addView(from,new LinearLayout.LayoutParams(0,dp(58),1));
        customRow.addView(to,new LinearLayout.LayoutParams(0,dp(58),1));
        box.addView(customRow);
        Button applyCustom = primaryButton(t("عرض الفترة المحددة", "Show Selected Range"));
        box.addView(applyCustom);

        LinearLayout reportBody = new LinearLayout(this);
        reportBody.setOrientation(LinearLayout.VERTICAL);
        box.addView(reportBody);

        SimpleDateFormat monthFmt = new SimpleDateFormat("MMMM yyyy", arabic ? new Locale("ar","SA") : Locale.ENGLISH);
        SimpleDateFormat dateTimeFmt = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        final Runnable[] render = new Runnable[1];
        Runnable updateCustomLabels = () -> {
            from.setText(t("من: ", "From: ") + dateTimeFmt.format(new Date(custom[0])));
            to.setText(t("إلى: ", "To: ") + dateTimeFmt.format(new Date(custom[1])));
        };
        updateCustomLabels.run();

        render[0] = () -> {
            reportBody.removeAllViews();
            String label = dateTimeFmt.format(new Date(range[0])) + "  →  " + dateTimeFmt.format(new Date(Math.max(range[0], range[1] - 1)));
            period.setText(label);
            DBHelper.DailySummary summary = db.getSummary(range[0], range[1]);

            reportBody.addView(sectionTitle(t("ملخص التقرير", "Report Summary")));
            List<String[]> summaryRows = new ArrayList<>();
            summaryRows.add(new String[]{t("إجمالي المبيعات قبل المرتجع", "Gross sales"), money(summary.grossSales)});
            summaryRows.add(new String[]{t("المرتجعات", "Refunds"), money(summary.refunds)});
            summaryRows.add(new String[]{t("صافي المبيعات بعد المرتجعات", "Net sales"), money(summary.sales)});
            summaryRows.add(new String[]{t("عدد السيارات المغسولة", "Cars washed"), String.valueOf(summary.totalCars)});
            reportBody.addView(reportTable(new String[]{t("البند", "Item"), t("القيمة", "Value")}, summaryRows, dp(420)));

            reportBody.addView(sectionTitle(t("الأكثر طلباً", "Most Requested")));
            String addon = arabic ? summary.topAddOnAr : summary.topAddOnEn;
            List<String[]> popularRows = new ArrayList<>();
            popularRows.add(new String[]{t("أكثر إضافة/خدمة", "Top add-on/service"),
                    (addon == null || addon.isEmpty()) ? "-" : addon + " × " + summary.topAddOnCount});
            popularRows.add(new String[]{t("أكثر نوع غسيل", "Top wash type"),
                    (summary.topCarSize == null || summary.topCarSize.isEmpty()) ? "-" : summary.topCarSize + " × " + summary.topCarSizeCount});
            reportBody.addView(reportTable(new String[]{t("البند", "Item"), t("النتيجة", "Result")}, popularRows, dp(460)));

            reportBody.addView(sectionTitle(t("أداء العمال", "Worker Performance")));
            List<String[]> workerRows = new ArrayList<>();
            int workerRank = 1;
            for (DBHelper.WorkerCount w : summary.workerCounts) {
                workerRows.add(new String[]{String.valueOf(workerRank++), w.name, String.valueOf(w.count), String.valueOf(w.refundCount)});
            }
            reportBody.addView(reportTable(new String[]{"#", t("العامل", "Worker"), t("الغسلات", "Washes"), t("مرتجع", "Refunds")}, workerRows, dp(560)));

            reportBody.addView(sectionTitle(t("تفاصيل الأيام", "Daily Breakdown")));
            List<DBHelper.DaySummary> days = db.getDailyBreakdown(range[0], range[1]);
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            List<String[]> dayRows = new ArrayList<>();
            for (DBHelper.DaySummary day : days) {
                DBHelper.DailySummary ds = day.summary;
                dayRows.add(new String[]{df.format(new Date(day.dayStart)), String.valueOf(ds.cars), money(ds.grossSales), money(ds.refunds), money(ds.sales)});
            }
            reportBody.addView(reportTable(new String[]{t("التاريخ", "Date"), t("السيارات", "Cars"), t("الإجمالي", "Gross"), t("المرتجع", "Refunds"), t("الصافي", "Net")}, dayRows, dp(760)));

            reportBody.addView(sectionTitle(t("طباعة وحفظ التقرير", "Print & Save Report")));
            Button printA4 = primaryButton(t("طباعة التقرير A4", "Print A4 Report"));
            printA4.setOnClickListener(v -> {
                try {
                    File f = DocumentExporter.createReportPdf(this, db, range[0], range[1], t("تقرير مغسلة نوره", "NOURA Car Wash Report"), arabic);
                    DocumentExporter.printPdf(this, f, "Noura Report");
                } catch (Exception e) { toast(t("تعذر إنشاء التقرير", "Could not create report")); }
            });
            reportBody.addView(printA4);

            Button savePdf = menuButton(t("حفظ التقرير PDF على الجهاز", "Save Report as PDF"));
            savePdf.setOnClickListener(v -> {
                try {
                    File f = DocumentExporter.createReportPdf(this, db, range[0], range[1], t("تقرير مغسلة نوره", "NOURA Car Wash Report"), arabic);
                    String savedName = DocumentExporter.saveReportPdfToDevice(this, f);
                    toast(t("تم حفظ التقرير في التنزيلات/NouraPOS: ", "Saved to Downloads/NouraPOS: ") + savedName);
                } catch (Exception e) { toast(t("تعذر حفظ التقرير", "Could not save report")); }
            });
            reportBody.addView(savePdf);

            Button sharePdf = menuButton(t("مشاركة التقرير / إيميل", "Share Report / Email"));
            sharePdf.setOnClickListener(v -> {
                try {
                    File f = DocumentExporter.createReportPdf(this, db, range[0], range[1], t("تقرير مغسلة نوره", "NOURA Car Wash Report"), arabic);
                    DocumentExporter.shareFile(this, f, "application/pdf", t("مشاركة التقرير", "Share Report"));
                } catch (Exception e) { toast(t("تعذر مشاركة التقرير", "Could not share report")); }
            });
            reportBody.addView(sharePdf);
        };

        prev.setOnClickListener(v -> {
            monthCursor.add(Calendar.MONTH,-1);
            range[0]=DBHelper.startOfMonth(monthCursor.getTimeInMillis());
            range[1]=DBHelper.startOfNextMonth(monthCursor.getTimeInMillis());
            render[0].run();
        });
        next.setOnClickListener(v -> {
            monthCursor.add(Calendar.MONTH,1);
            range[0]=DBHelper.startOfMonth(monthCursor.getTimeInMillis());
            range[1]=DBHelper.startOfNextMonth(monthCursor.getTimeInMillis());
            render[0].run();
        });
        today.setOnClickListener(v -> {
            range[0]=DBHelper.startOfToday();
            range[1]=DBHelper.startOfTomorrow();
            render[0].run();
        });
        current.setOnClickListener(v -> {
            monthCursor.setTimeInMillis(System.currentTimeMillis());
            range[0]=DBHelper.startOfMonth(); range[1]=DBHelper.startOfNextMonth();
            render[0].run();
        });
        from.setOnClickListener(v -> pickDateTime(custom[0], value -> { custom[0]=value; updateCustomLabels.run(); }));
        to.setOnClickListener(v -> pickDateTime(custom[1], value -> { custom[1]=value; updateCustomLabels.run(); }));
        applyCustom.setOnClickListener(v -> {
            if (custom[1] <= custom[0]) { toast(t("وقت النهاية يجب أن يكون بعد البداية", "End time must be after start time")); return; }
            range[0]=custom[0]; range[1]=custom[1] + 60_000L; render[0].run();
        });

        period.setText(monthFmt.format(new Date(range[0])));
        render[0].run();
    }

    private View reportTable(String[] headers, List<String[]> rows, int minWidth) {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(true);
        TableLayout table = new TableLayout(this);
        table.setMinimumWidth(minWidth);
        table.setStretchAllColumns(false);
        int cellWidth = Math.max(dp(88), minWidth / Math.max(1, headers.length));
        table.addView(reportTableRow(headers, true, cellWidth));
        if (rows == null || rows.isEmpty()) {
            String[] empty = new String[headers.length];
            for (int i = 0; i < empty.length; i++) empty[i] = i == 0 ? t("لا توجد بيانات", "No data") : "-";
            table.addView(reportTableRow(empty, false, cellWidth));
        } else {
            for (String[] row : rows) table.addView(reportTableRow(row, false, cellWidth));
        }
        scroll.addView(table, new HorizontalScrollView.LayoutParams(minWidth, ViewGroup.LayoutParams.WRAP_CONTENT));
        return scroll;
    }

    private TableRow reportTableRow(String[] values, boolean header, int cellWidth) {
        TableRow row = new TableRow(this);
        for (String value : values) {
            TextView cell = text(value == null ? "" : value, header ? 14 : 13, GRAY);
            cell.setGravity(Gravity.CENTER);
            cell.setPadding(dp(8), dp(10), dp(8), dp(10));
            if (header) cell.setTypeface(Typeface.DEFAULT_BOLD);
            cell.setBackground(round(header ? SMOKE : Color.WHITE, Color.LTGRAY, 0));
            row.addView(cell, new TableRow.LayoutParams(cellWidth, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        return row;
    }

    private void addRanking(LinearLayout box, List<DBHelper.WorkerCount> counts) {
        if (counts.isEmpty()) { box.addView(text(t("لا توجد عمليات بعد", "No sales yet"),15,Color.GRAY)); return; }
        int rank = 1;
        for (DBHelper.WorkerCount w : counts) {
            LinearLayout row = card(); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView r = text(String.valueOf(rank),22,RED); r.setTypeface(Typeface.DEFAULT_BOLD); row.addView(r,new LinearLayout.LayoutParams(dp(44),dp(56)));
            LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
            TextView n = text(w.name,18,GRAY); n.setTypeface(Typeface.DEFAULT_BOLD); info.addView(n);
            String details = t("الغسلات: ","Washes: ") + w.count;
            if (w.refundCount > 0) details += "   •   " + t("مرتجع: ","Refunded: ") + w.refundCount;
            info.addView(text(details,14,Color.DKGRAY));
            row.addView(info,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1));
            box.addView(row); rank++;
        }
    }

    private void showInvoices() {
        baseScreen(false);
        ScrollView sv = contentScroll(); LinearLayout box = stack(sv);
        box.addView(heading(t("فواتير اليوم", "Today's Invoices")));
        TextView hint = text(t("رقم الفاتورة يتجدد يومياً ويبدأ من 1", "Invoice numbering resets daily and starts at 1"), 14, Color.GRAY);
        hint.setPadding(dp(4), 0, dp(4), dp(10)); box.addView(hint);
        List<DBHelper.Sale> sales = db.getSalesInRange(DBHelper.startOfToday(), DBHelper.startOfTomorrow(), 0);
        if (sales.isEmpty()) {
            box.addView(text(t("لا توجد فواتير اليوم", "No invoices today"), 16, Color.GRAY));
            return;
        }
        SimpleDateFormat time = new SimpleDateFormat("HH:mm", Locale.US);
        for (DBHelper.Sale sale : sales) {
            LinearLayout c = card(); c.setOrientation(LinearLayout.VERTICAL);
            String state = sale.refunded ? "  •  " + t("مرتجع", "REFUNDED") : "";
            TextView first = text(t("فاتورة #", "Invoice #") + sale.invoiceNo + "  •  " + sale.plate + "  •  " + money(sale.total) + state,
                    17, sale.refunded ? RED : GRAY);
            first.setTypeface(Typeface.DEFAULT_BOLD); c.addView(first);
            c.addView(text(time.format(new Date(sale.createdAt)) + "  •  " + sale.workerName, 14, Color.GRAY));
            Button details = smallButton(t("التفاصيل", "Details"));
            details.setOnClickListener(v -> showSaleDetails(sale.id));
            c.addView(details);
            box.addView(c);
        }
    }

    private void showSearch() {
        baseScreen(false);
        ScrollView sv = contentScroll(); LinearLayout box = stack(sv);
        box.addView(heading(t("البحث عن فاتورة", "Find an Invoice")));
        EditText q = field(t("رقم الفاتورة أو اللوحة أو رقم العميل", "Invoice #, plate or customer phone"), false); box.addView(q);
        Button go = primaryButton(t("بحث", "Search")); box.addView(go);
        LinearLayout results = new LinearLayout(this); results.setOrientation(LinearLayout.VERTICAL); box.addView(results);
        go.setOnClickListener(v -> {
            results.removeAllViews();
            String queryText = q.getText().toString().trim();
            if (queryText.isEmpty()) { toast(t("اكتب رقم الفاتورة أو اللوحة أو الجوال", "Enter invoice #, plate or phone")); return; }
            List<DBHelper.Sale> sales = db.searchSales(queryText, 100);
            if (sales.isEmpty()) { results.addView(text(t("لا توجد نتائج", "No results"),16,Color.GRAY)); return; }
            for (DBHelper.Sale sale : sales) {
                LinearLayout c = card(); c.setOrientation(LinearLayout.VERTICAL);
                String state = sale.refunded ? "  •  " + t("مرتجع", "REFUNDED") : "";
                TextView first = text("#" + sale.invoiceNo + "  •  " + sale.plate + "  •  " + money(sale.total) + state,17,sale.refunded?RED:GRAY);
                first.setTypeface(Typeface.DEFAULT_BOLD); c.addView(first);
                c.addView(text(new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date(sale.createdAt)) + "  •  " + sale.workerName,14,Color.GRAY));
                Button details = smallButton(t("التفاصيل", "Details")); details.setOnClickListener(x -> showSaleDetails(sale.id)); c.addView(details);
                results.addView(c);
            }
        });
    }

    private void showSaleDetails(long id) {
        DBHelper.Sale s = db.getSale(id);
        if (s == null) return;
        StringBuilder b = new StringBuilder();
        if (s.refunded) b.append(t("الحالة: مرتجع", "Status: REFUNDED")).append("\n\n");
        b.append(t("اللوحة: ","Plate: ")).append(s.plate).append("\n");
        b.append(t("رقم العميل: ","Phone: ")).append(s.phone == null || s.phone.isEmpty() ? "-" : s.phone).append("\n");
        b.append(t("العامل: ","Worker: ")).append(s.workerName).append("\n");
        b.append(t("نوع الغسيل: ","Wash type: ")).append(s.carSize).append("\n");
        for (DBHelper.Product p : s.items) b.append("• ").append(arabic?p.nameAr:p.nameEn).append(" - ").append(money(p.price)).append("\n");
        b.append(t("المجموع قبل الخصم: ","Subtotal: ")).append(money(s.subtotal)).append("\n");
        if (s.discountAmount > 0) {
            String dsc = "percent".equals(s.discountType) ? String.format(Locale.US, "%.0f%%", s.discountValue) : money(s.discountValue);
            b.append(t("الخصم: ","Discount: ")).append(dsc).append(" (-").append(money(s.discountAmount)).append(")\n");
            if (s.discountReason != null && !s.discountReason.trim().isEmpty())
                b.append(t("سبب الخصم: ", "Discount reason: ")).append(s.discountReason).append("\n");
        }
        b.append(t("طريقة الدفع: ", "Payment: ")).append(paymentLabel(s.paymentMethod)).append("\n");
        if ("Split".equals(s.paymentMethod)) {
            b.append(t("كاش: ", "Cash: ")).append(money(s.cashAmount)).append("\n");
            b.append(t("شبكة: ", "Card: ")).append(money(s.cardAmount)).append("\n");
        }
        b.append(t("الإجمالي: ","Total: ")).append(money(s.total));
        if (s.refunded) {
            b.append("\n\n").append(t("وقت المرتجع: ","Refunded at: ")).append(new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date(s.refundedAt)));
            if (s.refundReason != null && !s.refundReason.isEmpty()) b.append("\n").append(t("سبب المرتجع: ","Refund reason: ")).append(s.refundReason);
        }
        AlertDialog d = new AlertDialog.Builder(this).setTitle(t("تفاصيل الفاتورة #","Invoice #") + s.invoiceNo).setMessage(b.toString())
                .setPositiveButton(t("طباعة", "Print"),null)
                .setNeutralButton(t("خيارات", "Options"),null)
                .setNegativeButton(t("إغلاق","Close"),null).create();
        d.setOnShowListener(x -> {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                if (!printer.printReceipt(s)) toast(t("الطابعة غير متصلة", "Printer not connected"));
            });
            d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> showInvoiceActions(s));
        });
        d.show();
    }

    private void showInvoiceActions(DBHelper.Sale sale) {
        List<String> labels = new ArrayList<>();
        labels.add(t("حفظ الفاتورة كصورة", "Save Invoice as Image"));
        labels.add(t("مشاركة صورة الفاتورة", "Share Invoice Image"));
        if (!sale.refunded) labels.add(t("تسجيل الفاتورة كمرتجع", "Mark Invoice as Refunded"));
        new AlertDialog.Builder(this).setTitle(t("خيارات الفاتورة", "Invoice Options"))
                .setItems(labels.toArray(new String[0]), (d,which) -> {
                    if (which == 0) saveInvoiceImage(sale,false);
                    else if (which == 1) saveInvoiceImage(sale,true);
                    else if (!sale.refunded) requestRefund(sale);
                }).setNegativeButton(t("إلغاء","Cancel"),null).show();
    }

    private void saveInvoiceImage(DBHelper.Sale sale, boolean share) {
        try {
            if (share) {
                File f = DocumentExporter.saveReceiptImage(this, sale);
                DocumentExporter.shareFile(this, f, "image/png", t("مشاركة الفاتورة", "Share Invoice"));
            } else {
                String name = DocumentExporter.saveReceiptImageToDevice(this, sale);
                toast(t("تم حفظ الفاتورة في الصور/NouraPOS: ", "Saved to Pictures/NouraPOS: ") + name);
            }
        } catch (Exception e) { toast(t("تعذر حفظ صورة الفاتورة", "Could not save invoice image")); }
    }

    private void requestRefund(DBHelper.Sale sale) {
        String pin = prefs.getString("admin_pin", "");
        if (pin.isEmpty()) { toast(t("أنشئ PIN الإدارة أولاً", "Create an Admin PIN first")); return; }
        EditText pinInput = new EditText(this);
        pinInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pinInput.setHint(t("PIN الإدارة", "Admin PIN"));
        new AlertDialog.Builder(this).setTitle(t("اعتماد المرتجع", "Approve Refund")).setView(pinInput)
                .setPositiveButton(t("متابعة","Continue"),(d,w)->{
                    if (!pin.equals(pinInput.getText().toString().trim())) { toast(t("رمز الإدارة غير صحيح", "Incorrect Admin PIN")); return; }
                    EditText reason = field(t("سبب المرتجع (اختياري)","Refund reason (optional)"),false);
                    new AlertDialog.Builder(this).setTitle(t("تأكيد مرتجع الفاتورة #","Refund Invoice #")+sale.invoiceNo).setView(reason)
                            .setPositiveButton(t("تأكيد المرتجع","Confirm Refund"),(x,y)->{
                                if (db.refundSale(sale.id, reason.getText().toString())) {
                                    LocalBackupManager.backup(this,db);
                                    toast(t("تم تسجيل الفاتورة كمرتجع بدون حذفها", "Invoice marked refunded and kept in records"));
                                    showSaleDetails(sale.id);
                                } else toast(t("الفاتورة مرتجعة مسبقاً", "Invoice is already refunded"));
                            }).setNegativeButton(t("إلغاء","Cancel"),null).show();
                }).setNegativeButton(t("إلغاء","Cancel"),null).show();
    }

    private interface TimePicked { void onPicked(long value); }

    private void pickDateTime(long initial, TimePicked callback) {
        Calendar c = Calendar.getInstance(); c.setTimeInMillis(initial);
        new DatePickerDialog(this, (view,year,month,day) -> {
            Calendar picked = Calendar.getInstance();
            picked.set(year,month,day,c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),0); picked.set(Calendar.MILLISECOND,0);
            new TimePickerDialog(this, (timeView,hour,minute) -> {
                picked.set(Calendar.HOUR_OF_DAY,hour); picked.set(Calendar.MINUTE,minute);
                callback.onPicked(picked.getTimeInMillis());
            },c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show();
        },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void requestDiscount(final String[] type, final double[] value, final String[] reason, final TextView status) {
        String pin = prefs.getString("admin_pin", "");
        if (pin.isEmpty()) {
            toast(t("أنشئ PIN الإدارة أولاً من قسم الإدارة", "Create an Admin PIN first"));
            return;
        }
        final EditText pinInput = new EditText(this);
        pinInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pinInput.setHint(t("PIN الإدارة", "Admin PIN"));
        new AlertDialog.Builder(this)
                .setTitle(t("اعتماد الخصم", "Approve Discount"))
                .setView(pinInput)
                .setPositiveButton(t("متابعة", "Continue"), (d,w) -> {
                    if (!pin.equals(pinInput.getText().toString().trim())) {
                        toast(t("رمز الإدارة غير صحيح", "Incorrect Admin PIN"));
                        return;
                    }
                    showDiscountEditor(type, value, reason, status);
                })
                .setNegativeButton(t("إلغاء", "Cancel"), null).show();
    }

    private void showDiscountEditor(final String[] type, final double[] value, final String[] reason, final TextView status) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18), dp(8), dp(18), 0);
        RadioGroup group = new RadioGroup(this);
        RadioButton percent = radio(t("نسبة مئوية %", "Percentage %")); percent.setTag("percent");
        RadioButton fixed = radio(t("مبلغ ثابت (ريال)", "Fixed amount (SAR)")); fixed.setTag("fixed");
        group.addView(percent); group.addView(fixed);
        if ("fixed".equals(type[0])) fixed.setChecked(true); else percent.setChecked(true);
        form.addView(group);
        EditText amount = numberField(value[0] > 0 ? String.valueOf(value[0]) : "");
        amount.setHint(t("قيمة الخصم", "Discount value")); form.addView(amount);
        EditText reasonInput = field(t("سبب الخصم *", "Discount reason *"), false);
        reasonInput.setText(reason[0]); form.addView(reasonInput);
        AlertDialog d = new AlertDialog.Builder(this).setTitle(t("الخصم", "Discount")).setView(form)
                .setPositiveButton(t("حفظ", "Save"), null)
                .setNegativeButton(t("إلغاء", "Cancel"), null).create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try {
                double amountValue = Double.parseDouble(amount.getText().toString());
                RadioButton selected = findChecked(group);
                String selectedType = selected == null ? "percent" : (String) selected.getTag();
                String why = reasonInput.getText().toString().trim();
                if (amountValue <= 0 || ("percent".equals(selectedType) && amountValue > 100)) {
                    toast(t("تأكد من قيمة الخصم", "Check the discount value")); return;
                }
                if (why.isEmpty()) {
                    toast(t("اكتب سبب الخصم", "Enter a discount reason")); return;
                }
                type[0] = selectedType; value[0] = amountValue; reason[0] = why;
                String valueText = "percent".equals(selectedType) ? String.format(Locale.US, "%.0f%%", amountValue) : money(amountValue);
                status.setText(t("خصم ", "Discount ") + valueText + " • " + why);
                d.dismiss();
            } catch (Exception e) { toast(t("تأكد من قيمة الخصم", "Check the discount value")); }
        }));
        d.show();
    }

    private void requestAdmin() {
        String pin = prefs.getString("admin_pin", "");
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        input.setHint(pin.isEmpty() ? t("اختر PIN من 4 أرقام", "Create a 4-digit PIN") : t("أدخل PIN", "Enter PIN"));
        new AlertDialog.Builder(this)
                .setTitle(pin.isEmpty() ? t("إنشاء رمز الإدارة", "Create Admin PIN") : t("دخول الإدارة", "Admin Login"))
                .setView(input)
                .setPositiveButton(t("متابعة","Continue"),(d,w)->{
                    String entered = input.getText().toString().trim();
                    if (pin.isEmpty()) {
                        if (entered.matches("\\d{4}")) { prefs.edit().putString("admin_pin",entered).apply(); showAdmin(); }
                        else toast(t("الرمز يجب أن يكون 4 أرقام", "PIN must be 4 digits"));
                    } else if (pin.equals(entered)) showAdmin();
                    else toast(t("رمز غير صحيح", "Incorrect PIN"));
                }).setNegativeButton(t("إلغاء","Cancel"),null).show();
    }

    private void showAdmin() {
        baseScreen(false);
        ScrollView sv = contentScroll(); LinearLayout box = stack(sv);
        box.addView(heading(t("الإدارة", "Admin")));
        box.addView(sectionTitle(t("أسعار الغسيل", "Wash Prices")));
        TextView unlimitedWashTypes = text(t("يمكنك إضافة أي عدد من أنواع الغسيل وتعديل أسعارها بدون حد", "You can add any number of wash types and edit their prices"), 14, Color.GRAY);
        unlimitedWashTypes.setPadding(dp(4), 0, dp(4), dp(8)); box.addView(unlimitedWashTypes);
        EditText washAr = field("اسم نوع الغسيل بالعربي",false);
        EditText washEn = field("Wash type name in English",false);
        EditText washPrice = numberField(""); washPrice.setHint(t("السعر","Price"));
        box.addView(washAr); box.addView(washEn); box.addView(washPrice);
        Button addWashType = primaryButton(t("إضافة نوع غسيل", "Add Wash Type")); box.addView(addWashType);
        LinearLayout washTypeList = new LinearLayout(this); washTypeList.setOrientation(LinearLayout.VERTICAL); box.addView(washTypeList);
        Runnable renderWashTypes = () -> renderWashTypes(washTypeList);
        addWashType.setOnClickListener(v->{
            try {
                String arName = washAr.getText().toString().trim();
                String enName = washEn.getText().toString().trim();
                if (arName.isEmpty()) { toast(t("اكتب اسم نوع الغسيل", "Enter the wash type name")); return; }
                if (enName.isEmpty()) enName = arName;
                db.addWashType(arName, enName, Double.parseDouble(washPrice.getText().toString()));
                washAr.setText(""); washEn.setText(""); washPrice.setText("");
                LocalBackupManager.backup(this,db); renderWashTypes.run();
            } catch(Exception e){ toast(t("تأكد من الاسم والسعر", "Check the name and price")); }
        });
        renderWashTypes.run();

        box.addView(sectionTitle(t("العمال", "Workers")));
        EditText workerName = field(t("اسم العامل", "Worker name"),false); box.addView(workerName);
        Button addWorker = primaryButton(t("إضافة عامل", "Add Worker")); box.addView(addWorker);
        LinearLayout workerList = new LinearLayout(this); workerList.setOrientation(LinearLayout.VERTICAL); box.addView(workerList);
        Runnable renderWorkers = () -> renderWorkers(workerList);
        addWorker.setOnClickListener(v->{ if(workerName.getText().toString().trim().isEmpty())return; db.addEmployee(workerName.getText().toString()); workerName.setText(""); LocalBackupManager.backup(this,db); renderWorkers.run(); });
        renderWorkers.run();

        box.addView(sectionTitle(t("المنتجات والخدمات الإضافية", "Products & Additional Services")));
        TextView unlimitedProducts = text(t("يمكنك إضافة أي عدد من المنتجات والخدمات بدون حد", "You can add any number of products and services"), 14, Color.GRAY);
        unlimitedProducts.setPadding(dp(4), 0, dp(4), dp(8)); box.addView(unlimitedProducts);
        EditText ar = field("الاسم بالعربي",false); EditText en = field("English name",false); EditText price = numberField(""); price.setHint(t("السعر","Price"));
        box.addView(ar); box.addView(en); box.addView(price);
        Button addProduct = primaryButton(t("إضافة خدمة", "Add Service")); box.addView(addProduct);
        LinearLayout productList = new LinearLayout(this); productList.setOrientation(LinearLayout.VERTICAL); box.addView(productList);
        Runnable renderProducts = () -> renderProducts(productList);
        addProduct.setOnClickListener(v->{
            try {
                if(ar.getText().toString().trim().isEmpty() || en.getText().toString().trim().isEmpty()) { toast(t("اكتب اسم الخدمة بالعربي والإنجليزي", "Enter both Arabic and English names")); return; }
                db.addProduct(ar.getText().toString(),en.getText().toString(),Double.parseDouble(price.getText().toString()));
                ar.setText(""); en.setText(""); price.setText(""); LocalBackupManager.backup(this,db); renderProducts.run();
            } catch(Exception e){ toast(t("تأكد من السعر", "Check the price")); }
        });
        renderProducts.run();

        box.addView(sectionTitle(t("الأمان والنسخ الاحتياطي", "Security & Backup")));
        Button pin = menuButton(t("تغيير PIN الإدارة", "Change Admin PIN")); pin.setOnClickListener(v -> changePin()); box.addView(pin);
        TextView backup = text(t("✓ يتم إنشاء نسخة احتياطية محلية تلقائياً بعد كل عملية أو تعديل. النسخ السحابي سيُربط في مرحلة Firebase.",
                "✓ A local backup is created automatically after each sale or edit. Cloud backup will be connected in the Firebase stage."),14,Color.GRAY);
        backup.setPadding(dp(8),dp(10),dp(8),dp(12)); box.addView(backup);
    }

    private void renderWorkers(LinearLayout list) {
        list.removeAllViews();
        for(DBHelper.Employee e: db.getEmployees(false)) {
            LinearLayout row = card(); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView name = text(e.name,17,GRAY); row.addView(name,new LinearLayout.LayoutParams(0,dp(52),1));
            Button edit = smallButton(t("تعديل","Edit")); edit.setOnClickListener(v->editEmployee(e)); row.addView(edit);
            Switch sw = new Switch(this); sw.setChecked(e.active); sw.setOnCheckedChangeListener((b,c)->{db.setEmployeeActive(e.id,c);LocalBackupManager.backup(this,db);}); row.addView(sw);
            list.addView(row);
        }
    }

    private void editEmployee(DBHelper.Employee e) {
        EditText f = new EditText(this); f.setText(e.name);
        new AlertDialog.Builder(this).setTitle(t("تعديل العامل","Edit Worker")).setView(f)
                .setPositiveButton(t("حفظ","Save"),(d,w)->{if(!f.getText().toString().trim().isEmpty()){db.updateEmployee(e.id,f.getText().toString());LocalBackupManager.backup(this,db);showAdmin();}})
                .setNegativeButton(t("إلغاء","Cancel"),null).show();
    }

    private void renderWashTypes(LinearLayout list) {
        list.removeAllViews();
        for(DBHelper.WashType wt: db.getWashTypes(false)) {
            LinearLayout row = card(); row.setGravity(Gravity.CENTER_VERTICAL);
            String name = arabic ? wt.nameAr : wt.nameEn;
            if (name == null || name.trim().isEmpty()) name = arabic ? wt.nameEn : wt.nameAr;
            TextView n = text(name + " • " + money(wt.price),16,GRAY);
            row.addView(n,new LinearLayout.LayoutParams(0,dp(56),1));
            Button edit = smallButton(t("تعديل","Edit")); edit.setOnClickListener(v->editWashType(wt)); row.addView(edit);
            Switch sw = new Switch(this); sw.setChecked(wt.active);
            sw.setOnCheckedChangeListener((b,c)->{db.setWashTypeActive(wt.id,c);LocalBackupManager.backup(this,db);});
            row.addView(sw);
            list.addView(row);
        }
    }

    private void editWashType(DBHelper.WashType wt) {
        LinearLayout form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(dp(18),dp(8),dp(18),0);
        EditText ar = field("اسم نوع الغسيل بالعربي",false); ar.setText(wt.nameAr); form.addView(ar);
        EditText en = field("Wash type name in English",false); en.setText(wt.nameEn); form.addView(en);
        EditText price = numberField(String.valueOf(wt.price)); form.addView(price);
        new AlertDialog.Builder(this).setTitle(t("تعديل نوع الغسيل","Edit Wash Type")).setView(form)
                .setPositiveButton(t("حفظ","Save"),(d,w)->{
                    try {
                        String arName = ar.getText().toString().trim();
                        String enName = en.getText().toString().trim();
                        if (arName.isEmpty()) { toast(t("اكتب اسم نوع الغسيل","Enter the wash type name")); return; }
                        if (enName.isEmpty()) enName = arName;
                        db.updateWashType(wt.id,arName,enName,Double.parseDouble(price.getText().toString()));
                        LocalBackupManager.backup(this,db); showAdmin();
                    } catch(Exception ex){ toast(t("تأكد من البيانات","Check the details")); }
                }).setNegativeButton(t("إلغاء","Cancel"),null).show();
    }

    private void renderProducts(LinearLayout list) {
        list.removeAllViews();
        for(DBHelper.Product p: db.getProducts(false)) {
            LinearLayout row = card(); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView n = text((arabic?p.nameAr:p.nameEn)+" • "+money(p.price),16,GRAY); row.addView(n,new LinearLayout.LayoutParams(0,dp(56),1));
            Button edit = smallButton(t("تعديل","Edit")); edit.setOnClickListener(v->editProduct(p)); row.addView(edit);
            Switch sw = new Switch(this); sw.setChecked(p.active); sw.setOnCheckedChangeListener((b,c)->{db.setProductActive(p.id,c);LocalBackupManager.backup(this,db);}); row.addView(sw);
            list.addView(row);
        }
    }

    private void editProduct(DBHelper.Product p) {
        LinearLayout form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(dp(18),dp(8),dp(18),0);
        EditText ar = field("الاسم بالعربي",false); ar.setText(p.nameAr); form.addView(ar);
        EditText en = field("English name",false); en.setText(p.nameEn); form.addView(en);
        EditText price = numberField(String.valueOf(p.price)); form.addView(price);
        new AlertDialog.Builder(this).setTitle(t("تعديل الخدمة","Edit Service")).setView(form)
                .setPositiveButton(t("حفظ","Save"),(d,w)->{
                    try { db.updateProduct(p.id,ar.getText().toString(),en.getText().toString(),Double.parseDouble(price.getText().toString())); LocalBackupManager.backup(this,db); showAdmin(); }
                    catch(Exception ex){ toast(t("تأكد من البيانات","Check the details")); }
                }).setNegativeButton(t("إلغاء","Cancel"),null).show();
    }

    private void changePin() {
        EditText f = new EditText(this); f.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle(t("PIN جديد من 4 أرقام","New 4-digit PIN")).setView(f)
                .setPositiveButton(t("حفظ","Save"),(d,w)->{String x=f.getText().toString(); if(x.matches("\\d{4}")){prefs.edit().putString("admin_pin",x).apply();toast(t("تم تغيير الرمز","PIN changed"));}else toast(t("يجب أن يكون 4 أرقام","Must be 4 digits"));})
                .setNegativeButton(t("إلغاء","Cancel"),null).show();
    }

    private String paymentLabel(String method) {
        if ("Cash".equals(method)) return t("نقدي", "Cash");
        if ("Card".equals(method)) return t("شبكة", "Card");
        if ("Split".equals(method)) return t("كاش + شبكة", "Cash + Card");
        return method == null ? "-" : method;
    }
    private String money(double v) { return String.format(Locale.US,"%.0f SAR",v); }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }

    private TextView heading(String s) {
        TextView v = text(s,25,GRAY); v.setTypeface(Typeface.DEFAULT_BOLD); v.setGravity(arabic?Gravity.RIGHT:Gravity.LEFT); v.setPadding(dp(4),dp(12),dp(4),dp(8)); return v;
    }
    private TextView sectionTitle(String s) {
        TextView v = text(s,18,GRAY); v.setTypeface(Typeface.DEFAULT_BOLD); v.setGravity(arabic?Gravity.RIGHT:Gravity.LEFT); v.setPadding(dp(4),dp(22),dp(4),dp(8)); return v;
    }
    private TextView text(String s,int sp,int color) { TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(color);return v; }

    private EditText field(String hint, boolean phone) {
        EditText e = new EditText(this); e.setHint(hint); e.setTextSize(17); e.setSingleLine(true); e.setPadding(dp(14),0,dp(14),0);
        e.setInputType(phone ? InputType.TYPE_CLASS_PHONE : InputType.TYPE_CLASS_TEXT);
        e.setBackground(round(Color.WHITE, Color.LTGRAY, 12));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)); p.setMargins(0,dp(5),0,dp(5)); e.setLayoutParams(p); return e;
    }
    private EditText numberField(String value) {
        EditText e = field(t("السعر","Price"),false); e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); e.setText(value); return e;
    }
    private LinearLayout labeled(String label, EditText input) {
        LinearLayout r = new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); TextView l=text(label,16,GRAY); l.setGravity(arabic?Gravity.RIGHT:Gravity.LEFT); r.addView(l,new LinearLayout.LayoutParams(0,dp(58),1)); r.addView(input,new LinearLayout.LayoutParams(dp(130),dp(54))); return r;
    }
    private RadioButton radio(String s) { RadioButton r=new RadioButton(this);r.setText(s);r.setTextSize(17);r.setPadding(dp(8),0,dp(8),0);return r; }

    private Button primaryButton(String s) {
        Button b=new Button(this); b.setText(s); b.setTextSize(17); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT_BOLD); b.setBackground(round(RED,RED,14));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(58));p.setMargins(0,dp(6),0,dp(6));b.setLayoutParams(p);return b;
    }
    private Button menuButton(String s) {
        Button b=new Button(this); b.setText(s); b.setTextSize(18); b.setGravity(arabic?Gravity.RIGHT|Gravity.CENTER_VERTICAL:Gravity.LEFT|Gravity.CENTER_VERTICAL); b.setPadding(dp(18),0,dp(18),0); b.setTextColor(GRAY); b.setAllCaps(false); b.setBackground(round(SMOKE,Color.LTGRAY,16));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(72));p.setMargins(0,dp(6),0,dp(6));b.setLayoutParams(p);return b;
    }
    private Button smallButton(String s) { Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setAllCaps(false);b.setTextColor(GRAY);b.setBackground(round(SMOKE,Color.LTGRAY,12));return b; }
    private LinearLayout card() { LinearLayout l=new LinearLayout(this);l.setPadding(dp(12),dp(7),dp(12),dp(7));l.setBackground(round(SMOKE,Color.LTGRAY,14));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);p.setMargins(0,dp(4),0,dp(4));l.setLayoutParams(p);return l; }
    private LinearLayout summaryCard(String title,String value,String subtitle) {
        LinearLayout c=card();c.setOrientation(LinearLayout.VERTICAL);TextView t=text(title,15,Color.GRAY);TextView v=text(value,27,GRAY);v.setTypeface(Typeface.DEFAULT_BOLD);TextView s=text(subtitle,15,Color.GRAY);c.addView(t);c.addView(v);c.addView(s);return c;
    }
    private GradientDrawable round(int fill,int stroke,int radius) { GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g; }
}
