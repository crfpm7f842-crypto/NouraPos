package com.noura.carwash.pos;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int RED = Color.rgb(236,34,36);
    private static final int GRAY = Color.rgb(51,51,51);
    private static final int SMOKE = Color.rgb(242,242,242);

    private DBHelper db;
    private SharedPreferences prefs;
    private SunmiPrinterBridge printer;
    private boolean arabic = true;
    private LinearLayout root;
    private DBHelper.AppUser currentUser;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new DBHelper(this);
        prefs = getSharedPreferences("noura_settings", MODE_PRIVATE);
        arabic = prefs.getBoolean("arabic", true);
        printer = new SunmiPrinterBridge(this);
        printer.connect();
        requestLegacyStoragePermissionIfNeeded();
        bootstrapAccounts();
    }

    private void bootstrapAccounts() {
        if (!db.hasAnyAppUsers()) {
            String oldPin = prefs.getString("admin_pin", "");
            if (oldPin.matches("\\d{4}")) {
                try {
                    long id = db.createManager("المدير", oldPin);
                    prefs.edit().putLong("session_user_id", id).apply();
                } catch (Exception ignored) { }
            }
        }
        long sessionId = prefs.getLong("session_user_id", 0);
        if (sessionId > 0) {
            DBHelper.AppUser session = db.getAppUser(sessionId);
            if (session != null && session.active) currentUser = session;
            else prefs.edit().remove("session_user_id").apply();
        }
        if (!db.hasAnyAppUsers()) showManagerSetup();
        else if (currentUser == null) showLogin();
        else showHome();
    }

    private void showManagerSetup() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18),dp(28),dp(18),dp(18));
        root.setBackgroundColor(Color.WHITE);
        ImageView logo = new ImageView(this); logo.setImageResource(R.drawable.noura_logo); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        root.addView(logo,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(90)));
        root.addView(heading(t("إنشاء حساب المدير", "Create Manager Account")));
        root.addView(text(t("هذا الإعداد يتم مرة واحدة فقط. حساب المدير يملك جميع الصلاحيات.", "This setup is required once. The manager account has all permissions."),15,Color.GRAY));
        EditText name = field(t("اسم المدير", "Manager name"),false); root.addView(name);
        EditText pin = pinField(t("PIN المدير - 4 أرقام", "Manager PIN - 4 digits")); root.addView(pin);
        EditText confirm = pinField(t("تأكيد PIN", "Confirm PIN")); root.addView(confirm);
        Button save = primaryButton(t("إنشاء الحساب", "Create Account")); root.addView(save);
        save.setOnClickListener(v -> {
            String p1=pin.getText().toString().trim(),p2=confirm.getText().toString().trim();
            if(!p1.matches("\\d{4}")){toast(t("PIN يجب أن يكون 4 أرقام","PIN must be 4 digits"));return;}
            if(!p1.equals(p2)){toast(t("رمزا PIN غير متطابقين","PINs do not match"));return;}
            try{
                long id=db.createManager(name.getText().toString(),p1);
                currentUser=db.getAppUser(id);
                prefs.edit().putLong("session_user_id",id).apply();
                LocalBackupManager.backup(this,db);
                showHome();
            }catch(Exception e){toast(t("تعذر إنشاء الحساب","Could not create account"));}
        });
        Button lang=smallButton(arabic?"EN":"عربي");lang.setOnClickListener(v->{arabic=!arabic;prefs.edit().putBoolean("arabic",arabic).apply();showManagerSetup();});
        root.addView(lang,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(48)));
        setContentView(root);
    }

    private void showLogin() {
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(30),dp(18),dp(18));root.setBackgroundColor(Color.WHITE);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.noura_logo);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);root.addView(logo,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(100)));
        root.addView(heading(t("تسجيل الدخول","Login")));
        root.addView(text(t("أدخل رقمك الخاص للدخول","Enter your personal PIN"),16,Color.GRAY));
        EditText pin=pinField(t("PIN من 4 أرقام","4-digit PIN"));root.addView(pin);
        Button login=primaryButton(t("دخول","Login"));root.addView(login);
        login.setOnClickListener(v->{
            DBHelper.AppUser u=db.authenticateUser(pin.getText().toString().trim());
            if(u==null){toast(t("الرقم غير صحيح أو الحساب موقوف","Incorrect PIN or account is disabled"));return;}
            currentUser=u;prefs.edit().putLong("session_user_id",u.id).apply();showHome();
        });
        pin.setOnEditorActionListener((v,actionId,event)->{if(actionId==EditorInfo.IME_ACTION_DONE){login.performClick();return true;}return false;});
        Button lang=smallButton(arabic?"EN":"عربي");lang.setOnClickListener(v->{arabic=!arabic;prefs.edit().putBoolean("arabic",arabic).apply();showLogin();});
        root.addView(lang,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(48)));
        setContentView(root);
        pin.requestFocus();
    }

    private void logout() {
        prefs.edit().remove("session_user_id").apply();
        currentUser=null;
        showLogin();
    }

    private boolean isManager(){return currentUser!=null&&currentUser.isManager();}
    private boolean require(boolean allowed){
        if(currentUser==null){showLogin();return false;}
        if(!allowed){toast(t("ليس لديك صلاحية لهذه العملية","You do not have permission for this action"));return false;}
        return true;
    }

    private void requestLegacyStoragePermissionIfNeeded() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1001);
        }
    }

    @Override protected void onDestroy() {
        printer.disconnect();
        db.close();
        super.onDestroy();
    }

    private String t(String ar,String en){return arabic?ar:en;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}

    private void baseScreen(boolean home) {
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.WHITE);root.setPadding(dp(12),dp(10),dp(12),dp(12));
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setOrientation(LinearLayout.HORIZONTAL);
        if(!home){Button back=smallButton("‹");back.setOnClickListener(v->showHome());header.addView(back,new LinearLayout.LayoutParams(dp(48),dp(48)));}
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.noura_logo);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams lpLogo=new LinearLayout.LayoutParams(0,dp(66),1);lpLogo.setMargins(dp(6),0,dp(6),0);header.addView(logo,lpLogo);
        Button lang=smallButton(arabic?"EN":"عربي");lang.setOnClickListener(v->{arabic=!arabic;prefs.edit().putBoolean("arabic",arabic).apply();showHome();});header.addView(lang,new LinearLayout.LayoutParams(dp(68),dp(46)));
        root.addView(header);setContentView(root);
    }
    private ScrollView contentScroll(){ScrollView sv=new ScrollView(this);root.addView(sv,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));return sv;}
    private LinearLayout stack(ScrollView sv){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(0,dp(8),0,dp(18));sv.addView(box,new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));return box;}

    private void showHome() {
        if(currentUser==null){showLogin();return;}
        currentUser=db.getAppUser(currentUser.id);
        if(currentUser==null||!currentUser.active){logout();return;}
        baseScreen(true);LinearLayout box=stack(contentScroll());
        box.addView(heading(t("كاشير مغسلة نوره","NOURA Car Wash POS")));

        LinearLayout account=card();account.setGravity(Gravity.CENTER_VERTICAL);
        String role=currentUser.isManager()?t("مدير","Manager"):t("موظف","Employee");
        TextView accountText=text(currentUser.name+"  •  "+role,15,GRAY);accountText.setTypeface(Typeface.DEFAULT_BOLD);account.addView(accountText,new LinearLayout.LayoutParams(0,dp(48),1));
        Button logout=smallButton(t("تسجيل خروج","Logout"));logout.setOnClickListener(v->logout());account.addView(logout,new LinearLayout.LayoutParams(dp(105),dp(44)));box.addView(account);

        box.addView(summaryCard(t("غسيل السيارات اليوم","Cars Washed Today"),String.valueOf(db.getTodayWashCount()),t("الفواتير المكتملة اليوم","Completed invoices today")));
        if(currentUser.canNewSale){
            Button order=menuButton("🚗  "+t("فاتورة جديدة","New Order"));order.setOnClickListener(v->showOrder());box.addView(order);
            int pending=db.getPendingCount();
            Button preparing=menuButton("⏱  "+t("قيد التحضير","In Preparation")+" ("+pending+")");preparing.setOnClickListener(v->showPendingOrders());box.addView(preparing);
        }
        if(currentUser.canViewInvoices){Button invoices=menuButton("🧾  "+t("عرض فواتير اليوم","View Today's Invoices"));invoices.setOnClickListener(v->showInvoices());box.addView(invoices);}
        if(currentUser.canReports){Button reports=menuButton("📊  "+t("التقارير وترتيب العمال","Reports & Worker Ranking"));reports.setOnClickListener(v->showReports());box.addView(reports);}
        if(currentUser.canSearch){Button search=menuButton("🔎  "+t("البحث عن فاتورة","Find an Invoice"));search.setOnClickListener(v->showSearch());box.addView(search);}
        if(isManager()){Button admin=menuButton("⚙  "+t("الإدارة والحسابات","Admin & Accounts"));admin.setOnClickListener(v->showAdmin());box.addView(admin);}

        TextView printerState=text((printer.isConnected()?"✓ ":"• ")+t(printer.isConnected()?"طابعة SUNMI متصلة":"سيتم الاتصال بطابعة SUNMI عند توفرها",printer.isConnected()?"SUNMI printer connected":"SUNMI printer will connect when available"),14,Color.GRAY);
        printerState.setPadding(dp(8),dp(20),dp(8),0);box.addView(printerState);
    }

    private void showOrder() {
        if(!require(currentUser!=null && currentUser.canNewSale))return;
        baseScreen(false);LinearLayout box=stack(contentScroll());box.addView(heading(t("فاتورة جديدة","New Order")));
        TextView note=text(t("سيبدأ حساب الوقت عند حفظ الطلب كـ «قيد التحضير». الدفع والتأكيد يكونان بعد انتهاء السيارة.","Timing starts when the order is saved as In Preparation. Payment is completed when the car is finished."),14,Color.GRAY);note.setPadding(dp(4),0,dp(4),dp(8));box.addView(note);

        box.addView(sectionTitle(t("بيانات السيارة والعميل","Car & Customer")));
        EditText plate=plateField();box.addView(plate);
        RadioGroup stayGroup=new RadioGroup(this);stayGroup.setOrientation(LinearLayout.HORIZONTAL);
        RadioButton waiting=radio(t("العميل ينتظر","Customer waiting")),leaving=radio(t("العميل سيغادر","Customer leaving"));
        stayGroup.addView(waiting,new RadioGroup.LayoutParams(0,dp(52),1));stayGroup.addView(leaving,new RadioGroup.LayoutParams(0,dp(52),1));waiting.setChecked(true);box.addView(stayGroup);
        EditText phone=field(t("رقم العميل (إلزامي عند المغادرة)","Customer phone (required if leaving)"),true);phone.setImeOptions(EditorInfo.IME_ACTION_NEXT);box.addView(phone);
        plate.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){if(s.length()==4)phone.requestFocus();}public void afterTextChanged(Editable e){}});

        box.addView(sectionTitle(t("نوع الغسيل","Wash Type")));
        List<DBHelper.WashType> washTypes=db.getWashTypes(true);RadioGroup carGroup=new RadioGroup(this);carGroup.setOrientation(LinearLayout.VERTICAL);
        for(int i=0;i<washTypes.size();i++){DBHelper.WashType wt=washTypes.get(i);String n=arabic?wt.nameAr:wt.nameEn;if(n==null||n.trim().isEmpty())n=arabic?wt.nameEn:wt.nameAr;RadioButton r=radio(n+" - "+money(wt.price));r.setTag(wt);carGroup.addView(r);if(i==0)r.setChecked(true);}
        if(washTypes.isEmpty())box.addView(text(t("لا توجد أنواع غسيل مفعلة","No active wash types"),14,RED));box.addView(carGroup);

        box.addView(sectionTitle(t("العامل المسؤول","Responsible Worker")));
        List<DBHelper.Employee> employees=db.getEmployees(true);Spinner worker=new Spinner(this);worker.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,employees));box.addView(worker,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(54)));
        if(employees.isEmpty())box.addView(text(t("لا يوجد عمال مضافون. أضف العمال من الإدارة أولاً.","No workers yet. Add workers from Admin first."),14,RED));

        box.addView(sectionTitle(t("خدمات إضافية الآن (ويمكن تعديلها عند نهاية الفاتورة)","Additional Services (can also be changed at the end)")));
        List<CheckBox> productChecks=addProductChecks(box,db.getProducts(true),null);

        final String[] discountType={"none"};final double[] discountValue={0};final String[] discountReason={""};
        if(currentUser.canDiscount){
            box.addView(sectionTitle(t("الخصم","Discount")));TextView status=text(t("بدون خصم","No discount"),16,Color.GRAY);box.addView(status);
            Button discount=menuButton(t("إضافة / تعديل الخصم","Add / Edit Discount"));discount.setOnClickListener(v->requestDiscount(discountType,discountValue,discountReason,status));box.addView(discount);
        }

        Button start=primaryButton(t("بدء الفاتورة وإرسالها لقيد التحضير","Start Invoice / In Preparation"));box.addView(start);
        start.setOnClickListener(v->{
            RadioButton selected=findChecked(carGroup);
            if(plate.getText().toString().trim().isEmpty()){toast(t("أدخل رقم اللوحة","Enter plate number"));return;}
            if(leaving.isChecked()&&phone.getText().toString().trim().isEmpty()){toast(t("رقم العميل مطلوب لأنه سيغادر","Customer phone is required when leaving"));return;}
            if(selected==null){toast(t("اختر نوع الغسيل","Choose a wash type"));return;}
            if(employees.isEmpty()||worker.getSelectedItem()==null){toast(t("اختر العامل المسؤول","Choose the responsible worker"));return;}
            DBHelper.WashType wt=(DBHelper.WashType)selected.getTag();DBHelper.Employee emp=(DBHelper.Employee)worker.getSelectedItem();
            String size=wt.nameAr==null||wt.nameAr.trim().isEmpty()?wt.nameEn:wt.nameAr;
            try{
                long id=db.createPendingSale(plate.getText().toString(),phone.getText().toString(),leaving.isChecked(),size,wt.price,emp.id,emp.name,selectedProducts(productChecks),discountType[0],discountValue[0],discountReason[0],currentUser.id,currentUser.name);
                LocalBackupManager.backup(this,db);DBHelper.Sale sale=db.getSale(id);
                new AlertDialog.Builder(this).setTitle(t("تم بدء الفاتورة ✓","Invoice started ✓"))
                        .setMessage(t("اللوحة: ","Plate: ")+sale.plate+"\n"+t("وقت البداية: ","Start: ")+formatDateTime(sale.createdAt)+"\n"+t("الحالة: قيد التحضير","Status: In Preparation"))
                        .setPositiveButton(t("فتح قيد التحضير","Open Preparation"),(d,w)->showPendingOrders())
                        .setNegativeButton(t("الرئيسية","Home"),(d,w)->showHome()).show();
            }catch(Exception e){toast(t("تعذر بدء الفاتورة","Could not start invoice"));}
        });
    }

    private List<CheckBox> addProductChecks(LinearLayout box,List<DBHelper.Product> products,List<DBHelper.Product> selected) {
        List<CheckBox> checks=new ArrayList<>();
        for(DBHelper.Product p:products){
            boolean wasSelected=containsProduct(selected,p.id);
            if(!p.active&&!wasSelected)continue;
            CheckBox cb=new CheckBox(this);cb.setText((arabic?p.nameAr:p.nameEn)+"  •  "+money(p.price));cb.setTextSize(17);cb.setTag(p);cb.setChecked(wasSelected);cb.setPadding(dp(8),dp(4),dp(8),dp(4));box.addView(cb,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(54)));checks.add(cb);
        }
        if(checks.isEmpty())box.addView(text(t("لا توجد خدمات إضافية حالياً","No additional services yet"),14,Color.GRAY));
        return checks;
    }
    private boolean containsProduct(List<DBHelper.Product> list,long id){if(list==null)return false;for(DBHelper.Product p:list)if(p.id==id)return true;return false;}
    private List<DBHelper.Product> selectedProducts(List<CheckBox> checks){List<DBHelper.Product> out=new ArrayList<>();for(CheckBox cb:checks)if(cb.isChecked())out.add((DBHelper.Product)cb.getTag());return out;}

    private void showPendingOrders() {
        if(!require(currentUser!=null && currentUser.canNewSale))return;
        baseScreen(false);LinearLayout box=stack(contentScroll());box.addView(heading(t("فواتير قيد التحضير","Invoices In Preparation")));
        List<DBHelper.Sale> pending=db.getPendingSales();
        if(pending.isEmpty()){box.addView(text(t("لا توجد فواتير قيد التحضير","No invoices in preparation"),16,Color.GRAY));return;}
        for(DBHelper.Sale sale:pending){
            LinearLayout c=card();c.setOrientation(LinearLayout.VERTICAL);
            TextView first=text(sale.plate+"  •  "+sale.workerName,18,GRAY);first.setTypeface(Typeface.DEFAULT_BOLD);c.addView(first);
            c.addView(text(t("بدأت: ","Started: ")+formatDateTime(sale.createdAt)+"  •  "+t("المدة حتى الآن: ","Elapsed: ")+durationText(sale.durationMs()),14,Color.GRAY));
            c.addView(text(t("القيمة الحالية: ","Current total: ")+money(sale.total),14,Color.GRAY));
            Button open=primaryButton(t("فتح / إضافة خدمات / إنهاء","Open / Add Services / Finish"));open.setOnClickListener(v->showPendingOrder(sale.id));c.addView(open);box.addView(c);
        }
    }

    private void showPendingOrder(long id) {
        if(!require(currentUser!=null && currentUser.canNewSale))return;
        DBHelper.Sale sale=db.getSale(id);if(sale==null||!sale.isPending()){toast(t("هذه الفاتورة لم تعد قيد التحضير","This invoice is no longer pending"));showPendingOrders();return;}
        baseScreen(false);LinearLayout box=stack(contentScroll());box.addView(heading(t("إنهاء الفاتورة","Finish Invoice")));
        box.addView(summaryCard(sale.plate,t("بدأت: ","Started: ")+formatDateTime(sale.createdAt),t("المدة حتى الآن: ","Elapsed: ")+durationText(sale.durationMs())));
        box.addView(text(t("العامل: ","Worker: ")+sale.workerName+"  •  "+t("نوع الغسيل: ","Wash: ")+sale.carSize+"  •  "+money(sale.basePrice),15,GRAY));

        box.addView(sectionTitle(t("الخدمات الإضافية","Additional Services")));
        List<CheckBox> checks=addProductChecks(box,db.getProducts(false),sale.items);

        final String[] discountType={sale.discountType==null?"none":sale.discountType};
        final double[] discountValue={sale.discountValue};
        final String[] discountReason={sale.discountReason==null?"":sale.discountReason};
        TextView discountStatus=text(discountValue[0]>0?t("الخصم الحالي: ","Current discount: ")+("percent".equals(discountType[0])?String.format(Locale.US,"%.0f%%",discountValue[0]):money(discountValue[0])):t("بدون خصم","No discount"),15,Color.GRAY);
        if(currentUser.canDiscount){
            box.addView(sectionTitle(t("الخصم","Discount")));box.addView(discountStatus);
            Button discount=menuButton(t("إضافة / تعديل الخصم","Add / Edit Discount"));discount.setOnClickListener(v->requestDiscount(discountType,discountValue,discountReason,discountStatus));box.addView(discount);
            Button clear=smallButton(t("إلغاء الخصم","Clear Discount"));clear.setOnClickListener(v->{discountType[0]="none";discountValue[0]=0;discountReason[0]="";discountStatus.setText(t("بدون خصم","No discount"));});box.addView(clear,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(48)));
        }

        TextView totalPreview=text("",19,GRAY);totalPreview.setTypeface(Typeface.DEFAULT_BOLD);totalPreview.setPadding(dp(4),dp(16),dp(4),dp(6));box.addView(totalPreview);
        Runnable updateTotal=()->totalPreview.setText(t("الإجمالي الحالي: ","Current total: ")+money(calculateTotal(sale.basePrice,checks,discountType[0],discountValue[0])));
        updateTotal.run();
        for(CheckBox cb:checks)cb.setOnCheckedChangeListener((b,c)->updateTotal.run());

        box.addView(sectionTitle(t("إنهاء الفاتورة وطريقة الدفع","Complete Invoice & Payment")));
        Button cash=primaryButton(t("تأكيد - نقدي","Confirm - Cash"));cash.setOnClickListener(v->finishPending(sale,checks,discountType,discountValue,discountReason,"Cash",-1,-1));box.addView(cash);
        Button card=primaryButton(t("تأكيد - شبكة","Confirm - Card"));card.setOnClickListener(v->finishPending(sale,checks,discountType,discountValue,discountReason,"Card",-1,-1));box.addView(card);
        Button split=primaryButton(t("تأكيد - كاش + شبكة","Confirm - Cash + Card"));split.setOnClickListener(v->{
            double total=calculateTotal(sale.basePrice,checks,discountType[0],discountValue[0]);
            requestSplitPayment(total,(c1,c2)->finishPending(sale,checks,discountType,discountValue,discountReason,"Split",c1,c2));
        });box.addView(split);
    }

    private double calculateTotal(double base,List<CheckBox> checks,String type,double value){
        double subtotal=base;for(CheckBox cb:checks)if(cb.isChecked())subtotal+=((DBHelper.Product)cb.getTag()).price;
        double discount=0;if("percent".equals(type))discount=subtotal*Math.max(0,Math.min(100,value))/100.0;else if("fixed".equals(type))discount=Math.max(0,Math.min(subtotal,value));return Math.max(0,subtotal-discount);
    }

    private void finishPending(DBHelper.Sale sale,List<CheckBox> checks,String[] discountType,double[] discountValue,String[] discountReason,String method,double cash,double card){
        try{
            boolean ok=db.completePendingSale(sale.id,selectedProducts(checks),discountType[0],discountValue[0],discountReason[0],method,cash,card,currentUser.id,currentUser.name);
            if(!ok){toast(t("تعذر إنهاء الفاتورة أو تم إنهاؤها مسبقاً","Could not complete invoice or it was already completed"));showPendingOrders();return;}
            LocalBackupManager.backup(this,db);showPaidDialog(db.getSale(sale.id));
        }catch(Exception e){toast(t("تعذر حفظ العملية، تحقق من مبالغ الدفع","Could not save sale; check payment amounts"));}
    }

    private RadioButton findChecked(RadioGroup g){int id=g.getCheckedRadioButtonId();return id==-1?null:g.findViewById(id);}
    private interface SplitPaymentPicked{void onPicked(double cash,double card);}
    private void requestSplitPayment(double total,SplitPaymentPicked callback){
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(18),dp(8),dp(18),0);
        TextView tv=text(t("الإجمالي: ","Total: ")+money(total),19,GRAY);tv.setTypeface(Typeface.DEFAULT_BOLD);form.addView(tv);
        EditText cash=numberField("");cash.setHint(t("المبلغ كاش","Cash amount"));form.addView(cash);EditText card=numberField("");card.setHint(t("المبلغ شبكة","Card amount"));form.addView(card);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(t("تقسيم الدفع","Split Payment")).setView(form).setPositiveButton(t("حفظ","Save"),null).setNegativeButton(t("إلغاء","Cancel"),null).create();
        d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{double c=Double.parseDouble(cash.getText().toString().trim()),k=Double.parseDouble(card.getText().toString().trim());if(c<0||k<0||Math.abs(c+k-total)>0.01){toast(t("مجموع الكاش والشبكة يجب أن يساوي الإجمالي","Cash + card must equal the total"));return;}callback.onPicked(c,k);d.dismiss();}catch(Exception e){toast(t("أدخل مبلغ الكاش ومبلغ الشبكة","Enter cash and card amounts"));}}));d.show();
    }

    private void showPaidDialog(DBHelper.Sale sale){
        AlertDialog d=new AlertDialog.Builder(this).setTitle(t("تم تأكيد الفاتورة ✓","Invoice completed ✓"))
                .setMessage(t("رقم الفاتورة: ","Invoice #: ")+sale.invoiceNo+"\n"+t("من: ","From: ")+formatTime(sale.createdAt)+"  "+t("إلى: ","To: ")+formatTime(sale.completedAt)+"\n"+t("المدة: ","Duration: ")+durationText(sale.durationMs())+"\n"+t("الإجمالي: ","Total: ")+money(sale.total))
                .setPositiveButton(t("طباعة الفاتورة","Print Receipt"),null).setNegativeButton(t("الرئيسية بدون طباعة","Home - No Print"),(x,w)->showHome()).setNeutralButton(t("حفظ كصورة","Save as Image"),null).create();
        d.setOnShowListener(x->{d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{if(printer.printReceipt(sale))toast(t("تم إرسال الفاتورة للطابعة","Receipt sent to printer"));else toast(t("الطابعة غير متصلة حالياً","Printer is not connected"));});d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->saveInvoiceImage(sale,false));});d.show();
    }

    private void showReports() {
        if(!require(currentUser!=null && currentUser.canReports))return;
        baseScreen(false);LinearLayout box=stack(contentScroll());box.addView(heading(t("التقارير","Reports")));
        final long[] range={DBHelper.startOfMonth(),DBHelper.startOfNextMonth()};final long[] custom={DBHelper.startOfToday(),DBHelper.startOfTomorrow()-60_000L};final Calendar monthCursor=Calendar.getInstance();monthCursor.setTimeInMillis(range[0]);
        TextView period=text("",16,GRAY);period.setTypeface(Typeface.DEFAULT_BOLD);period.setGravity(Gravity.CENTER);period.setPadding(dp(4),dp(8),dp(4),dp(8));box.addView(period);
        LinearLayout nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);Button prev=smallButton(t("‹ شهر","‹ Month")),today=smallButton(t("اليوم","Today")),current=smallButton(t("هذا الشهر","This Month")),next=smallButton(t("شهر ›","Month ›"));
        nav.addView(prev,new LinearLayout.LayoutParams(0,dp(52),1));nav.addView(today,new LinearLayout.LayoutParams(0,dp(52),1));nav.addView(current,new LinearLayout.LayoutParams(0,dp(52),1));nav.addView(next,new LinearLayout.LayoutParams(0,dp(52),1));box.addView(nav);
        box.addView(sectionTitle(t("بحث بالتاريخ والوقت","Search by Date & Time")));LinearLayout customRow=new LinearLayout(this);customRow.setOrientation(LinearLayout.HORIZONTAL);Button from=smallButton(""),to=smallButton("");customRow.addView(from,new LinearLayout.LayoutParams(0,dp(58),1));customRow.addView(to,new LinearLayout.LayoutParams(0,dp(58),1));box.addView(customRow);Button applyCustom=primaryButton(t("عرض الفترة المحددة","Show Selected Range"));box.addView(applyCustom);
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);box.addView(body);
        SimpleDateFormat dt=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US);final Runnable[] render=new Runnable[1];
        Runnable labels=()->{from.setText(t("من: ","From: ")+dt.format(new Date(custom[0])));to.setText(t("إلى: ","To: ")+dt.format(new Date(custom[1])));};labels.run();

        render[0]=()->{
            body.removeAllViews();period.setText(dt.format(new Date(range[0]))+"  →  "+dt.format(new Date(Math.max(range[0],range[1]-1))));
            DBHelper.DailySummary s=db.getSummary(range[0],range[1]);
            body.addView(sectionTitle(t("ملخص التقرير","Report Summary")));
            List<String[]> summaryRows=new ArrayList<>();summaryRows.add(new String[]{t("إجمالي المبيعات قبل المرتجع","Gross sales"),money(s.grossSales)});summaryRows.add(new String[]{t("عدد فواتير المرتجع","Refunded invoices"),String.valueOf(s.refundedCars)});summaryRows.add(new String[]{t("قيمة المرتجعات","Refund amount"),money(s.refunds)});summaryRows.add(new String[]{t("صافي المبيعات بعد المرتجع","Net sales"),money(s.sales)});summaryRows.add(new String[]{t("عدد السيارات المغسولة","Cars washed"),String.valueOf(s.totalCars)});body.addView(reportTable(new String[]{t("البند","Item"),t("القيمة","Value")},summaryRows,dp(440)));

            body.addView(sectionTitle(t("تفصيل الكاش والشبكة","Cash & Card Breakdown")));
            List<String[]> payRows=new ArrayList<>();payRows.add(new String[]{t("الكاش قبل المرتجع","Cash gross"),money(s.cashGross)});payRows.add(new String[]{t("مرتجع الكاش","Cash refunds"),money(s.cashRefunds)});payRows.add(new String[]{t("صافي الكاش","Net cash"),money(s.cashNet)});payRows.add(new String[]{t("الشبكة قبل المرتجع","Card gross"),money(s.cardGross)});payRows.add(new String[]{t("مرتجع الشبكة","Card refunds"),money(s.cardRefunds)});payRows.add(new String[]{t("صافي الشبكة","Net card"),money(s.cardNet)});payRows.add(new String[]{t("صافي الكاش + الشبكة","Cash + Card net"),money(s.paymentNet)});body.addView(reportTable(new String[]{t("طريقة الدفع","Payment"),t("القيمة","Value")},payRows,dp(450)));

            body.addView(sectionTitle(t("الأكثر طلباً","Most Requested")));String addon=arabic?s.topAddOnAr:s.topAddOnEn;List<String[]> popular=new ArrayList<>();popular.add(new String[]{t("أكثر إضافة/خدمة","Top add-on/service"),addon==null||addon.isEmpty()?"-":addon+" × "+s.topAddOnCount});popular.add(new String[]{t("أكثر نوع غسيل","Top wash type"),s.topCarSize==null||s.topCarSize.isEmpty()?"-":s.topCarSize+" × "+s.topCarSizeCount});body.addView(reportTable(new String[]{t("البند","Item"),t("النتيجة","Result")},popular,dp(460)));

            body.addView(sectionTitle(t("أداء العمال","Worker Performance")));List<String[]> workers=new ArrayList<>();int rank=1;for(DBHelper.WorkerCount w:s.workerCounts)workers.add(new String[]{String.valueOf(rank++),w.name,String.valueOf(w.count),String.valueOf(w.refundCount)});body.addView(reportTable(new String[]{"#",t("العامل","Worker"),t("الغسلات","Washes"),t("مرتجع","Refunds")},workers,dp(560)));

            body.addView(sectionTitle(t("تفاصيل الأيام","Daily Breakdown")));List<String[]> days=new ArrayList<>();SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd",Locale.US);for(DBHelper.DaySummary d:db.getDailyBreakdown(range[0],range[1])){DBHelper.DailySummary x=d.summary;days.add(new String[]{df.format(new Date(d.dayStart)),String.valueOf(x.cars),money(x.grossSales),money(x.refunds),money(x.sales)});}body.addView(reportTable(new String[]{t("التاريخ","Date"),t("السيارات","Cars"),t("الإجمالي","Gross"),t("المرتجع","Refunds"),t("الصافي","Net")},days,dp(760)));

            body.addView(sectionTitle(t("طباعة وحفظ التقرير","Print & Save Report")));
            Button print=primaryButton(t("طباعة التقرير A4","Print A4 Report"));print.setOnClickListener(v->{try{File f=DocumentExporter.createReportPdf(this,db,range[0],range[1],t("تقرير مغسلة نوره","NOURA Car Wash Report"),arabic);DocumentExporter.printPdf(this,f,"Noura Report");}catch(Exception e){toast(t("تعذر إنشاء التقرير","Could not create report"));}});body.addView(print);
            Button save=menuButton(t("حفظ التقرير PDF على الجهاز","Save Report as PDF"));save.setOnClickListener(v->{try{File f=DocumentExporter.createReportPdf(this,db,range[0],range[1],t("تقرير مغسلة نوره","NOURA Car Wash Report"),arabic);String n=DocumentExporter.saveReportPdfToDevice(this,f);toast(t("تم حفظ التقرير: ","Saved report: ")+n);}catch(Exception e){toast(t("تعذر حفظ التقرير","Could not save report"));}});body.addView(save);
            Button share=menuButton(t("مشاركة التقرير / إيميل","Share Report / Email"));share.setOnClickListener(v->{try{File f=DocumentExporter.createReportPdf(this,db,range[0],range[1],t("تقرير مغسلة نوره","NOURA Car Wash Report"),arabic);DocumentExporter.shareFile(this,f,"application/pdf",t("مشاركة التقرير","Share Report"));}catch(Exception e){toast(t("تعذر مشاركة التقرير","Could not share report"));}});body.addView(share);
        };
        prev.setOnClickListener(v->{monthCursor.add(Calendar.MONTH,-1);range[0]=DBHelper.startOfMonth(monthCursor.getTimeInMillis());range[1]=DBHelper.startOfNextMonth(monthCursor.getTimeInMillis());render[0].run();});
        next.setOnClickListener(v->{monthCursor.add(Calendar.MONTH,1);range[0]=DBHelper.startOfMonth(monthCursor.getTimeInMillis());range[1]=DBHelper.startOfNextMonth(monthCursor.getTimeInMillis());render[0].run();});
        today.setOnClickListener(v->{range[0]=DBHelper.startOfToday();range[1]=DBHelper.startOfTomorrow();render[0].run();});
        current.setOnClickListener(v->{monthCursor.setTimeInMillis(System.currentTimeMillis());range[0]=DBHelper.startOfMonth();range[1]=DBHelper.startOfNextMonth();render[0].run();});
        from.setOnClickListener(v->pickDateTime(custom[0],value->{custom[0]=value;labels.run();}));to.setOnClickListener(v->pickDateTime(custom[1],value->{custom[1]=value;labels.run();}));
        applyCustom.setOnClickListener(v->{if(custom[1]<=custom[0]){toast(t("وقت النهاية يجب أن يكون بعد البداية","End time must be after start time"));return;}range[0]=custom[0];range[1]=custom[1]+60_000L;render[0].run();});
        render[0].run();
    }

    private View reportTable(String[] headers,List<String[]> rows,int minWidth){
        HorizontalScrollView scroll=new HorizontalScrollView(this);TableLayout table=new TableLayout(this);table.setMinimumWidth(minWidth);int cellWidth=Math.max(dp(88),minWidth/Math.max(1,headers.length));table.addView(reportTableRow(headers,true,cellWidth));
        if(rows==null||rows.isEmpty()){String[] empty=new String[headers.length];for(int i=0;i<empty.length;i++)empty[i]=i==0?t("لا توجد بيانات","No data"):"-";table.addView(reportTableRow(empty,false,cellWidth));}else for(String[] row:rows)table.addView(reportTableRow(row,false,cellWidth));
        scroll.addView(table,new HorizontalScrollView.LayoutParams(minWidth,ViewGroup.LayoutParams.WRAP_CONTENT));return scroll;
    }
    private TableRow reportTableRow(String[] values,boolean header,int cellWidth){TableRow row=new TableRow(this);for(String value:values){TextView cell=text(value==null?"":value,header?14:13,GRAY);cell.setGravity(Gravity.CENTER);cell.setPadding(dp(8),dp(10),dp(8),dp(10));if(header)cell.setTypeface(Typeface.DEFAULT_BOLD);cell.setBackground(round(header?SMOKE:Color.WHITE,Color.LTGRAY,0));row.addView(cell,new TableRow.LayoutParams(cellWidth,ViewGroup.LayoutParams.WRAP_CONTENT));}return row;}

    private void showInvoices(){
        if(!require(currentUser!=null && currentUser.canViewInvoices))return;
        baseScreen(false);LinearLayout box=stack(contentScroll());box.addView(heading(t("فواتير اليوم","Today's Invoices")));
        List<DBHelper.Sale> sales=db.getSalesInRange(DBHelper.startOfToday(),DBHelper.startOfTomorrow(),0);if(sales.isEmpty()){box.addView(text(t("لا توجد فواتير اليوم","No invoices today"),16,Color.GRAY));return;}
        for(DBHelper.Sale sale:sales){LinearLayout c=card();c.setOrientation(LinearLayout.VERTICAL);String state=sale.refunded?"  •  "+t("مرتجع","REFUNDED"):"";TextView first=text(t("فاتورة #","Invoice #")+sale.invoiceNo+"  •  "+sale.plate+"  •  "+money(sale.total)+state,17,sale.refunded?RED:GRAY);first.setTypeface(Typeface.DEFAULT_BOLD);c.addView(first);c.addView(text(formatTime(sale.completedAt)+"  •  "+sale.workerName+"  •  "+durationText(sale.durationMs()),14,Color.GRAY));Button details=smallButton(t("التفاصيل","Details"));details.setOnClickListener(v->showSaleDetails(sale.id));c.addView(details);box.addView(c);}
    }

    private void showSearch(){
        if(!require(currentUser!=null && currentUser.canSearch))return;
        baseScreen(false);LinearLayout box=stack(contentScroll());box.addView(heading(t("البحث عن فاتورة","Find an Invoice")));EditText q=field(t("رقم الفاتورة أو اللوحة أو رقم العميل","Invoice #, plate or customer phone"),false);box.addView(q);Button go=primaryButton(t("بحث","Search"));box.addView(go);LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);box.addView(results);
        go.setOnClickListener(v->{results.removeAllViews();String query=q.getText().toString().trim();if(query.isEmpty()){toast(t("اكتب رقم الفاتورة أو اللوحة أو الجوال","Enter invoice #, plate or phone"));return;}List<DBHelper.Sale> sales=db.searchSales(query,100);if(sales.isEmpty()){results.addView(text(t("لا توجد نتائج","No results"),16,Color.GRAY));return;}for(DBHelper.Sale sale:sales){LinearLayout c=card();c.setOrientation(LinearLayout.VERTICAL);String state=sale.refunded?" • "+t("مرتجع","REFUNDED"):"";TextView first=text("#"+sale.invoiceNo+" • "+sale.plate+" • "+money(sale.total)+state,17,sale.refunded?RED:GRAY);first.setTypeface(Typeface.DEFAULT_BOLD);c.addView(first);c.addView(text(formatDateTime(sale.completedAt)+" • "+sale.workerName,14,Color.GRAY));Button d=smallButton(t("التفاصيل","Details"));d.setOnClickListener(x->showSaleDetails(sale.id));c.addView(d);results.addView(c);}});
    }

    private void showSaleDetails(long id){
        DBHelper.Sale s=db.getSale(id);if(s==null)return;StringBuilder b=new StringBuilder();if(s.refunded)b.append(t("الحالة: مرتجع","Status: REFUNDED")).append("\n\n");
        b.append(t("اللوحة: ","Plate: ")).append(s.plate).append("\n");b.append(t("العامل: ","Worker: ")).append(s.workerName).append("\n");b.append(t("نوع الغسيل: ","Wash type: ")).append(s.carSize).append("\n");
        b.append(t("وقت البداية: ","Start time: ")).append(formatDateTime(s.createdAt)).append("\n");b.append(t("وقت النهاية: ","End time: ")).append(formatDateTime(s.completedAt)).append("\n");b.append(t("مدة الخدمة: ","Service duration: ")).append(durationText(s.durationMs())).append("\n");
        if(s.createdByUserName!=null&&!s.createdByUserName.isEmpty())b.append(t("فتحها المستخدم: ","Started by: ")).append(s.createdByUserName).append("\n");if(s.completedByUserName!=null&&!s.completedByUserName.isEmpty())b.append(t("أنهاها المستخدم: ","Completed by: ")).append(s.completedByUserName).append("\n");
        for(DBHelper.Product x:s.items)b.append("• ").append(arabic?x.nameAr:x.nameEn).append(" - ").append(money(x.price)).append("\n");
        b.append(t("المجموع قبل الخصم: ","Subtotal: ")).append(money(s.subtotal)).append("\n");if(s.discountAmount>0){String dsc="percent".equals(s.discountType)?String.format(Locale.US,"%.0f%%",s.discountValue):money(s.discountValue);b.append(t("الخصم: ","Discount: ")).append(dsc).append(" (-").append(money(s.discountAmount)).append(")\n");if(s.discountReason!=null&&!s.discountReason.trim().isEmpty())b.append(t("سبب الخصم: ","Discount reason: ")).append(s.discountReason).append("\n");}
        b.append(t("طريقة الدفع: ","Payment: ")).append(paymentLabel(s.paymentMethod)).append("\n");b.append(t("كاش: ","Cash: ")).append(money(s.cashAmount)).append("\n");b.append(t("شبكة: ","Card: ")).append(money(s.cardAmount)).append("\n");b.append(t("الإجمالي: ","Total: ")).append(money(s.total));
        if(s.refunded){b.append("\n\n").append(t("وقت المرتجع: ","Refunded at: ")).append(formatDateTime(s.refundedAt));if(s.refundReason!=null&&!s.refundReason.isEmpty())b.append("\n").append(t("سبب المرتجع: ","Refund reason: ")).append(s.refundReason);}
        AlertDialog d=new AlertDialog.Builder(this).setTitle(t("تفاصيل الفاتورة #","Invoice #")+s.invoiceNo).setMessage(b.toString()).setPositiveButton(t("طباعة","Print"),null).setNeutralButton(t("خيارات","Options"),null).setNegativeButton(t("إغلاق","Close"),null).create();
        d.setOnShowListener(x->{d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{if(!printer.printReceipt(s))toast(t("الطابعة غير متصلة","Printer not connected"));});d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->showInvoiceActions(s));});d.show();
    }

    private void showInvoiceActions(DBHelper.Sale sale){
        List<String> labels=new ArrayList<>();labels.add(t("حفظ الفاتورة كصورة","Save Invoice as Image"));labels.add(t("مشاركة صورة الفاتورة","Share Invoice Image"));if(!sale.refunded&&currentUser!=null&&currentUser.canRefund)labels.add(t("تسجيل الفاتورة كمرتجع","Mark Invoice as Refunded"));
        new AlertDialog.Builder(this).setTitle(t("خيارات الفاتورة","Invoice Options")).setItems(labels.toArray(new String[0]),(d,which)->{if(which==0)saveInvoiceImage(sale,false);else if(which==1)saveInvoiceImage(sale,true);else if(!sale.refunded&&currentUser!=null&&currentUser.canRefund)requestRefund(sale);}).setNegativeButton(t("إلغاء","Cancel"),null).show();
    }
    private void saveInvoiceImage(DBHelper.Sale sale,boolean share){try{if(share){File f=DocumentExporter.saveReceiptImage(this,sale);DocumentExporter.shareFile(this,f,"image/png",t("مشاركة الفاتورة","Share Invoice"));}else{String name=DocumentExporter.saveReceiptImageToDevice(this,sale);toast(t("تم حفظ الفاتورة: ","Saved invoice: ")+name);}}catch(Exception e){toast(t("تعذر حفظ صورة الفاتورة","Could not save invoice image"));}}
    private void requestRefund(DBHelper.Sale sale){
        if(!require(currentUser!=null && currentUser.canRefund))return;EditText reason=field(t("سبب المرتجع (اختياري)","Refund reason (optional)"),false);
        new AlertDialog.Builder(this).setTitle(t("تأكيد مرتجع الفاتورة #","Refund Invoice #")+sale.invoiceNo).setView(reason).setPositiveButton(t("تأكيد المرتجع","Confirm Refund"),(x,y)->{if(db.refundSale(sale.id,reason.getText().toString())){LocalBackupManager.backup(this,db);toast(t("تم تسجيل الفاتورة كمرتجع بدون حذفها","Invoice marked refunded and kept in records"));showSaleDetails(sale.id);}else toast(t("الفاتورة مرتجعة مسبقاً","Invoice is already refunded"));}).setNegativeButton(t("إلغاء","Cancel"),null).show();
    }

    private interface TimePicked{void onPicked(long value);}
    private void pickDateTime(long initial,TimePicked callback){Calendar c=Calendar.getInstance();c.setTimeInMillis(initial);new DatePickerDialog(this,(view,year,month,day)->{Calendar picked=Calendar.getInstance();picked.set(year,month,day,c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),0);picked.set(Calendar.MILLISECOND,0);new TimePickerDialog(this,(tv,hour,minute)->{picked.set(Calendar.HOUR_OF_DAY,hour);picked.set(Calendar.MINUTE,minute);callback.onPicked(picked.getTimeInMillis());},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show();},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}

    private void requestDiscount(final String[] type,final double[] value,final String[] reason,final TextView status){if(!require(currentUser!=null && currentUser.canDiscount))return;showDiscountEditor(type,value,reason,status);}
    private void showDiscountEditor(final String[] type,final double[] value,final String[] reason,final TextView status){
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(18),dp(8),dp(18),0);RadioGroup group=new RadioGroup(this);RadioButton percent=radio(t("نسبة مئوية %","Percentage %"));percent.setTag("percent");RadioButton fixed=radio(t("مبلغ ثابت (ريال)","Fixed amount (SAR)"));fixed.setTag("fixed");group.addView(percent);group.addView(fixed);if("fixed".equals(type[0]))fixed.setChecked(true);else percent.setChecked(true);form.addView(group);
        EditText amount=numberField(value[0]>0?String.valueOf(value[0]):"");amount.setHint(t("قيمة الخصم","Discount value"));form.addView(amount);EditText why=field(t("سبب الخصم *","Discount reason *"),false);why.setText(reason[0]);form.addView(why);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(t("الخصم","Discount")).setView(form).setPositiveButton(t("حفظ","Save"),null).setNegativeButton(t("إلغاء","Cancel"),null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{double av=Double.parseDouble(amount.getText().toString());RadioButton selected=findChecked(group);String st=selected==null?"percent":(String)selected.getTag();String rs=why.getText().toString().trim();if(av<=0||("percent".equals(st)&&av>100)){toast(t("تأكد من قيمة الخصم","Check the discount value"));return;}if(rs.isEmpty()){toast(t("اكتب سبب الخصم","Enter a discount reason"));return;}type[0]=st;value[0]=av;reason[0]=rs;status.setText(t("خصم ","Discount ")+("percent".equals(st)?String.format(Locale.US,"%.0f%%",av):money(av))+" • "+rs);d.dismiss();}catch(Exception e){toast(t("تأكد من قيمة الخصم","Check the discount value"));}}));d.show();
    }

    private void showAdmin(){
        if(!require(isManager()))return;
        baseScreen(false);LinearLayout box=stack(contentScroll());box.addView(heading(t("الإدارة","Admin")));

        box.addView(sectionTitle(t("حسابات الدخول والصلاحيات","Login Accounts & Permissions")));
        box.addView(text(t("حساب المدير يملك جميع الصلاحيات. يمكنك إضافة عدد غير محدود من حسابات الموظفين وتحديد صلاحية كل حساب.","The manager has all permissions. Add unlimited employee accounts and choose each account's permissions."),14,Color.GRAY));
        Button addAccount=primaryButton(t("إضافة حساب موظف","Add Employee Account"));addAccount.setOnClickListener(v->showAddUserDialog());box.addView(addAccount);
        LinearLayout users=new LinearLayout(this);users.setOrientation(LinearLayout.VERTICAL);box.addView(users);renderAppUsers(users);

        box.addView(sectionTitle(t("أسعار الغسيل","Wash Prices")));
        EditText washAr=field("اسم نوع الغسيل بالعربي",false),washEn=field("Wash type name in English",false),washPrice=numberField("");washPrice.setHint(t("السعر","Price"));box.addView(washAr);box.addView(washEn);box.addView(washPrice);Button addWash=primaryButton(t("إضافة نوع غسيل","Add Wash Type"));box.addView(addWash);LinearLayout washList=new LinearLayout(this);washList.setOrientation(LinearLayout.VERTICAL);box.addView(washList);Runnable rw=()->renderWashTypes(washList);addWash.setOnClickListener(v->{try{String a=washAr.getText().toString().trim(),e=washEn.getText().toString().trim();if(a.isEmpty()){toast(t("اكتب اسم نوع الغسيل","Enter wash type name"));return;}if(e.isEmpty())e=a;db.addWashType(a,e,Double.parseDouble(washPrice.getText().toString()));washAr.setText("");washEn.setText("");washPrice.setText("");LocalBackupManager.backup(this,db);rw.run();}catch(Exception ex){toast(t("تأكد من الاسم والسعر","Check name and price"));}});rw.run();

        box.addView(sectionTitle(t("عمال الغسيل","Wash Workers")));EditText workerName=field(t("اسم العامل","Worker name"),false);box.addView(workerName);Button addWorker=primaryButton(t("إضافة عامل","Add Worker"));box.addView(addWorker);LinearLayout workers=new LinearLayout(this);workers.setOrientation(LinearLayout.VERTICAL);box.addView(workers);Runnable rworkers=()->renderWorkers(workers);addWorker.setOnClickListener(v->{if(workerName.getText().toString().trim().isEmpty())return;db.addEmployee(workerName.getText().toString());workerName.setText("");LocalBackupManager.backup(this,db);rworkers.run();});rworkers.run();

        box.addView(sectionTitle(t("المنتجات والخدمات الإضافية","Products & Additional Services")));EditText ar=field("الاسم بالعربي",false),en=field("English name",false),price=numberField("");price.setHint(t("السعر","Price"));box.addView(ar);box.addView(en);box.addView(price);Button addProduct=primaryButton(t("إضافة خدمة","Add Service"));box.addView(addProduct);LinearLayout products=new LinearLayout(this);products.setOrientation(LinearLayout.VERTICAL);box.addView(products);Runnable rp=()->renderProducts(products);addProduct.setOnClickListener(v->{try{if(ar.getText().toString().trim().isEmpty()||en.getText().toString().trim().isEmpty()){toast(t("اكتب اسم الخدمة بالعربي والإنجليزي","Enter Arabic and English names"));return;}db.addProduct(ar.getText().toString(),en.getText().toString(),Double.parseDouble(price.getText().toString()));ar.setText("");en.setText("");price.setText("");LocalBackupManager.backup(this,db);rp.run();}catch(Exception e){toast(t("تأكد من السعر","Check the price"));}});rp.run();

        box.addView(sectionTitle(t("الأمان والنسخ الاحتياطي","Security & Backup")));Button pin=menuButton(t("تغيير PIN المدير","Change Manager PIN"));pin.setOnClickListener(v->changePin());box.addView(pin);TextView backup=text(t("✓ يتم إنشاء نسخة احتياطية محلية تلقائياً بعد كل عملية أو تعديل.","✓ A local backup is created automatically after each sale or edit."),14,Color.GRAY);backup.setPadding(dp(8),dp(10),dp(8),dp(12));box.addView(backup);
    }

    private void showAddUserDialog(){
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(18),dp(8),dp(18),0);EditText name=field(t("اسم الموظف","Employee name"),false),pin=pinField(t("PIN من 4 أرقام","4-digit PIN"));form.addView(name);form.addView(pin);
        CheckBox sale=permissionCheck(t("إنشاء وإنهاء الفواتير + قيد التحضير","Create/complete invoices + preparation"),true),inv=permissionCheck(t("عرض فواتير اليوم","View today's invoices"),true),reports=permissionCheck(t("عرض التقارير","View reports"),false),search=permissionCheck(t("البحث عن الفواتير","Search invoices"),true),refund=permissionCheck(t("تنفيذ المرتجع","Process refunds"),false),discount=permissionCheck(t("إضافة الخصومات","Apply discounts"),false);
        form.addView(sale);form.addView(inv);form.addView(reports);form.addView(search);form.addView(refund);form.addView(discount);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(t("حساب موظف جديد","New Employee Account")).setView(form).setPositiveButton(t("إضافة","Add"),null).setNegativeButton(t("إلغاء","Cancel"),null).create();
        d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String n=name.getText().toString().trim(),p=pin.getText().toString().trim();if(n.isEmpty()){toast(t("اكتب اسم الموظف","Enter employee name"));return;}if(!p.matches("\\d{4}")){toast(t("PIN يجب أن يكون 4 أرقام","PIN must be 4 digits"));return;}try{db.addAppUser(n,p,sale.isChecked(),inv.isChecked(),reports.isChecked(),search.isChecked(),refund.isChecked(),discount.isChecked());LocalBackupManager.backup(this,db);d.dismiss();showAdmin();}catch(Exception e){toast(t("تعذر إضافة الحساب. تأكد أن PIN غير مستخدم.","Could not add account. Make sure the PIN is unique."));}}));d.show();
    }
    private CheckBox permissionCheck(String label,boolean checked){CheckBox c=new CheckBox(this);c.setText(label);c.setChecked(checked);c.setTextSize(15);return c;}

    private void renderAppUsers(LinearLayout list){
        list.removeAllViews();for(DBHelper.AppUser u:db.getAppUsers()){LinearLayout row=card();row.setGravity(Gravity.CENTER_VERTICAL);String label=u.name+" • "+(u.isManager()?t("مدير","Manager"):t("موظف","Employee"));TextView n=text(label,16,GRAY);row.addView(n,new LinearLayout.LayoutParams(0,dp(54),1));if(u.isManager()){TextView all=text(t("كل الصلاحيات","All"),13,RED);row.addView(all);}else{Button edit=smallButton(t("الصلاحيات","Permissions"));edit.setOnClickListener(v->editAppUser(u));row.addView(edit);Switch sw=new Switch(this);sw.setChecked(u.active);sw.setOnCheckedChangeListener((b,c)->{db.setAppUserActive(u.id,c);LocalBackupManager.backup(this,db);});row.addView(sw);}list.addView(row);}
    }
    private void editAppUser(DBHelper.AppUser u){
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(18),dp(8),dp(18),0);EditText name=field(t("اسم الموظف","Employee name"),false);name.setText(u.name);EditText pin=pinField(t("PIN جديد (اتركه فارغاً بدون تغيير)","New PIN (leave blank to keep current)"));form.addView(name);form.addView(pin);
        CheckBox sale=permissionCheck(t("إنشاء وإنهاء الفواتير + قيد التحضير","Create/complete invoices + preparation"),u.canNewSale),inv=permissionCheck(t("عرض فواتير اليوم","View today's invoices"),u.canViewInvoices),reports=permissionCheck(t("عرض التقارير","View reports"),u.canReports),search=permissionCheck(t("البحث عن الفواتير","Search invoices"),u.canSearch),refund=permissionCheck(t("تنفيذ المرتجع","Process refunds"),u.canRefund),discount=permissionCheck(t("إضافة الخصومات","Apply discounts"),u.canDiscount);form.addView(sale);form.addView(inv);form.addView(reports);form.addView(search);form.addView(refund);form.addView(discount);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(t("تعديل حساب الموظف","Edit Employee Account")).setView(form).setPositiveButton(t("حفظ","Save"),null).setNegativeButton(t("إلغاء","Cancel"),null).create();
        d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String n=name.getText().toString().trim(),p=pin.getText().toString().trim();if(n.isEmpty()){toast(t("اكتب الاسم","Enter name"));return;}if(!p.isEmpty()&&!p.matches("\\d{4}")){toast(t("PIN يجب أن يكون 4 أرقام","PIN must be 4 digits"));return;}try{db.updateAppUser(u.id,n,sale.isChecked(),inv.isChecked(),reports.isChecked(),search.isChecked(),refund.isChecked(),discount.isChecked());if(!p.isEmpty())db.updateUserPin(u.id,p);LocalBackupManager.backup(this,db);d.dismiss();showAdmin();}catch(Exception e){toast(t("تعذر الحفظ. قد يكون PIN مستخدماً.","Could not save. PIN may already be in use."));}}));d.show();
    }

    private void renderWorkers(LinearLayout list){list.removeAllViews();for(DBHelper.Employee e:db.getEmployees(false)){LinearLayout row=card();row.setGravity(Gravity.CENTER_VERTICAL);TextView name=text(e.name,17,GRAY);row.addView(name,new LinearLayout.LayoutParams(0,dp(52),1));Button edit=smallButton(t("تعديل","Edit"));edit.setOnClickListener(v->editEmployee(e));row.addView(edit);Switch sw=new Switch(this);sw.setChecked(e.active);sw.setOnCheckedChangeListener((b,c)->{db.setEmployeeActive(e.id,c);LocalBackupManager.backup(this,db);});row.addView(sw);list.addView(row);}}
    private void editEmployee(DBHelper.Employee e){EditText f=new EditText(this);f.setText(e.name);new AlertDialog.Builder(this).setTitle(t("تعديل العامل","Edit Worker")).setView(f).setPositiveButton(t("حفظ","Save"),(d,w)->{if(!f.getText().toString().trim().isEmpty()){db.updateEmployee(e.id,f.getText().toString());LocalBackupManager.backup(this,db);showAdmin();}}).setNegativeButton(t("إلغاء","Cancel"),null).show();}
    private void renderWashTypes(LinearLayout list){list.removeAllViews();for(DBHelper.WashType wt:db.getWashTypes(false)){LinearLayout row=card();row.setGravity(Gravity.CENTER_VERTICAL);String name=arabic?wt.nameAr:wt.nameEn;if(name==null||name.trim().isEmpty())name=arabic?wt.nameEn:wt.nameAr;TextView n=text(name+" • "+money(wt.price),16,GRAY);row.addView(n,new LinearLayout.LayoutParams(0,dp(56),1));Button edit=smallButton(t("تعديل","Edit"));edit.setOnClickListener(v->editWashType(wt));row.addView(edit);Switch sw=new Switch(this);sw.setChecked(wt.active);sw.setOnCheckedChangeListener((b,c)->{db.setWashTypeActive(wt.id,c);LocalBackupManager.backup(this,db);});row.addView(sw);list.addView(row);}}
    private void editWashType(DBHelper.WashType wt){LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(18),dp(8),dp(18),0);EditText ar=field("اسم نوع الغسيل بالعربي",false);ar.setText(wt.nameAr);EditText en=field("Wash type name in English",false);en.setText(wt.nameEn);EditText price=numberField(String.valueOf(wt.price));form.addView(ar);form.addView(en);form.addView(price);new AlertDialog.Builder(this).setTitle(t("تعديل نوع الغسيل","Edit Wash Type")).setView(form).setPositiveButton(t("حفظ","Save"),(d,w)->{try{String a=ar.getText().toString().trim(),e=en.getText().toString().trim();if(a.isEmpty())return;if(e.isEmpty())e=a;db.updateWashType(wt.id,a,e,Double.parseDouble(price.getText().toString()));LocalBackupManager.backup(this,db);showAdmin();}catch(Exception ex){toast(t("تأكد من البيانات","Check details"));}}).setNegativeButton(t("إلغاء","Cancel"),null).show();}
    private void renderProducts(LinearLayout list){list.removeAllViews();for(DBHelper.Product p:db.getProducts(false)){LinearLayout row=card();row.setGravity(Gravity.CENTER_VERTICAL);TextView n=text((arabic?p.nameAr:p.nameEn)+" • "+money(p.price),16,GRAY);row.addView(n,new LinearLayout.LayoutParams(0,dp(56),1));Button edit=smallButton(t("تعديل","Edit"));edit.setOnClickListener(v->editProduct(p));row.addView(edit);Switch sw=new Switch(this);sw.setChecked(p.active);sw.setOnCheckedChangeListener((b,c)->{db.setProductActive(p.id,c);LocalBackupManager.backup(this,db);});row.addView(sw);list.addView(row);}}
    private void editProduct(DBHelper.Product p){LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(18),dp(8),dp(18),0);EditText ar=field("الاسم بالعربي",false);ar.setText(p.nameAr);EditText en=field("English name",false);en.setText(p.nameEn);EditText price=numberField(String.valueOf(p.price));form.addView(ar);form.addView(en);form.addView(price);new AlertDialog.Builder(this).setTitle(t("تعديل الخدمة","Edit Service")).setView(form).setPositiveButton(t("حفظ","Save"),(d,w)->{try{db.updateProduct(p.id,ar.getText().toString(),en.getText().toString(),Double.parseDouble(price.getText().toString()));LocalBackupManager.backup(this,db);showAdmin();}catch(Exception ex){toast(t("تأكد من البيانات","Check details"));}}).setNegativeButton(t("إلغاء","Cancel"),null).show();}

    private void changePin(){
        EditText f=pinField(t("PIN جديد من 4 أرقام","New 4-digit PIN"));new AlertDialog.Builder(this).setTitle(t("تغيير PIN المدير","Change Manager PIN")).setView(f).setPositiveButton(t("حفظ","Save"),(d,w)->{String x=f.getText().toString().trim();if(!x.matches("\\d{4}")){toast(t("يجب أن يكون 4 أرقام","Must be 4 digits"));return;}try{db.updateUserPin(currentUser.id,x);LocalBackupManager.backup(this,db);toast(t("تم تغيير الرمز","PIN changed"));}catch(Exception e){toast(t("هذا PIN مستخدم لحساب آخر","This PIN is used by another account"));}}).setNegativeButton(t("إلغاء","Cancel"),null).show();
    }

    private String paymentLabel(String method){if("Cash".equals(method))return t("نقدي","Cash");if("Card".equals(method))return t("شبكة","Card");if("Split".equals(method))return t("كاش + شبكة","Cash + Card");return method==null?"-":method;}
    private String money(double v){return String.format(Locale.US,"%.0f SAR",v);}
    private String formatTime(long v){return new SimpleDateFormat("HH:mm",Locale.US).format(new Date(v));}
    private String formatDateTime(long v){return v<=0?"-":new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date(v));}
    private String durationText(long ms){long totalMinutes=Math.max(0,ms/60_000L),h=totalMinutes/60,m=totalMinutes%60;if(h>0)return h+t(" س "," h ")+m+t(" د"," m");return m+t(" دقيقة"," min");}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    private TextView heading(String s){TextView v=text(s,25,GRAY);v.setTypeface(Typeface.DEFAULT_BOLD);v.setGravity(arabic?Gravity.RIGHT:Gravity.LEFT);v.setPadding(dp(4),dp(12),dp(4),dp(8));return v;}
    private TextView sectionTitle(String s){TextView v=text(s,18,GRAY);v.setTypeface(Typeface.DEFAULT_BOLD);v.setGravity(arabic?Gravity.RIGHT:Gravity.LEFT);v.setPadding(dp(4),dp(22),dp(4),dp(8));return v;}
    private TextView text(String s,int sp,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(color);return v;}
    private EditText field(String hint,boolean phone){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(17);e.setSingleLine(true);e.setPadding(dp(14),0,dp(14),0);e.setInputType(phone?InputType.TYPE_CLASS_PHONE:InputType.TYPE_CLASS_TEXT);e.setBackground(round(Color.WHITE,Color.LTGRAY,12));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(56));p.setMargins(0,dp(5),0,dp(5));e.setLayoutParams(p);return e;}
    private EditText plateField(){EditText e=field(t("رقم اللوحة *","Plate number *"),false);e.setInputType(InputType.TYPE_CLASS_NUMBER);e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4)});e.setImeOptions(EditorInfo.IME_ACTION_NEXT);return e;}
    private EditText pinField(String hint){EditText e=field(hint,false);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4)});e.setImeOptions(EditorInfo.IME_ACTION_DONE);return e;}
    private EditText numberField(String value){EditText e=field(t("السعر","Price"),false);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);e.setText(value);return e;}
    private RadioButton radio(String s){RadioButton r=new RadioButton(this);r.setText(s);r.setTextSize(17);r.setPadding(dp(8),0,dp(8),0);return r;}
    private Button primaryButton(String s){Button b=new Button(this);b.setText(s);b.setTextSize(17);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT_BOLD);b.setBackground(round(RED,RED,14));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(58));p.setMargins(0,dp(6),0,dp(6));b.setLayoutParams(p);return b;}
    private Button menuButton(String s){Button b=new Button(this);b.setText(s);b.setTextSize(18);b.setGravity(arabic?Gravity.RIGHT|Gravity.CENTER_VERTICAL:Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setPadding(dp(18),0,dp(18),0);b.setTextColor(GRAY);b.setAllCaps(false);b.setBackground(round(SMOKE,Color.LTGRAY,16));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(72));p.setMargins(0,dp(6),0,dp(6));b.setLayoutParams(p);return b;}
    private Button smallButton(String s){Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setAllCaps(false);b.setTextColor(GRAY);b.setBackground(round(SMOKE,Color.LTGRAY,12));return b;}
    private LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setPadding(dp(12),dp(7),dp(12),dp(7));l.setBackground(round(SMOKE,Color.LTGRAY,14));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);p.setMargins(0,dp(4),0,dp(4));l.setLayoutParams(p);return l;}
    private LinearLayout summaryCard(String title,String value,String subtitle){LinearLayout c=card();c.setOrientation(LinearLayout.VERTICAL);TextView t=text(title,15,Color.GRAY),v=text(value,24,GRAY),s=text(subtitle,14,Color.GRAY);v.setTypeface(Typeface.DEFAULT_BOLD);c.addView(t);c.addView(v);c.addView(s);return c;}
    private GradientDrawable round(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
}