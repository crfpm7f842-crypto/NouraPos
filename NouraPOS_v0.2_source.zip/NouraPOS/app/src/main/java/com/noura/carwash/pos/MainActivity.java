package com.noura.carwash.pos;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int RED = Color.rgb(236,34,36);
    private static final int GRAY = Color.rgb(51,51,51);
    private static final int SMOKE = Color.rgb(242,242,242);

    private DBHelper db;
    private SharedPreferences prefs;
    private SunmiPrinterBridge printer;
    private boolean arabic = true;
    private LinearLayout root;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new DBHelper(this);
        prefs = getSharedPreferences("noura_settings", MODE_PRIVATE);
        arabic = prefs.getBoolean("arabic", true);
        printer = new SunmiPrinterBridge(this);
        printer.connect();
        showHome();
    }

    @Override protected void onDestroy() {
        printer.disconnect();
        db.close();
        super.onDestroy();
    }

    private String t(String ar, String en) { return arabic ? ar : en; }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void baseScreen(boolean home) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        root.setPadding(dp(12), dp(10), dp(12), dp(12));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);

        if (!home) {
            Button back = smallButton("‹");
            back.setOnClickListener(v -> showHome());
            header.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        }

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.noura.carwash.pos.R.drawable.noura_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams lpLogo = new LinearLayout.LayoutParams(0, dp(66), 1);
        lpLogo.setMargins(dp(6),0,dp(6),0);
        header.addView(logo, lpLogo);

        Button lang = smallButton(arabic ? "EN" : "عربي");
        lang.setOnClickListener(v -> {
            arabic = !arabic;
            prefs.edit().putBoolean("arabic", arabic).apply();
            showHome();
        });
        header.addView(lang, new LinearLayout.LayoutParams(dp(68), dp(46)));
        root.addView(header);

        setContentView(root);
    }

    private ScrollView contentScroll() {
        ScrollView sv = new ScrollView(this);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1);
        root.addView(sv, p);
        return sv;
    }

    private LinearLayout stack(ScrollView sv) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(8), 0, dp(18));
        sv.addView(box, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return box;
    }

    private void showHome() {
        baseScreen(true);
        ScrollView sv = contentScroll();
        LinearLayout box = stack(sv);
        TextView title = heading(t("كاشير مغسلة نوره", "NOURA Car Wash POS"));
        box.addView(title);
        TextView sub = text(t("اختر العملية", "Choose an action"), 16, Color.DKGRAY);
        sub.setGravity(arabic ? Gravity.RIGHT : Gravity.LEFT);
        box.addView(sub);

        Button order = menuButton("🚗  " + t("فاتورة جديدة", "New Order"));
        order.setOnClickListener(v -> showOrder()); box.addView(order);
        Button reports = menuButton("📊  " + t("التقارير وترتيب العمال", "Reports & Worker Ranking"));
        reports.setOnClickListener(v -> showReports()); box.addView(reports);
        Button search = menuButton("🔎  " + t("البحث عن فاتورة", "Find an Invoice"));
        search.setOnClickListener(v -> showSearch()); box.addView(search);
        Button admin = menuButton("⚙  " + t("الإدارة", "Admin"));
        admin.setOnClickListener(v -> requestAdmin()); box.addView(admin);

        TextView printerState = text((printer.isConnected() ? "✓ " : "• ") + t(
                printer.isConnected() ? "طابعة SUNMI متصلة" : "سيتم الاتصال بطابعة SUNMI عند توفرها",
                printer.isConnected() ? "SUNMI printer connected" : "SUNMI printer will connect when available"), 14, Color.GRAY);
        printerState.setPadding(dp(8),dp(20),dp(8),0);
        box.addView(printerState);
    }

    private void showOrder() {
        baseScreen(false);
        ScrollView sv = contentScroll();
        LinearLayout box = stack(sv);
        box.addView(heading(t("طلب جديد", "New Order")));

        box.addView(sectionTitle(t("بيانات السيارة والعميل", "Car & Customer")));
        EditText plate = field(t("رقم اللوحة *", "Plate number *"), false);
        box.addView(plate);
        RadioGroup stayGroup = new RadioGroup(this);
        stayGroup.setOrientation(LinearLayout.HORIZONTAL);
        RadioButton waiting = radio(t("العميل ينتظر", "Customer waiting"));
        RadioButton leaving = radio(t("العميل سيغادر", "Customer leaving"));
        stayGroup.addView(waiting, new RadioGroup.LayoutParams(0, dp(52), 1));
        stayGroup.addView(leaving, new RadioGroup.LayoutParams(0, dp(52), 1));
        waiting.setChecked(true);
        box.addView(stayGroup);
        EditText phone = field(t("رقم العميل (إلزامي عند المغادرة)", "Customer phone (required if leaving)"), true);
        box.addView(phone);

        box.addView(sectionTitle(t("حجم السيارة", "Car Size")));
        double smallPrice = getPrice("small",30);
        double mediumPrice = getPrice("medium",35);
        double largePrice = getPrice("large",40);
        RadioGroup carGroup = new RadioGroup(this);
        carGroup.setOrientation(LinearLayout.VERTICAL);
        RadioButton small = radio(t("صغير", "Small") + " - " + money(smallPrice)); small.setTag("small");
        RadioButton medium = radio(t("وسط", "Medium") + " - " + money(mediumPrice)); medium.setTag("medium");
        RadioButton large = radio(t("كبير", "Large") + " - " + money(largePrice)); large.setTag("large");
        carGroup.addView(small); carGroup.addView(medium); carGroup.addView(large); small.setChecked(true);
        box.addView(carGroup);

        box.addView(sectionTitle(t("العامل المسؤول", "Responsible Worker")));
        List<DBHelper.Employee> employees = db.getEmployees(true);
        Spinner worker = new Spinner(this);
        ArrayAdapter<DBHelper.Employee> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, employees);
        worker.setAdapter(adapter); box.addView(worker, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        if (employees.isEmpty()) {
            TextView warn = text(t("لا يوجد عمال مضافون. أضف العمال من الإدارة أولاً.", "No workers yet. Add workers from Admin first."), 14, RED);
            warn.setPadding(dp(6),dp(4),dp(6),dp(8)); box.addView(warn);
        }

        box.addView(sectionTitle(t("خدمات إضافية", "Additional Services")));
        List<DBHelper.Product> products = db.getProducts(true);
        List<CheckBox> productChecks = new ArrayList<>();
        if (products.isEmpty()) {
            TextView empty = text(t("لا توجد خدمات إضافية حالياً", "No additional services yet"), 14, Color.GRAY);
            box.addView(empty);
        } else {
            for (DBHelper.Product p : products) {
                CheckBox cb = new CheckBox(this);
                cb.setText((arabic ? p.nameAr : p.nameEn) + "  •  " + money(p.price));
                cb.setTextSize(17); cb.setTag(p); cb.setPadding(dp(8),dp(4),dp(8),dp(4));
                box.addView(cb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
                productChecks.add(cb);
            }
        }

        box.addView(sectionTitle(t("الخصم", "Discount")));
        final String[] discountType = {"none"};
        final double[] discountValue = {0};
        TextView discountStatus = text(t("بدون خصم", "No discount"), 16, Color.GRAY);
        discountStatus.setPadding(dp(8), dp(4), dp(8), dp(4));
        box.addView(discountStatus);
        Button discountButton = menuButton(t("إضافة / تعديل الخصم", "Add / Edit Discount"));
        discountButton.setOnClickListener(v -> requestDiscount(discountType, discountValue, discountStatus));
        box.addView(discountButton);
        Button clearDiscount = smallButton(t("إلغاء الخصم", "Clear Discount"));
        clearDiscount.setOnClickListener(v -> {
            discountType[0] = "none"; discountValue[0] = 0;
            discountStatus.setText(t("بدون خصم", "No discount"));
        });
        box.addView(clearDiscount, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        box.addView(sectionTitle(t("طريقة الدفع", "Payment Method")));
        LinearLayout pay = new LinearLayout(this); pay.setOrientation(LinearLayout.VERTICAL);
        String[][] methods = {{"نقدي","Cash"},{"بطاقة","Card"},{"دفع جوال","Mobile"}};
        for (String[] m : methods) {
            Button b = primaryButton(t(m[0],m[1]));
            b.setOnClickListener(v -> {
                RadioButton selectedCar = findChecked(carGroup);
                if (plate.getText().toString().trim().isEmpty()) { toast(t("أدخل رقم اللوحة", "Enter plate number")); return; }
                if (leaving.isChecked() && phone.getText().toString().trim().isEmpty()) { toast(t("رقم العميل مطلوب لأنه سيغادر", "Customer phone is required when leaving")); return; }
                if (employees.isEmpty() || worker.getSelectedItem() == null) { toast(t("أضف العامل المسؤول أولاً", "Add/select a responsible worker first")); return; }
                if (selectedCar == null) { toast(t("اختر حجم السيارة", "Choose car size")); return; }
                String size = (String) selectedCar.getTag();
                double base = size.equals("small") ? smallPrice : size.equals("medium") ? mediumPrice : largePrice;
                List<DBHelper.Product> selectedProducts = new ArrayList<>();
                for (CheckBox cb : productChecks) if (cb.isChecked()) selectedProducts.add((DBHelper.Product) cb.getTag());
                DBHelper.Employee emp = (DBHelper.Employee) worker.getSelectedItem();
                long id = db.createSale(plate.getText().toString(), phone.getText().toString(), leaving.isChecked(), size, base, emp.id, emp.name, m[1], selectedProducts, discountType[0], discountValue[0]);
                LocalBackupManager.backup(this, db);
                DBHelper.Sale sale = db.getSale(id);
                showPaidDialog(sale);
            });
            pay.addView(b);
        }
        box.addView(pay);
    }

    private RadioButton findChecked(RadioGroup g) {
        int id = g.getCheckedRadioButtonId();
        return id == -1 ? null : g.findViewById(id);
    }

    private void showPaidDialog(DBHelper.Sale sale) {
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle(t("تم تسجيل العملية ✓", "Payment saved ✓"))
                .setMessage(t("رقم الفاتورة: ", "Invoice #: ") + sale.id + "\n" +
                        (sale.discountAmount > 0 ? t("الخصم: ", "Discount: ") + money(sale.discountAmount) + "\n" : "") +
                        t("الإجمالي: ", "Total: ") + money(sale.total))
                .setPositiveButton(t("طباعة الفاتورة", "Print Receipt"), null)
                .setNegativeButton(t("طلب جديد بدون طباعة", "New Order - No Print"), (x,w) -> showOrder())
                .setNeutralButton(t("الرئيسية", "Home"), (x,w) -> showHome())
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (printer.printReceipt(sale)) toast(t("تم إرسال الفاتورة للطابعة", "Receipt sent to printer"));
            else toast(t("الطابعة غير متصلة حالياً", "Printer is not connected"));
        }));
        d.show();
    }

    private void showReports() {
        baseScreen(false);
        ScrollView sv = contentScroll(); LinearLayout box = stack(sv);
        box.addView(heading(t("التقارير", "Reports")));
        DBHelper.DailySummary day = db.getSummary(DBHelper.startOfToday(), DBHelper.startOfTomorrow());
        box.addView(summaryCard(t("مبيعات اليوم", "Today's Sales"), money(day.sales), t("عدد السيارات: ", "Cars: ") + day.cars));
        box.addView(sectionTitle(t("أداء العمال اليوم", "Workers Today")));
        addRanking(box, day.workerCounts);
        DBHelper.DailySummary month = db.getSummary(DBHelper.startOfMonth(), DBHelper.startOfNextMonth());
        box.addView(summaryCard(t("مبيعات الشهر", "Monthly Sales"), money(month.sales), t("عدد السيارات: ", "Cars: ") + month.cars));
        box.addView(sectionTitle(t("ترتيب العمال هذا الشهر", "Monthly Worker Ranking")));
        addRanking(box, month.workerCounts);
    }

    private void addRanking(LinearLayout box, List<DBHelper.WorkerCount> counts) {
        if (counts.isEmpty()) { box.addView(text(t("لا توجد عمليات بعد", "No sales yet"),15,Color.GRAY)); return; }
        int rank = 1;
        for (DBHelper.WorkerCount w : counts) {
            LinearLayout row = card(); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView r = text(String.valueOf(rank),22,RED); r.setTypeface(Typeface.DEFAULT_BOLD); row.addView(r,new LinearLayout.LayoutParams(dp(44),dp(48)));
            TextView n = text(w.name,18,GRAY); row.addView(n,new LinearLayout.LayoutParams(0,dp(48),1));
            TextView c = text(w.count + " " + t("سيارة","cars"),17,Color.DKGRAY); row.addView(c);
            box.addView(row); rank++;
        }
    }

    private void showSearch() {
        baseScreen(false);
        ScrollView sv = contentScroll(); LinearLayout box = stack(sv);
        box.addView(heading(t("البحث عن فاتورة", "Find an Invoice")));
        EditText q = field(t("رقم اللوحة أو رقم العميل", "Plate number or customer phone"), false); box.addView(q);
        Button go = primaryButton(t("بحث", "Search")); box.addView(go);
        LinearLayout results = new LinearLayout(this); results.setOrientation(LinearLayout.VERTICAL); box.addView(results);
        go.setOnClickListener(v -> {
            results.removeAllViews();
            String text = q.getText().toString().trim();
            if (text.isEmpty()) { toast(t("اكتب رقم اللوحة أو الجوال", "Enter a plate or phone")); return; }
            List<DBHelper.Sale> sales = db.searchSales(text, 50);
            if (sales.isEmpty()) { results.addView(text(t("لا توجد نتائج", "No results"),16,Color.GRAY)); return; }
            for (DBHelper.Sale s : sales) {
                LinearLayout c = card(); c.setOrientation(LinearLayout.VERTICAL);
                TextView first = text("#" + s.id + "  •  " + s.plate + "  •  " + money(s.total),17,GRAY); first.setTypeface(Typeface.DEFAULT_BOLD); c.addView(first);
                c.addView(text(new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date(s.createdAt)) + "  •  " + s.workerName,14,Color.GRAY));
                Button details = smallButton(t("التفاصيل", "Details")); details.setOnClickListener(x -> showSaleDetails(s.id)); c.addView(details);
                results.addView(c);
            }
        });
    }

    private void showSaleDetails(long id) {
        DBHelper.Sale s = db.getSale(id);
        if (s == null) return;
        StringBuilder b = new StringBuilder();
        b.append(t("اللوحة: ","Plate: ")).append(s.plate).append("\n");
        b.append(t("رقم العميل: ","Phone: ")).append(s.phone == null || s.phone.isEmpty() ? "-" : s.phone).append("\n");
        b.append(t("العامل: ","Worker: ")).append(s.workerName).append("\n");
        b.append(t("الحجم: ","Size: ")).append(s.carSize).append("\n");
        for (DBHelper.Product p : s.items) b.append("• ").append(arabic?p.nameAr:p.nameEn).append(" - ").append(money(p.price)).append("\n");
        b.append(t("المجموع قبل الخصم: ","Subtotal: ")).append(money(s.subtotal)).append("\n");
        if (s.discountAmount > 0) {
            String d = "percent".equals(s.discountType) ? String.format(Locale.US, "%.0f%%", s.discountValue) : money(s.discountValue);
            b.append(t("الخصم: ","Discount: ")).append(d).append(" (-").append(money(s.discountAmount)).append(")\n");
        }
        b.append(t("الإجمالي: ","Total: ")).append(money(s.total));
        new AlertDialog.Builder(this).setTitle(t("تفاصيل الفاتورة #","Invoice #") + s.id).setMessage(b.toString())
                .setPositiveButton(t("طباعة", "Print"),(d,w)->{
                    if (!printer.printReceipt(s)) toast(t("الطابعة غير متصلة", "Printer not connected"));
                }).setNegativeButton(t("إغلاق","Close"),null).show();
    }

    private void requestDiscount(final String[] type, final double[] value, final TextView status) {
        String pin = prefs.getString("admin_pin", "");
        if (pin.isEmpty()) {
            toast(t("أنشئ PIN الإدارة أولاً من قسم الإدارة", "Create an Admin PIN first"));
            return;
        }
        final EditText pinInput = new EditText(this);
        pinInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pinInput.setHint(t("PIN الإدارة", "Admin PIN"));
        new AlertDialog.Builder(this)
                .setTitle(t("اعتماد الخصم", "Approve Discount"))
                .setView(pinInput)
                .setPositiveButton(t("متابعة", "Continue"), (d,w) -> {
                    if (!pin.equals(pinInput.getText().toString().trim())) {
                        toast(t("رمز الإدارة غير صحيح", "Incorrect Admin PIN"));
                        return;
                    }
                    showDiscountEditor(type, value, status);
                })
                .setNegativeButton(t("إلغاء", "Cancel"), null).show();
    }

    private void showDiscountEditor(final String[] type, final double[] value, final TextView status) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18), dp(8), dp(18), 0);
        RadioGroup group = new RadioGroup(this);
        RadioButton percent = radio(t("نسبة مئوية %", "Percentage %")); percent.setTag("percent");
        RadioButton fixed = radio(t("مبلغ ثابت (ريال)", "Fixed amount (SAR)")); fixed.setTag("fixed");
        group.addView(percent); group.addView(fixed);
        if ("fixed".equals(type[0])) fixed.setChecked(true); else percent.setChecked(true);
        form.addView(group);
        EditText amount = numberField(value[0] > 0 ? String.valueOf(value[0]) : "");
        amount.setHint(t("قيمة الخصم", "Discount value")); form.addView(amount);
        new AlertDialog.Builder(this).setTitle(t("الخصم", "Discount")).setView(form)
                .setPositiveButton(t("حفظ", "Save"), (d,w) -> {
                    try {
                        double x = Double.parseDouble(amount.getText().toString());
                        RadioButton selected = findChecked(group);
                        String selectedType = selected == null ? "percent" : (String) selected.getTag();
                        if (x <= 0 || ("percent".equals(selectedType) && x > 100)) {
                            toast(t("تأكد من قيمة الخصم", "Check the discount value")); return;
                        }
                        type[0] = selectedType; value[0] = x;
                        status.setText("percent".equals(selectedType) ? t("خصم ", "Discount ") + String.format(Locale.US, "%.0f%%", x) : t("خصم ", "Discount ") + money(x));
                    } catch (Exception e) { toast(t("تأكد من قيمة الخصم", "Check the discount value")); }
                }).setNegativeButton(t("إلغاء", "Cancel"), null).show();
    }

    private void requestAdmin() {
        String pin = prefs.getString("admin_pin", "");
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        input.setHint(pin.isEmpty() ? t("اختر PIN من 4 أرقام", "Create a 4-digit PIN") : t("أدخل PIN", "Enter PIN"));
        new AlertDialog.Builder(this)
                .setTitle(pin.isEmpty() ? t("إنشاء رمز الإدارة", "Create Admin PIN") : t("دخول الإدارة", "Admin Login"))
                .setView(input)
                .setPositiveButton(t("متابعة","Continue"),(d,w)->{
                    String entered = input.getText().toString().trim();
                    if (pin.isEmpty()) {
                        if (entered.matches("\\d{4}")) { prefs.edit().putString("admin_pin",entered).apply(); showAdmin(); }
                        else toast(t("الرمز يجب أن يكون 4 أرقام", "PIN must be 4 digits"));
                    } else if (pin.equals(entered)) showAdmin();
                    else toast(t("رمز غير صحيح", "Incorrect PIN"));
                }).setNegativeButton(t("إلغاء","Cancel"),null).show();
    }

    private void showAdmin() {
        baseScreen(false);
        ScrollView sv = contentScroll(); LinearLayout box = stack(sv);
        box.addView(heading(t("الإدارة", "Admin")));
        box.addView(sectionTitle(t("أسعار الغسيل", "Wash Prices")));
        EditText small = numberField(String.valueOf(getPrice("small",30))); EditText medium = numberField(String.valueOf(getPrice("medium",35))); EditText large = numberField(String.valueOf(getPrice("large",40)));
        box.addView(labeled(t("صغير","Small"),small)); box.addView(labeled(t("وسط","Medium"),medium)); box.addView(labeled(t("كبير","Large"),large));
        Button savePrices = primaryButton(t("حفظ الأسعار", "Save Prices"));
        savePrices.setOnClickListener(v->{
            try {
                prefs.edit().putFloat("price_small",Float.parseFloat(small.getText().toString())).putFloat("price_medium",Float.parseFloat(medium.getText().toString())).putFloat("price_large",Float.parseFloat(large.getText().toString())).apply();
                toast(t("تم الحفظ", "Saved"));
            } catch(Exception e){ toast(t("تأكد من الأسعار", "Check the prices")); }
        }); box.addView(savePrices);

        box.addView(sectionTitle(t("العمال", "Workers")));
        EditText workerName = field(t("اسم العامل", "Worker name"),false); box.addView(workerName);
        Button addWorker = primaryButton(t("إضافة عامل", "Add Worker")); box.addView(addWorker);
        LinearLayout workerList = new LinearLayout(this); workerList.setOrientation(LinearLayout.VERTICAL); box.addView(workerList);
        Runnable renderWorkers = () -> renderWorkers(workerList);
        addWorker.setOnClickListener(v->{ if(workerName.getText().toString().trim().isEmpty())return; db.addEmployee(workerName.getText().toString()); workerName.setText(""); LocalBackupManager.backup(this,db); renderWorkers.run(); });
        renderWorkers.run();

        box.addView(sectionTitle(t("الخدمات الإضافية", "Additional Services")));
        EditText ar = field("الاسم بالعربي",false); EditText en = field("English name",false); EditText price = numberField(""); price.setHint(t("السعر","Price"));
        box.addView(ar); box.addView(en); box.addView(price);
        Button addProduct = primaryButton(t("إضافة خدمة", "Add Service")); box.addView(addProduct);
        LinearLayout productList = new LinearLayout(this); productList.setOrientation(LinearLayout.VERTICAL); box.addView(productList);
        Runnable renderProducts = () -> renderProducts(productList);
        addProduct.setOnClickListener(v->{
            try {
                if(ar.getText().toString().trim().isEmpty() || en.getText().toString().trim().isEmpty()) { toast(t("اكتب اسم الخدمة بالعربي والإنجليزي", "Enter both Arabic and English names")); return; }
                db.addProduct(ar.getText().toString(),en.getText().toString(),Double.parseDouble(price.getText().toString()));
                ar.setText(""); en.setText(""); price.setText(""); LocalBackupManager.backup(this,db); renderProducts.run();
            } catch(Exception e){ toast(t("تأكد من السعر", "Check the price")); }
        });
        renderProducts.run();

        box.addView(sectionTitle(t("الأمان والنسخ الاحتياطي", "Security & Backup")));
        Button pin = menuButton(t("تغيير PIN الإدارة", "Change Admin PIN")); pin.setOnClickListener(v -> changePin()); box.addView(pin);
        TextView backup = text(t("✓ يتم إنشاء نسخة احتياطية محلية تلقائياً بعد كل عملية أو تعديل. النسخ السحابي سيُربط في مرحلة Firebase.",
                "✓ A local backup is created automatically after each sale or edit. Cloud backup will be connected in the Firebase stage."),14,Color.GRAY);
        backup.setPadding(dp(8),dp(10),dp(8),dp(12)); box.addView(backup);
    }

    private void renderWorkers(LinearLayout list) {
        list.removeAllViews();
        for(DBHelper.Employee e: db.getEmployees(false)) {
            LinearLayout row = card(); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView name = text(e.name,17,GRAY); row.addView(name,new LinearLayout.LayoutParams(0,dp(52),1));
            Button edit = smallButton(t("تعديل","Edit")); edit.setOnClickListener(v->editEmployee(e)); row.addView(edit);
            Switch sw = new Switch(this); sw.setChecked(e.active); sw.setOnCheckedChangeListener((b,c)->{db.setEmployeeActive(e.id,c);LocalBackupManager.backup(this,db);}); row.addView(sw);
            list.addView(row);
        }
    }

    private void editEmployee(DBHelper.Employee e) {
        EditText f = new EditText(this); f.setText(e.name);
        new AlertDialog.Builder(this).setTitle(t("تعديل العامل","Edit Worker")).setView(f)
                .setPositiveButton(t("حفظ","Save"),(d,w)->{if(!f.getText().toString().trim().isEmpty()){db.updateEmployee(e.id,f.getText().toString());LocalBackupManager.backup(this,db);showAdmin();}})
                .setNegativeButton(t("إلغاء","Cancel"),null).show();
    }

    private void renderProducts(LinearLayout list) {
        list.removeAllViews();
        for(DBHelper.Product p: db.getProducts(false)) {
            LinearLayout row = card(); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView n = text((arabic?p.nameAr:p.nameEn)+" • "+money(p.price),16,GRAY); row.addView(n,new LinearLayout.LayoutParams(0,dp(56),1));
            Button edit = smallButton(t("تعديل","Edit")); edit.setOnClickListener(v->editProduct(p)); row.addView(edit);
            Switch sw = new Switch(this); sw.setChecked(p.active); sw.setOnCheckedChangeListener((b,c)->{db.setProductActive(p.id,c);LocalBackupManager.backup(this,db);}); row.addView(sw);
            list.addView(row);
        }
    }

    private void editProduct(DBHelper.Product p) {
        LinearLayout form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(dp(18),dp(8),dp(18),0);
        EditText ar = field("الاسم بالعربي",false); ar.setText(p.nameAr); form.addView(ar);
        EditText en = field("English name",false); en.setText(p.nameEn); form.addView(en);
        EditText price = numberField(String.valueOf(p.price)); form.addView(price);
        new AlertDialog.Builder(this).setTitle(t("تعديل الخدمة","Edit Service")).setView(form)
                .setPositiveButton(t("حفظ","Save"),(d,w)->{
                    try { db.updateProduct(p.id,ar.getText().toString(),en.getText().toString(),Double.parseDouble(price.getText().toString())); LocalBackupManager.backup(this,db); showAdmin(); }
                    catch(Exception ex){ toast(t("تأكد من البيانات","Check the details")); }
                }).setNegativeButton(t("إلغاء","Cancel"),null).show();
    }

    private void changePin() {
        EditText f = new EditText(this); f.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle(t("PIN جديد من 4 أرقام","New 4-digit PIN")).setView(f)
                .setPositiveButton(t("حفظ","Save"),(d,w)->{String x=f.getText().toString(); if(x.matches("\\d{4}")){prefs.edit().putString("admin_pin",x).apply();toast(t("تم تغيير الرمز","PIN changed"));}else toast(t("يجب أن يكون 4 أرقام","Must be 4 digits"));})
                .setNegativeButton(t("إلغاء","Cancel"),null).show();
    }

    private double getPrice(String key, double def) { return prefs.getFloat("price_"+key,(float)def); }
    private String money(double v) { return String.format(Locale.US,"%.0f SAR",v); }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }

    private TextView heading(String s) {
        TextView v = text(s,25,GRAY); v.setTypeface(Typeface.DEFAULT_BOLD); v.setGravity(arabic?Gravity.RIGHT:Gravity.LEFT); v.setPadding(dp(4),dp(12),dp(4),dp(8)); return v;
    }
    private TextView sectionTitle(String s) {
        TextView v = text(s,18,GRAY); v.setTypeface(Typeface.DEFAULT_BOLD); v.setGravity(arabic?Gravity.RIGHT:Gravity.LEFT); v.setPadding(dp(4),dp(22),dp(4),dp(8)); return v;
    }
    private TextView text(String s,int sp,int color) { TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(color);return v; }

    private EditText field(String hint, boolean phone) {
        EditText e = new EditText(this); e.setHint(hint); e.setTextSize(17); e.setSingleLine(true); e.setPadding(dp(14),0,dp(14),0);
        e.setInputType(phone ? InputType.TYPE_CLASS_PHONE : InputType.TYPE_CLASS_TEXT);
        e.setBackground(round(Color.WHITE, Color.LTGRAY, 12));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)); p.setMargins(0,dp(5),0,dp(5)); e.setLayoutParams(p); return e;
    }
    private EditText numberField(String value) {
        EditText e = field(t("السعر","Price"),false); e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); e.setText(value); return e;
    }
    private LinearLayout labeled(String label, EditText input) {
        LinearLayout r = new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); TextView l=text(label,16,GRAY); l.setGravity(arabic?Gravity.RIGHT:Gravity.LEFT); r.addView(l,new LinearLayout.LayoutParams(0,dp(58),1)); r.addView(input,new LinearLayout.LayoutParams(dp(130),dp(54))); return r;
    }
    private RadioButton radio(String s) { RadioButton r=new RadioButton(this);r.setText(s);r.setTextSize(17);r.setPadding(dp(8),0,dp(8),0);return r; }

    private Button primaryButton(String s) {
        Button b=new Button(this); b.setText(s); b.setTextSize(17); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT_BOLD); b.setBackground(round(RED,RED,14));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(58));p.setMargins(0,dp(6),0,dp(6));b.setLayoutParams(p);return b;
    }
    private Button menuButton(String s) {
        Button b=new Button(this); b.setText(s); b.setTextSize(18); b.setGravity(arabic?Gravity.RIGHT|Gravity.CENTER_VERTICAL:Gravity.LEFT|Gravity.CENTER_VERTICAL); b.setPadding(dp(18),0,dp(18),0); b.setTextColor(GRAY); b.setAllCaps(false); b.setBackground(round(SMOKE,Color.LTGRAY,16));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(72));p.setMargins(0,dp(6),0,dp(6));b.setLayoutParams(p);return b;
    }
    private Button smallButton(String s) { Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setAllCaps(false);b.setTextColor(GRAY);b.setBackground(round(SMOKE,Color.LTGRAY,12));return b; }
    private LinearLayout card() { LinearLayout l=new LinearLayout(this);l.setPadding(dp(12),dp(7),dp(12),dp(7));l.setBackground(round(SMOKE,Color.LTGRAY,14));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);p.setMargins(0,dp(4),0,dp(4));l.setLayoutParams(p);return l; }
    private LinearLayout summaryCard(String title,String value,String subtitle) {
        LinearLayout c=card();c.setOrientation(LinearLayout.VERTICAL);TextView t=text(title,15,Color.GRAY);TextView v=text(value,27,GRAY);v.setTypeface(Typeface.DEFAULT_BOLD);TextView s=text(subtitle,15,Color.GRAY);c.addView(t);c.addView(v);c.addView(s);return c;
    }
    private GradientDrawable round(int fill,int stroke,int radius) { GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g; }
}
