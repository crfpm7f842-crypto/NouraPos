package com.noura.carwash.pos;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;

import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DocumentExporter {
    private static final String AUTHORITY = "com.noura.carwash.pos.fileprovider";

    @SuppressWarnings("deprecation")
    private static File outputDirectory(Context context, String type) {
        File base = context.getExternalFilesDir(type);
        if (base == null) base = context.getFilesDir();
        File dir = new File(base, "NouraPOS");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    public static Bitmap buildReceiptBitmap(DBHelper.Sale sale) {
        final int width = 384; // SUNMI V2 / 58mm native printable width
        final int maxHeight = 1700 + (sale.items == null ? 0 : sale.items.size() * 80);
        Bitmap work = Bitmap.createBitmap(width, maxHeight, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(work);
        c.drawColor(Color.WHITE);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.BLACK);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        p.setTextAlign(Paint.Align.CENTER);

        int y = 42;
        p.setTextSize(30); p.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("مغسلة نوره", width / 2f, y, p); y += 38;
        p.setTextSize(23);
        c.drawText("NOURA CAR WASH", width / 2f, y, p); y += 34;
        if (sale.refunded) {
            p.setTextSize(22); p.setColor(Color.DKGRAY);
            c.drawText("مرتجع  •  REFUNDED", width / 2f, y, p); y += 34;
            p.setColor(Color.BLACK);
        }

        p.setStrokeWidth(1.5f);
        c.drawLine(12, y, width - 12, y, p); y += 28;
        p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(20);
        c.drawText("Invoice #" + sale.invoiceNo, width / 2f, y, p); y += 28;
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(18);
        c.drawText("رقم الفاتورة: " + sale.invoiceNo, width / 2f, y, p); y += 27;
        c.drawText(new SimpleDateFormat("yyyy-MM-dd  HH:mm", Locale.US).format(new Date(sale.createdAt)), width / 2f, y, p); y += 32;

        p.setTextAlign(Paint.Align.LEFT); p.setTextSize(17);
        y = drawWrappedText(c, p, "Plate / اللوحة: " + sale.plate, 14, y, width - 28, 25);
        y = drawWrappedText(c, p, "Worker / العامل: " + sale.workerName, 14, y, width - 28, 25);
        y = drawWrappedText(c, p, "Car / السيارة: " + sale.carSize + "   " + money(sale.basePrice), 14, y, width - 28, 25);
        if (sale.items != null) {
            for (DBHelper.Product item : sale.items) {
                y = drawWrappedText(c, p, "• " + item.nameEn + " / " + item.nameAr + "   " + money(item.price), 14, y, width - 28, 25);
            }
        }

        y += 3; c.drawLine(12, y, width - 12, y, p); y += 29;
        if (sale.discountAmount > 0) {
            y = drawWrappedText(c, p, "SUBTOTAL / قبل الخصم: " + money(sale.subtotal), 14, y, width - 28, 25);
            String discountLabel = "percent".equals(sale.discountType)
                    ? String.format(Locale.US, "%.0f%%", sale.discountValue)
                    : money(sale.discountValue);
            y = drawWrappedText(c, p, "DISCOUNT / الخصم: " + discountLabel + "  (-" + money(sale.discountAmount) + ")", 14, y, width - 28, 25);
            if (sale.discountReason != null && !sale.discountReason.trim().isEmpty()) {
                y = drawWrappedText(c, p, "Discount reason / سبب الخصم: " + sale.discountReason, 14, y, width - 28, 25);
            }
        }

        p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(23);
        y = drawWrappedText(c, p, "TOTAL / الإجمالي: " + money(sale.total), 14, y + 2, width - 28, 31);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(17);
        String payment = paymentDisplay(sale.paymentMethod);
        y = drawWrappedText(c, p, "Payment / الدفع: " + payment, 14, y, width - 28, 25);
        if ("Split".equals(sale.paymentMethod)) {
            y = drawWrappedText(c, p, "Cash / نقدي: " + money(sale.cashAmount), 14, y, width - 28, 25);
            y = drawWrappedText(c, p, "Card / شبكة: " + money(sale.cardAmount), 14, y, width - 28, 25);
        }
        if (sale.refunded) {
            y = drawWrappedText(c, p, "Refunded / وقت المرتجع: " + new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date(sale.refundedAt)), 14, y, width - 28, 25);
            if (sale.refundReason != null && !sale.refundReason.trim().isEmpty()) {
                y = drawWrappedText(c, p, "Reason / السبب: " + sale.refundReason, 14, y, width - 28, 25);
            }
        }

        p.setTextAlign(Paint.Align.CENTER); p.setTextSize(17);
        c.drawText("شكراً لزيارتكم - Thank you", width / 2f, y + 14, p);
        int finalHeight = Math.min(maxHeight, Math.max(500, y + 48));
        Bitmap result = Bitmap.createBitmap(work, 0, 0, width, finalHeight);
        if (result != work) work.recycle();
        return result;
    }

    private static int drawWrappedText(Canvas c, Paint p, String text, float x, int y, float maxWidth, int lineHeight) {
        if (text == null) return y;
        String[] paragraphs = text.split("\\n", -1);
        for (String paragraph : paragraphs) {
            String[] words = paragraph.split(" ");
            String line = "";
            for (String word : words) {
                String candidate = line.isEmpty() ? word : line + " " + word;
                if (!line.isEmpty() && p.measureText(candidate) > maxWidth) {
                    c.drawText(line, x, y, p);
                    y += lineHeight;
                    line = word;
                } else {
                    line = candidate;
                }
            }
            if (!line.isEmpty()) {
                c.drawText(line, x, y, p);
                y += lineHeight;
            }
        }
        return y;
    }

    private static String paymentDisplay(String method) {
        if ("Cash".equals(method)) return "Cash / نقدي";
        if ("Card".equals(method)) return "Card / شبكة";
        if ("Split".equals(method)) return "Split / كاش + شبكة";
        return method == null ? "-" : method;
    }

    public static File saveReceiptImage(Context context, DBHelper.Sale sale) throws IOException {
        File dir = outputDirectory(context, Environment.DIRECTORY_PICTURES);
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Could not create receipt directory");
        String day = sale.invoiceDay == null || sale.invoiceDay.isEmpty()
                ? new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(sale.createdAt)) : sale.invoiceDay;
        File file = new File(dir, "Noura_Invoice_" + day + "_" + sale.invoiceNo + ".png");
        Bitmap bmp = buildReceiptBitmap(sale);
        try (FileOutputStream out = new FileOutputStream(file)) {
            if (!bmp.compress(Bitmap.CompressFormat.PNG, 100, out)) throw new IOException("Could not save image");
        }
        bmp.recycle();
        return file;
    }

    public static String saveReceiptImageToDevice(Context context, DBHelper.Sale sale) throws IOException {
        String day = sale.invoiceDay == null || sale.invoiceDay.isEmpty()
                ? new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(sale.createdAt)) : sale.invoiceDay;
        String name = "Noura_Invoice_" + day + "_" + sale.invoiceNo + ".png";
        Bitmap bmp = buildReceiptBitmap(sale);
        try {
            saveBitmapToPictures(context, bmp, name);
        } finally {
            bmp.recycle();
        }
        return name;
    }

    @SuppressWarnings("deprecation")
    private static void saveBitmapToPictures(Context context, Bitmap bmp, String name) throws IOException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver resolver = context.getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/NouraPOS");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("Could not create image in MediaStore");
            try (OutputStream out = resolver.openOutputStream(uri)) {
                if (out == null || !bmp.compress(Bitmap.CompressFormat.PNG, 100, out)) throw new IOException("Could not save image");
            } catch (Exception e) {
                resolver.delete(uri, null, null);
                if (e instanceof IOException) throw (IOException)e;
                throw new IOException(e);
            }
            values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0);
            resolver.update(uri, values, null, null);
            return;
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            throw new IOException("Storage permission not granted");
        File base = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        File dir = new File(base, "NouraPOS");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Could not create Pictures/NouraPOS");
        try (FileOutputStream out = new FileOutputStream(new File(dir, name))) {
            if (!bmp.compress(Bitmap.CompressFormat.PNG, 100, out)) throw new IOException("Could not save image");
        }
    }

    public static File createReportPdf(Context context, DBHelper db, long start, long end, String title, boolean arabic) throws IOException {
        File dir = outputDirectory(context, Environment.DIRECTORY_DOCUMENTS);
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Could not create report directory");
        String stamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date());
        File file = new File(dir, "Noura_Report_" + stamp + ".pdf");

        DBHelper.DailySummary summary = db.getSummary(start, end);
        List<DBHelper.WorkerCount> workers = summary.workerCounts;
        List<DBHelper.DaySummary> days = db.getDailyBreakdown(start, end);

        PdfDocument doc = new PdfDocument();
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int pageNo = 1;
        PdfDocument.Page page = newPage(doc, pageNo);
        Canvas canvas = page.getCanvas();
        int y = drawReportHeader(canvas, p, title, start, end, arabic);

        List<String[]> summaryRows = new ArrayList<>();
        summaryRows.add(new String[]{arabic ? "إجمالي المبيعات" : "Gross sales", money(summary.grossSales)});
        summaryRows.add(new String[]{arabic ? "المرتجعات" : "Refunds", money(summary.refunds)});
        summaryRows.add(new String[]{arabic ? "صافي المبيعات" : "Net sales", money(summary.sales)});
        summaryRows.add(new String[]{arabic ? "عدد السيارات" : "Cars washed", String.valueOf(summary.cars)});
        String topAddon = arabic ? summary.topAddOnAr : summary.topAddOnEn;
        summaryRows.add(new String[]{arabic ? "أكثر إضافة طلباً" : "Top add-on", (topAddon == null || topAddon.isEmpty()) ? "-" : topAddon + " × " + summary.topAddOnCount});
        summaryRows.add(new String[]{arabic ? "أكثر حجم سيارة" : "Top car size", (summary.topCarSize == null || summary.topCarSize.isEmpty()) ? "-" : summary.topCarSize + " × " + summary.topCarSizeCount});
        y = drawSimpleTable(canvas, p, y, new String[]{arabic ? "البند" : "Item", arabic ? "القيمة" : "Value"}, summaryRows, new float[]{42, 345, 553});

        y += 18;
        y = drawSectionTitle(canvas, p, y, arabic ? "أداء العمال" : "Worker performance");
        y = drawWorkerTable(canvas, p, y, workers, arabic);

        y += 18;
        if (y > 690) { doc.finishPage(page); pageNo++; page = newPage(doc, pageNo); canvas = page.getCanvas(); y = 55; }
        y = drawSectionTitle(canvas, p, y, arabic ? "تفاصيل الأيام" : "Daily breakdown");
        SimpleDateFormat dayFmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        int[] x = {42, 135, 205, 330, 440, 553};
        String[] headers = {arabic ? "التاريخ" : "Date", arabic ? "سيارات" : "Cars", arabic ? "إجمالي" : "Gross", arabic ? "مرتجع" : "Refunds", arabic ? "صافي" : "Net"};
        y = drawTableRow(canvas, p, y, x, headers, true);
        for (DBHelper.DaySummary day : days) {
            if (y > 790) {
                doc.finishPage(page); pageNo++; page = newPage(doc, pageNo); canvas = page.getCanvas(); y = 55;
                y = drawTableRow(canvas, p, y, x, headers, true);
            }
            DBHelper.DailySummary d = day.summary;
            y = drawTableRow(canvas, p, y, x, new String[]{dayFmt.format(new Date(day.dayStart)), String.valueOf(d.cars), moneyShort(d.grossSales), moneyShort(d.refunds), moneyShort(d.sales)}, false);
        }

        doc.finishPage(page);
        try (FileOutputStream out = new FileOutputStream(file)) { doc.writeTo(out); }
        doc.close();
        return file;
    }

    public static String saveReportPdfToDevice(Context context, File source) throws IOException {
        if (source == null || !source.exists()) throw new IOException("Report file not found");
        String name = source.getName();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver resolver = context.getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, name);
            values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/NouraPOS");
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("Could not create report in Downloads");
            try (InputStream in = new FileInputStream(source); OutputStream out = resolver.openOutputStream(uri)) {
                if (out == null) throw new IOException("Could not open report destination");
                copy(in, out);
            } catch (Exception e) {
                resolver.delete(uri, null, null);
                if (e instanceof IOException) throw (IOException)e;
                throw new IOException(e);
            }
            values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0);
            resolver.update(uri, values, null, null);
            return name;
        }

        @SuppressWarnings("deprecation") File base = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            throw new IOException("Storage permission not granted");
        File dir = new File(base, "NouraPOS");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Could not create Downloads/NouraPOS");
        File target = new File(dir, name);
        try (InputStream in = new FileInputStream(source); OutputStream out = new FileOutputStream(target)) { copy(in, out); }
        return name;
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[8192];
        int n;
        while ((n = in.read(buffer)) >= 0) out.write(buffer, 0, n);
    }

    private static PdfDocument.Page newPage(PdfDocument doc, int pageNo) {
        PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(595, 842, pageNo).create();
        PdfDocument.Page page = doc.startPage(info);
        page.getCanvas().drawColor(Color.WHITE);
        return page;
    }

    private static int drawReportHeader(Canvas c, Paint p, String title, long start, long end, boolean arabic) {
        p.setTextAlign(Paint.Align.CENTER); p.setColor(Color.BLACK); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(22);
        c.drawText("NOURA CAR WASH", 297, 48, p);
        p.setTextSize(15); c.drawText(title, 297, 73, p);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(10);
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        c.drawText(f.format(new Date(start)) + "  →  " + f.format(new Date(Math.max(start, end - 1))), 297, 92, p);
        return 120;
    }

    private static int drawSectionTitle(Canvas c, Paint p, int y, String title) {
        p.setTextAlign(Paint.Align.LEFT); p.setColor(Color.BLACK); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(13);
        c.drawText(title, 42, y, p);
        c.drawLine(42, y + 5, 553, y + 5, p);
        return y + 22;
    }

    private static int drawSimpleTable(Canvas c, Paint p, int y, String[] headers, List<String[]> rows, float[] x) {
        int[] xi = new int[]{(int)x[0], (int)x[1], (int)x[2]};
        y = drawTableRow(c, p, y, xi, headers, true);
        for (String[] row : rows) y = drawTableRow(c, p, y, xi, row, false);
        return y;
    }

    private static int drawWorkerTable(Canvas c, Paint p, int y, List<DBHelper.WorkerCount> workers, boolean arabic) {
        int[] x = {42, 90, 315, 430, 553};
        y = drawTableRow(c, p, y, x, new String[]{"#", arabic ? "العامل" : "Worker", arabic ? "الغسلات" : "Washes", arabic ? "مرتجع" : "Refunds"}, true);
        int rank = 1;
        for (DBHelper.WorkerCount w : workers) {
            y = drawTableRow(c, p, y, x, new String[]{String.valueOf(rank++), w.name, String.valueOf(w.count), String.valueOf(w.refundCount)}, false);
        }
        if (workers.isEmpty()) y = drawTableRow(c, p, y, x, new String[]{"-", arabic ? "لا توجد عمليات" : "No sales", "0", "0"}, false);
        return y;
    }

    private static int drawTableRow(Canvas c, Paint p, int y, int[] x, String[] cells, boolean header) {
        int h = 24;
        p.setStyle(Paint.Style.FILL);
        p.setColor(header ? Color.rgb(235,235,235) : Color.WHITE);
        c.drawRect(x[0], y, x[x.length - 1], y + h, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(0.8f); p.setColor(Color.LTGRAY);
        c.drawRect(x[0], y, x[x.length - 1], y + h, p);
        for (int i = 1; i < x.length - 1; i++) c.drawLine(x[i], y, x[i], y + h, p);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.DKGRAY); p.setTypeface(header ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT); p.setTextSize(9); p.setTextAlign(Paint.Align.CENTER);
        for (int i = 0; i < cells.length && i + 1 < x.length; i++) {
            String txt = cells[i] == null ? "" : cells[i];
            txt = ellipsize(p, txt, x[i + 1] - x[i] - 6);
            c.drawText(txt, (x[i] + x[i + 1]) / 2f, y + 16, p);
        }
        return y + h;
    }

    private static String ellipsize(Paint p, String text, float maxWidth) {
        if (p.measureText(text) <= maxWidth) return text;
        String suffix = "…";
        while (text.length() > 1 && p.measureText(text + suffix) > maxWidth) text = text.substring(0, text.length() - 1);
        return text + suffix;
    }

    public static void shareFile(Context context, File file, String mimeType, String chooserTitle) {
        Uri uri = FileProvider.getUriForFile(context, AUTHORITY, file);
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType(mimeType);
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        context.startActivity(Intent.createChooser(i, chooserTitle));
    }

    public static void printPdf(Activity activity, File file, String jobName) {
        PrintManager manager = (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
        if (manager == null) return;
        PrintAttributes attrs = new PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                .build();
        manager.print(jobName, new PdfFileAdapter(file), attrs);
    }

    private static class PdfFileAdapter extends PrintDocumentAdapter {
        private final File file;
        PdfFileAdapter(File file){ this.file=file; }

        @Override public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                                       CancellationSignal cancellationSignal, LayoutResultCallback callback, android.os.Bundle extras) {
            if (cancellationSignal.isCanceled()) { callback.onLayoutCancelled(); return; }
            PrintDocumentInfo info = new PrintDocumentInfo.Builder(file.getName())
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN).build();
            callback.onLayoutFinished(info, true);
        }

        @Override public void onWrite(PageRange[] pages, ParcelFileDescriptor destination,
                                      CancellationSignal cancellationSignal, WriteResultCallback callback) {
            try (FileInputStream in = new FileInputStream(file); FileOutputStream out = new FileOutputStream(destination.getFileDescriptor())) {
                byte[] buffer = new byte[8192];
                int n;
                while ((n=in.read(buffer)) >= 0) {
                    if (cancellationSignal.isCanceled()) { callback.onWriteCancelled(); return; }
                    out.write(buffer,0,n);
                }
                callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
            } catch (IOException e) { callback.onWriteFailed(e.getMessage()); }
        }
    }

    private static String money(double v) { return String.format(Locale.US, "%.2f SAR", v); }
    private static String moneyShort(double v) { return String.format(Locale.US, "%.0f", v); }
}
