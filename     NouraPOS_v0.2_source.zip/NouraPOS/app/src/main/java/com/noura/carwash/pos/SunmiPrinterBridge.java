package com.noura.carwash.pos;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.RemoteException;

import com.sunmi.peripheral.printer.InnerPrinterCallback;
import com.sunmi.peripheral.printer.InnerPrinterException;
import com.sunmi.peripheral.printer.InnerPrinterManager;
import com.sunmi.peripheral.printer.SunmiPrinterService;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SunmiPrinterBridge {
    private SunmiPrinterService service;
    private final Context context;
    private boolean connected = false;

    public SunmiPrinterBridge(Context context) { this.context = context.getApplicationContext(); }

    private final InnerPrinterCallback callback = new InnerPrinterCallback() {
        @Override protected void onConnected(SunmiPrinterService s) {
            service = s;
            connected = true;
        }
        @Override protected void onDisconnected() {
            service = null;
            connected = false;
        }
    };

    public void connect() {
        try { InnerPrinterManager.getInstance().bindService(context, callback); }
        catch (InnerPrinterException ignored) { connected = false; }
    }

    public void disconnect() {
        try { InnerPrinterManager.getInstance().unBindService(context, callback); }
        catch (InnerPrinterException ignored) { }
    }

    public boolean isConnected() { return connected && service != null; }

    public boolean printReceipt(DBHelper.Sale sale) {
        if (!isConnected() || sale == null) return false;
        try {
            Bitmap receipt = buildReceiptBitmap(sale);
            service.printBitmap(receipt, null);
            service.lineWrap(4, null);
            return true;
        } catch (RemoteException e) {
            return false;
        }
    }

    private Bitmap buildReceiptBitmap(DBHelper.Sale sale) {
        return DocumentExporter.buildReceiptBitmap(sale);
    }

    private String money(double v) { return String.format(Locale.US, "%.2f SAR", v); }
}
