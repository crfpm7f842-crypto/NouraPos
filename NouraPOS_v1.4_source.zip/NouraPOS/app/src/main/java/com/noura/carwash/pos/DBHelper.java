package com.noura.carwash.pos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "noura_pos.db";
    private static final int DB_VERSION = 8;

    public DBHelper(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE employees (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1)");
        db.execSQL("CREATE TABLE products (id INTEGER PRIMARY KEY AUTOINCREMENT, name_ar TEXT NOT NULL, name_en TEXT NOT NULL, price REAL NOT NULL, active INTEGER NOT NULL DEFAULT 1)");
        db.execSQL("CREATE TABLE wash_types (id INTEGER PRIMARY KEY AUTOINCREMENT, name_ar TEXT NOT NULL, name_en TEXT NOT NULL, price REAL NOT NULL, active INTEGER NOT NULL DEFAULT 1)");
        seedNouraMenu(db);
        db.execSQL("CREATE TABLE sales (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_day TEXT NOT NULL DEFAULT '', invoice_no INTEGER NOT NULL DEFAULT 0, " +
                "created_at INTEGER NOT NULL, completed_at INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'completed', " +
                "plate TEXT NOT NULL, phone TEXT, customer_leaving INTEGER NOT NULL DEFAULT 0, car_size TEXT NOT NULL, base_price REAL NOT NULL, " +
                "subtotal REAL NOT NULL DEFAULT 0, discount_type TEXT NOT NULL DEFAULT 'none', discount_value REAL NOT NULL DEFAULT 0, " +
                "discount_amount REAL NOT NULL DEFAULT 0, discount_reason TEXT NOT NULL DEFAULT '', total REAL NOT NULL, " +
                "worker_id INTEGER, worker_name TEXT NOT NULL, payment_method TEXT NOT NULL DEFAULT '', cash_amount REAL NOT NULL DEFAULT 0, card_amount REAL NOT NULL DEFAULT 0, " +
                "refunded INTEGER NOT NULL DEFAULT 0, refunded_at INTEGER NOT NULL DEFAULT 0, refund_reason TEXT NOT NULL DEFAULT '', " +
                "created_by_user_id INTEGER NOT NULL DEFAULT 0, created_by_user_name TEXT NOT NULL DEFAULT '', " +
                "completed_by_user_id INTEGER NOT NULL DEFAULT 0, completed_by_user_name TEXT NOT NULL DEFAULT '')");
        db.execSQL("CREATE TABLE sale_items (id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL, product_id INTEGER, name_ar TEXT NOT NULL, name_en TEXT NOT NULL, price REAL NOT NULL)");
        createUsersTable(db);
        createIndexes(db);
    }

    private static void createIndexes(SQLiteDatabase db) {
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sales_created_at ON sales(created_at)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sales_completed_at ON sales(completed_at)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sales_status ON sales(status, created_at)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sales_worker ON sales(worker_id, completed_at)");
        db.execSQL("DROP INDEX IF EXISTS idx_sales_invoice_day_no");
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_sales_invoice_day_no ON sales(invoice_day, invoice_no) WHERE invoice_no>0");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sale_items_sale ON sale_items(sale_id)");
    }

    private static void createUsersTable(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS app_users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, pin_hash TEXT NOT NULL UNIQUE, role TEXT NOT NULL DEFAULT 'employee', " +
                "active INTEGER NOT NULL DEFAULT 1, can_new_sale INTEGER NOT NULL DEFAULT 1, can_view_invoices INTEGER NOT NULL DEFAULT 1, " +
                "can_reports INTEGER NOT NULL DEFAULT 0, can_search INTEGER NOT NULL DEFAULT 1, can_refund INTEGER NOT NULL DEFAULT 0, can_discount INTEGER NOT NULL DEFAULT 0)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE sales ADD COLUMN subtotal REAL NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE sales ADD COLUMN discount_type TEXT NOT NULL DEFAULT 'none'");
            db.execSQL("ALTER TABLE sales ADD COLUMN discount_value REAL NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE sales ADD COLUMN discount_amount REAL NOT NULL DEFAULT 0");
            db.execSQL("UPDATE sales SET subtotal=total WHERE subtotal=0");
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE sales ADD COLUMN refunded INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE sales ADD COLUMN refunded_at INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE sales ADD COLUMN refund_reason TEXT NOT NULL DEFAULT ''");
        }
        if (oldVersion < 4) {
            db.execSQL("ALTER TABLE sales ADD COLUMN invoice_day TEXT NOT NULL DEFAULT ''");
            db.execSQL("ALTER TABLE sales ADD COLUMN invoice_no INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE sales ADD COLUMN discount_reason TEXT NOT NULL DEFAULT ''");
            db.execSQL("ALTER TABLE sales ADD COLUMN cash_amount REAL NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE sales ADD COLUMN card_amount REAL NOT NULL DEFAULT 0");
            Map<String,Integer> counters = new HashMap<>();
            Cursor c = db.rawQuery("SELECT id, created_at, total, payment_method FROM sales ORDER BY created_at, id", null);
            while (c.moveToNext()) {
                long id = c.getLong(0), createdAt = c.getLong(1);
                double total = c.getDouble(2);
                String payment = c.getString(3), day = dayKey(createdAt);
                int next = counters.containsKey(day) ? counters.get(day) + 1 : 1;
                counters.put(day, next);
                ContentValues v = new ContentValues();
                v.put("invoice_day", day); v.put("invoice_no", next);
                if ("Cash".equalsIgnoreCase(payment)) v.put("cash_amount", total); else v.put("card_amount", total);
                db.update("sales", v, "id=?", new String[]{String.valueOf(id)});
            }
            c.close();
        }
        if (oldVersion < 5) {
            db.execSQL("CREATE TABLE IF NOT EXISTS wash_types (id INTEGER PRIMARY KEY AUTOINCREMENT, name_ar TEXT NOT NULL, name_en TEXT NOT NULL, price REAL NOT NULL, active INTEGER NOT NULL DEFAULT 1)");
            Cursor c = db.rawQuery("SELECT COUNT(*) FROM wash_types", null);
            boolean empty = !c.moveToFirst() || c.getInt(0) == 0; c.close();
            if (empty) seedNouraMenu(db);
        }
        if (oldVersion < 6) {
            db.execSQL("ALTER TABLE sales ADD COLUMN completed_at INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE sales ADD COLUMN status TEXT NOT NULL DEFAULT 'completed'");
            db.execSQL("ALTER TABLE sales ADD COLUMN created_by_user_id INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE sales ADD COLUMN created_by_user_name TEXT NOT NULL DEFAULT ''");
            db.execSQL("ALTER TABLE sales ADD COLUMN completed_by_user_id INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE sales ADD COLUMN completed_by_user_name TEXT NOT NULL DEFAULT ''");
            db.execSQL("UPDATE sales SET completed_at=created_at WHERE completed_at=0");
        }
        if (oldVersion < 7) createUsersTable(db);
        if (oldVersion < 8) seedNouraMenu(db);
        createIndexes(db);
    }

    private static void seedNouraMenu(SQLiteDatabase db) {
        Object[][] washes = {
            {"غسيل صغير","Small Wash",30.0}, {"غسيل وسط","Medium Wash",35.0}, {"غسيل كبير","Large Wash",40.0},
            {"غسيل خارجي صغير","Small Exterior Wash",20.0}, {"غسيل خارجي وسط","Medium Exterior Wash",25.0}, {"غسيل خارجي كبير","Large Exterior Wash",30.0},
            {"ماء فقط","Water Only",10.0}, {"غسيل كفرات","Tire Wash",5.0}, {"قزاز فقط","Glass Only",5.0},
            {"كاوا","Kawa",5.0}, {"غسيل دنه","Pickup Wash",60.0}, {"غسيل باص","Bus Wash",40.0},
            {"غسيل كرسي","One Seat Wash",20.0}, {"غسيل 2 كرسي","Two Seat Wash",30.0}, {"غسيل 5 كرسي","Five Seat Wash",60.0}
        };
        for (Object[] row : washes) insertSeedIfMissing(db,"wash_types",(String)row[0],(String)row[1],(Double)row[2]);
        Object[][] extras = {{"إضافة صابون","Add Soap",5.0},{"كاوا","Kawa",5.0}};
        for (Object[] row : extras) insertSeedIfMissing(db,"products",(String)row[0],(String)row[1],(Double)row[2]);
    }

    private static void insertSeedIfMissing(SQLiteDatabase db,String table,String ar,String en,double price) {
        Cursor c=db.rawQuery("SELECT id FROM "+table+" WHERE name_ar=? LIMIT 1",new String[]{ar});
        boolean exists=c.moveToFirst();c.close();
        if(!exists){ContentValues v=new ContentValues();v.put("name_ar",ar);v.put("name_en",en);v.put("price",price);v.put("active",1);db.insert(table,null,v);}
    }

    public long addEmployee(String name) { ContentValues v=new ContentValues(); v.put("name",name.trim()); return getWritableDatabase().insert("employees",null,v); }
    public void updateEmployee(long id,String name){ContentValues v=new ContentValues();v.put("name",name.trim());getWritableDatabase().update("employees",v,"id=?",new String[]{String.valueOf(id)});}
    public void setEmployeeActive(long id,boolean active){ContentValues v=new ContentValues();v.put("active",active?1:0);getWritableDatabase().update("employees",v,"id=?",new String[]{String.valueOf(id)});}
    public List<Employee> getEmployees(boolean onlyActive){
        ArrayList<Employee> out=new ArrayList<>();
        Cursor c=getReadableDatabase().query("employees",null,onlyActive?"active=1":null,null,null,null,"name COLLATE NOCASE");
        while(c.moveToNext()) out.add(new Employee(c.getLong(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name")),c.getInt(c.getColumnIndexOrThrow("active"))==1));
        c.close(); return out;
    }

    public long addWashType(String ar,String en,double price){ContentValues v=new ContentValues();v.put("name_ar",ar.trim());v.put("name_en",en.trim());v.put("price",price);v.put("active",1);return getWritableDatabase().insert("wash_types",null,v);}
    public void updateWashType(long id,String ar,String en,double price){ContentValues v=new ContentValues();v.put("name_ar",ar.trim());v.put("name_en",en.trim());v.put("price",price);getWritableDatabase().update("wash_types",v,"id=?",new String[]{String.valueOf(id)});}
    public void setWashTypeActive(long id,boolean active){ContentValues v=new ContentValues();v.put("active",active?1:0);getWritableDatabase().update("wash_types",v,"id=?",new String[]{String.valueOf(id)});}
    public List<WashType> getWashTypes(boolean onlyActive){
        ArrayList<WashType> out=new ArrayList<>();
        Cursor c=getReadableDatabase().query("wash_types",null,onlyActive?"active=1":null,null,null,null,"id ASC");
        while(c.moveToNext()) out.add(new WashType(c.getLong(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name_ar")),c.getString(c.getColumnIndexOrThrow("name_en")),c.getDouble(c.getColumnIndexOrThrow("price")),c.getInt(c.getColumnIndexOrThrow("active"))==1));
        c.close(); return out;
    }

    public long addProduct(String ar,String en,double price){ContentValues v=new ContentValues();v.put("name_ar",ar.trim());v.put("name_en",en.trim());v.put("price",price);v.put("active",1);return getWritableDatabase().insert("products",null,v);}
    public void updateProduct(long id,String ar,String en,double price){ContentValues v=new ContentValues();v.put("name_ar",ar.trim());v.put("name_en",en.trim());v.put("price",price);getWritableDatabase().update("products",v,"id=?",new String[]{String.valueOf(id)});}
    public void setProductActive(long id,boolean active){ContentValues v=new ContentValues();v.put("active",active?1:0);getWritableDatabase().update("products",v,"id=?",new String[]{String.valueOf(id)});}
    public List<Product> getProducts(boolean onlyActive){
        ArrayList<Product> out=new ArrayList<>();
        Cursor c=getReadableDatabase().query("products",null,onlyActive?"active=1":null,null,null,null,"id DESC");
        while(c.moveToNext()) out.add(new Product(c.getLong(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name_ar")),c.getString(c.getColumnIndexOrThrow("name_en")),c.getDouble(c.getColumnIndexOrThrow("price")),c.getInt(c.getColumnIndexOrThrow("active"))==1));
        c.close(); return out;
    }

    private static Totals calculateTotals(double basePrice,List<Product> items,String discountType,double discountValue,String discountReason) {
        double subtotal=basePrice;
        if(items!=null) for(Product p:items) subtotal+=p.price;
        String type=discountType==null?"none":discountType;
        double amount=0;
        if("percent".equals(type)) amount=subtotal*Math.max(0,Math.min(100,discountValue))/100.0;
        else if("fixed".equals(type)) amount=Math.max(0,Math.min(subtotal,discountValue));
        else {type="none";discountValue=0;discountReason="";}
        return new Totals(subtotal,type,discountValue,amount,discountReason==null?"":discountReason.trim(),Math.max(0,subtotal-amount));
    }

    private static void replaceSaleItems(SQLiteDatabase db,long saleId,List<Product> items) {
        db.delete("sale_items","sale_id=?",new String[]{String.valueOf(saleId)});
        if(items==null)return;
        for(Product p:items){
            ContentValues i=new ContentValues();
            i.put("sale_id",saleId);i.put("product_id",p.id);i.put("name_ar",p.nameAr);i.put("name_en",p.nameEn);i.put("price",p.price);
            db.insertOrThrow("sale_items",null,i);
        }
    }

    public long createPendingSale(String plate,String phone,boolean leaving,String carSize,double basePrice,
                                  long workerId,String workerName,List<Product> items,String discountType,double discountValue,String discountReason,
                                  long createdByUserId,String createdByUserName) {
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try{
            long now=System.currentTimeMillis(); Totals totals=calculateTotals(basePrice,items,discountType,discountValue,discountReason);
            ContentValues v=new ContentValues();
            v.put("invoice_day","");v.put("invoice_no",0);v.put("created_at",now);v.put("completed_at",0);v.put("status","pending");
            v.put("plate",plate.trim().toUpperCase());v.put("phone",phone==null?"":phone.trim());v.put("customer_leaving",leaving?1:0);
            v.put("car_size",carSize);v.put("base_price",basePrice);v.put("subtotal",totals.subtotal);v.put("discount_type",totals.type);
            v.put("discount_value",totals.discountValue);v.put("discount_amount",totals.discountAmount);v.put("discount_reason",totals.reason);v.put("total",totals.total);
            v.put("worker_id",workerId);v.put("worker_name",workerName);v.put("payment_method","");v.put("cash_amount",0);v.put("card_amount",0);
            v.put("created_by_user_id",createdByUserId);v.put("created_by_user_name",createdByUserName==null?"":createdByUserName);
            long id=db.insertOrThrow("sales",null,v); replaceSaleItems(db,id,items); db.setTransactionSuccessful(); return id;
        }finally{db.endTransaction();}
    }

    public boolean completePendingSale(long id,List<Product> items,String discountType,double discountValue,String discountReason,
                                       String paymentMethod,double cashAmount,double cardAmount,long completedByUserId,String completedByUserName) {
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try{
            Cursor c=db.query("sales",new String[]{"base_price","status"},"id=?",new String[]{String.valueOf(id)},null,null,null);
            if(!c.moveToFirst()){c.close();return false;}
            double basePrice=c.getDouble(0); String status=c.getString(1); c.close();
            if(!"pending".equals(status))return false;
            Totals totals=calculateTotals(basePrice,items,discountType,discountValue,discountReason);
            String method=paymentMethod==null?"Cash":paymentMethod;
            double cash=Math.max(0,cashAmount),card=Math.max(0,cardAmount);
            if("Cash".equals(method)){cash=totals.total;card=0;}
            else if("Card".equals(method)){cash=0;card=totals.total;}
            else if("Split".equals(method)){
                if(Math.abs((cash+card)-totals.total)>0.01) throw new IllegalArgumentException("Split payment does not match total");
            } else {method="Card";cash=0;card=totals.total;}
            long now=System.currentTimeMillis(); String invoiceDay=dayKey(now);
            int invoiceNo=1; Cursor ic=db.rawQuery("SELECT COALESCE(MAX(invoice_no),0)+1 FROM sales WHERE invoice_day=? AND invoice_no>0",new String[]{invoiceDay});
            if(ic.moveToFirst())invoiceNo=ic.getInt(0);ic.close();
            ContentValues v=new ContentValues();
            v.put("invoice_day",invoiceDay);v.put("invoice_no",invoiceNo);v.put("completed_at",now);v.put("status","completed");
            v.put("subtotal",totals.subtotal);v.put("discount_type",totals.type);v.put("discount_value",totals.discountValue);v.put("discount_amount",totals.discountAmount);v.put("discount_reason",totals.reason);v.put("total",totals.total);
            v.put("payment_method",method);v.put("cash_amount",cash);v.put("card_amount",card);v.put("completed_by_user_id",completedByUserId);v.put("completed_by_user_name",completedByUserName==null?"":completedByUserName);
            if(db.update("sales",v,"id=? AND status='pending'",new String[]{String.valueOf(id)})!=1)return false;
            replaceSaleItems(db,id,items); db.setTransactionSuccessful(); return true;
        }finally{db.endTransaction();}
    }

    public Sale getSale(long id){
        Cursor c=getReadableDatabase().query("sales",null,"id=?",new String[]{String.valueOf(id)},null,null,null);
        Sale s=null;if(c.moveToFirst())s=readSale(c);c.close();if(s!=null)s.items=getSaleItems(id);return s;
    }

    public List<Sale> getPendingSales(){
        ArrayList<Sale> out=new ArrayList<>();
        Cursor c=getReadableDatabase().query("sales",null,"status='pending'",null,null,null,"created_at ASC");
        while(c.moveToNext()){Sale s=readSale(c);s.items=getSaleItems(s.id);out.add(s);}c.close();return out;
    }
    public int getPendingCount(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM sales WHERE status='pending'",null);int n=c.moveToFirst()?c.getInt(0):0;c.close();return n;}

    public boolean refundSale(long id,String reason){
        ContentValues v=new ContentValues();v.put("refunded",1);v.put("refunded_at",System.currentTimeMillis());v.put("refund_reason",reason==null?"":reason.trim());
        return getWritableDatabase().update("sales",v,"id=? AND status='completed' AND refunded=0",new String[]{String.valueOf(id)})>0;
    }

    public List<Product> getSaleItems(long saleId){
        ArrayList<Product> out=new ArrayList<>();Cursor c=getReadableDatabase().query("sale_items",null,"sale_id=?",new String[]{String.valueOf(saleId)},null,null,"id");
        while(c.moveToNext())out.add(new Product(c.getLong(c.getColumnIndexOrThrow("product_id")),c.getString(c.getColumnIndexOrThrow("name_ar")),c.getString(c.getColumnIndexOrThrow("name_en")),c.getDouble(c.getColumnIndexOrThrow("price")),true));
        c.close();return out;
    }

    public List<Sale> searchSales(String query,int limit){
        ArrayList<Sale> out=new ArrayList<>();String cleaned=query==null?"":query.trim().replace("#",""),q="%"+cleaned+"%";
        Cursor c=getReadableDatabase().query("sales",null,"status='completed' AND (plate LIKE ? OR phone LIKE ? OR CAST(invoice_no AS TEXT) LIKE ? OR invoice_day LIKE ?)",
                new String[]{q,q,q,q},null,null,"completed_at DESC",String.valueOf(limit));
        while(c.moveToNext())out.add(readSale(c));c.close();return out;
    }

    public List<Sale> getSalesInRange(long start,long end,int limit){
        ArrayList<Sale> out=new ArrayList<>();
        Cursor c=getReadableDatabase().query("sales",null,"status='completed' AND completed_at>=? AND completed_at<?",
                new String[]{String.valueOf(start),String.valueOf(end)},null,null,"completed_at DESC",limit>0?String.valueOf(limit):null);
        while(c.moveToNext())out.add(readSale(c));c.close();return out;
    }

    public int getTodayWashCount(){
        Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM sales WHERE status='completed' AND completed_at>=? AND completed_at<?",
                new String[]{String.valueOf(startOfToday()),String.valueOf(startOfTomorrow())});
        int count=c.moveToFirst()?c.getInt(0):0;c.close();return count;
    }

    public DailySummary getSummary(long start,long end){
        DailySummary s=new DailySummary();String[] args={String.valueOf(start),String.valueOf(end)};
        Cursor sales=getReadableDatabase().rawQuery(
                "SELECT COUNT(*),COALESCE(SUM(total),0),COALESCE(SUM(cash_amount),0),COALESCE(SUM(card_amount),0) FROM sales WHERE status='completed' AND completed_at>=? AND completed_at<?",args);
        if(sales.moveToFirst()){s.totalCars=sales.getInt(0);s.cars=s.totalCars;s.grossSales=sales.getDouble(1);s.cashGross=sales.getDouble(2);s.cardGross=sales.getDouble(3);}sales.close();
        Cursor refunds=getReadableDatabase().rawQuery(
                "SELECT COUNT(*),COALESCE(SUM(total),0),COALESCE(SUM(cash_amount),0),COALESCE(SUM(card_amount),0) FROM sales WHERE status='completed' AND refunded=1 AND refunded_at>=? AND refunded_at<?",args);
        if(refunds.moveToFirst()){s.refundedCars=refunds.getInt(0);s.refunds=refunds.getDouble(1);s.cashRefunds=refunds.getDouble(2);s.cardRefunds=refunds.getDouble(3);}refunds.close();
        s.sales=s.grossSales-s.refunds;s.cashNet=s.cashGross-s.cashRefunds;s.cardNet=s.cardGross-s.cardRefunds;s.paymentNet=s.cashNet+s.cardNet;

        Cursor w=getReadableDatabase().rawQuery(
                "SELECT COALESCE(e.name,x.worker_name), " +
                        "SUM(CASE WHEN x.status='completed' AND x.completed_at>=? AND x.completed_at<? THEN 1 ELSE 0 END), " +
                        "SUM(CASE WHEN x.status='completed' AND x.refunded=1 AND x.refunded_at>=? AND x.refunded_at<? THEN 1 ELSE 0 END) " +
                        "FROM sales x LEFT JOIN employees e ON e.id=x.worker_id " +
                        "WHERE (x.status='completed' AND x.completed_at>=? AND x.completed_at<?) OR (x.status='completed' AND x.refunded=1 AND x.refunded_at>=? AND x.refunded_at<?) " +
                        "GROUP BY x.worker_id,COALESCE(e.name,x.worker_name) ORDER BY 2 DESC,1 COLLATE NOCASE",
                new String[]{String.valueOf(start),String.valueOf(end),String.valueOf(start),String.valueOf(end),String.valueOf(start),String.valueOf(end),String.valueOf(start),String.valueOf(end)});
        while(w.moveToNext()){int washes=w.getInt(1),refundCount=w.getInt(2);s.workerCounts.add(new WorkerCount(w.getString(0),washes,refundCount,washes));}w.close();

        Cursor addon=getReadableDatabase().rawQuery(
                "SELECT si.name_ar,si.name_en,COUNT(*) c FROM sale_items si JOIN sales x ON x.id=si.sale_id " +
                        "WHERE x.status='completed' AND x.completed_at>=? AND x.completed_at<? GROUP BY si.name_ar,si.name_en ORDER BY c DESC,si.name_en LIMIT 1",args);
        if(addon.moveToFirst()){s.topAddOnAr=addon.getString(0);s.topAddOnEn=addon.getString(1);s.topAddOnCount=addon.getInt(2);}addon.close();
        Cursor car=getReadableDatabase().rawQuery(
                "SELECT car_size,COUNT(*) c FROM sales WHERE status='completed' AND completed_at>=? AND completed_at<? GROUP BY car_size ORDER BY c DESC,car_size LIMIT 1",args);
        if(car.moveToFirst()){s.topCarSize=car.getString(0);s.topCarSizeCount=car.getInt(1);}car.close();
        return s;
    }

    public List<DaySummary> getDailyBreakdown(long start,long end){
        ArrayList<DaySummary> out=new ArrayList<>();Calendar c=Calendar.getInstance();c.setTimeInMillis(start);
        c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
        while(c.getTimeInMillis()<end){long dayStart=c.getTimeInMillis();c.add(Calendar.DATE,1);long dayEnd=Math.min(c.getTimeInMillis(),end);DailySummary summary=getSummary(Math.max(dayStart,start),dayEnd);if(summary.totalCars>0||summary.refundedCars>0||dayStart>=start)out.add(new DaySummary(dayStart,summary));}
        return out;
    }

    public boolean hasAnyAppUsers(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM app_users",null);boolean yes=c.moveToFirst()&&c.getInt(0)>0;c.close();return yes;}
    public long createManager(String name,String pin){
        ContentValues v=new ContentValues();v.put("name",name==null||name.trim().isEmpty()?"المدير":name.trim());v.put("pin_hash",hashPin(pin));v.put("role","manager");v.put("active",1);
        v.put("can_new_sale",1);v.put("can_view_invoices",1);v.put("can_reports",1);v.put("can_search",1);v.put("can_refund",1);v.put("can_discount",1);
        return getWritableDatabase().insertOrThrow("app_users",null,v);
    }
    public long addAppUser(String name,String pin,boolean canNewSale,boolean canViewInvoices,boolean canReports,boolean canSearch,boolean canRefund,boolean canDiscount){
        ContentValues v=new ContentValues();v.put("name",name.trim());v.put("pin_hash",hashPin(pin));v.put("role","employee");v.put("active",1);
        v.put("can_new_sale",canNewSale?1:0);v.put("can_view_invoices",canViewInvoices?1:0);v.put("can_reports",canReports?1:0);v.put("can_search",canSearch?1:0);v.put("can_refund",canRefund?1:0);v.put("can_discount",canDiscount?1:0);
        return getWritableDatabase().insertOrThrow("app_users",null,v);
    }
    public void updateAppUser(long id,String name,boolean canNewSale,boolean canViewInvoices,boolean canReports,boolean canSearch,boolean canRefund,boolean canDiscount){
        AppUser current=getAppUser(id);if(current==null||current.isManager())return;
        ContentValues v=new ContentValues();v.put("name",name.trim());v.put("can_new_sale",canNewSale?1:0);v.put("can_view_invoices",canViewInvoices?1:0);v.put("can_reports",canReports?1:0);v.put("can_search",canSearch?1:0);v.put("can_refund",canRefund?1:0);v.put("can_discount",canDiscount?1:0);
        getWritableDatabase().update("app_users",v,"id=?",new String[]{String.valueOf(id)});
    }
    public void updateUserPin(long id,String pin){ContentValues v=new ContentValues();v.put("pin_hash",hashPin(pin));getWritableDatabase().update("app_users",v,"id=?",new String[]{String.valueOf(id)});}
    public void setAppUserActive(long id,boolean active){AppUser u=getAppUser(id);if(u==null||u.isManager())return;ContentValues v=new ContentValues();v.put("active",active?1:0);getWritableDatabase().update("app_users",v,"id=?",new String[]{String.valueOf(id)});}
    public AppUser authenticateUser(String pin){
        Cursor c=getReadableDatabase().query("app_users",null,"pin_hash=? AND active=1",new String[]{hashPin(pin)},null,null,null,"1");
        AppUser u=c.moveToFirst()?readAppUser(c):null;c.close();return u;
    }
    public AppUser getAppUser(long id){Cursor c=getReadableDatabase().query("app_users",null,"id=?",new String[]{String.valueOf(id)},null,null,null);AppUser u=c.moveToFirst()?readAppUser(c):null;c.close();return u;}
    public List<AppUser> getAppUsers(){ArrayList<AppUser> out=new ArrayList<>();Cursor c=getReadableDatabase().query("app_users",null,null,null,null,null,"CASE role WHEN 'manager' THEN 0 ELSE 1 END,name COLLATE NOCASE");while(c.moveToNext())out.add(readAppUser(c));c.close();return out;}
    private AppUser readAppUser(Cursor c){
        AppUser u=new AppUser();u.id=c.getLong(c.getColumnIndexOrThrow("id"));u.name=c.getString(c.getColumnIndexOrThrow("name"));u.role=c.getString(c.getColumnIndexOrThrow("role"));u.active=c.getInt(c.getColumnIndexOrThrow("active"))==1;
        boolean manager="manager".equals(u.role);u.canNewSale=manager||c.getInt(c.getColumnIndexOrThrow("can_new_sale"))==1;u.canViewInvoices=manager||c.getInt(c.getColumnIndexOrThrow("can_view_invoices"))==1;u.canReports=manager||c.getInt(c.getColumnIndexOrThrow("can_reports"))==1;u.canSearch=manager||c.getInt(c.getColumnIndexOrThrow("can_search"))==1;u.canRefund=manager||c.getInt(c.getColumnIndexOrThrow("can_refund"))==1;u.canDiscount=manager||c.getInt(c.getColumnIndexOrThrow("can_discount"))==1;return u;
    }
    private static String hashPin(String pin){
        try{MessageDigest md=MessageDigest.getInstance("SHA-256");byte[] bytes=md.digest((pin==null?"":pin).getBytes("UTF-8"));StringBuilder sb=new StringBuilder();for(byte b:bytes)sb.append(String.format(Locale.US,"%02x",b&0xff));return sb.toString();}catch(Exception e){throw new RuntimeException(e);}
    }

    public String exportAllJson() throws Exception{
        JSONObject root=new JSONObject();root.put("version",5);root.put("exported_at",System.currentTimeMillis());
        root.put("employees",tableToJson("SELECT * FROM employees ORDER BY id"));root.put("products",tableToJson("SELECT * FROM products ORDER BY id"));root.put("wash_types",tableToJson("SELECT * FROM wash_types ORDER BY id"));root.put("sales",tableToJson("SELECT * FROM sales ORDER BY id"));root.put("sale_items",tableToJson("SELECT * FROM sale_items ORDER BY id"));root.put("app_users",tableToJson("SELECT * FROM app_users ORDER BY id"));
        return root.toString(2);
    }
    private JSONArray tableToJson(String sql)throws Exception{
        JSONArray arr=new JSONArray();Cursor c=getReadableDatabase().rawQuery(sql,null);String[] cols=c.getColumnNames();
        while(c.moveToNext()){JSONObject row=new JSONObject();for(int i=0;i<cols.length;i++){int type=c.getType(i);if(type==Cursor.FIELD_TYPE_INTEGER)row.put(cols[i],c.getLong(i));else if(type==Cursor.FIELD_TYPE_FLOAT)row.put(cols[i],c.getDouble(i));else if(type==Cursor.FIELD_TYPE_NULL)row.put(cols[i],JSONObject.NULL);else row.put(cols[i],c.getString(i));}arr.put(row);}c.close();return arr;
    }

    private Sale readSale(Cursor c){
        Sale s=new Sale();s.id=c.getLong(c.getColumnIndexOrThrow("id"));s.invoiceNo=c.getInt(c.getColumnIndexOrThrow("invoice_no"));s.invoiceDay=c.getString(c.getColumnIndexOrThrow("invoice_day"));
        s.createdAt=c.getLong(c.getColumnIndexOrThrow("created_at"));int completedIndex=c.getColumnIndex("completed_at");s.completedAt=completedIndex>=0?c.getLong(completedIndex):s.createdAt;int statusIndex=c.getColumnIndex("status");s.status=statusIndex>=0?c.getString(statusIndex):"completed";
        s.plate=c.getString(c.getColumnIndexOrThrow("plate"));s.phone=c.getString(c.getColumnIndexOrThrow("phone"));s.leaving=c.getInt(c.getColumnIndexOrThrow("customer_leaving"))==1;s.carSize=c.getString(c.getColumnIndexOrThrow("car_size"));s.basePrice=c.getDouble(c.getColumnIndexOrThrow("base_price"));
        s.subtotal=c.getDouble(c.getColumnIndexOrThrow("subtotal"));s.discountType=c.getString(c.getColumnIndexOrThrow("discount_type"));s.discountValue=c.getDouble(c.getColumnIndexOrThrow("discount_value"));s.discountAmount=c.getDouble(c.getColumnIndexOrThrow("discount_amount"));s.discountReason=c.getString(c.getColumnIndexOrThrow("discount_reason"));s.total=c.getDouble(c.getColumnIndexOrThrow("total"));
        s.workerId=c.getLong(c.getColumnIndexOrThrow("worker_id"));s.workerName=c.getString(c.getColumnIndexOrThrow("worker_name"));s.paymentMethod=c.getString(c.getColumnIndexOrThrow("payment_method"));s.cashAmount=c.getDouble(c.getColumnIndexOrThrow("cash_amount"));s.cardAmount=c.getDouble(c.getColumnIndexOrThrow("card_amount"));s.refunded=c.getInt(c.getColumnIndexOrThrow("refunded"))==1;s.refundedAt=c.getLong(c.getColumnIndexOrThrow("refunded_at"));s.refundReason=c.getString(c.getColumnIndexOrThrow("refund_reason"));
        int x=c.getColumnIndex("created_by_user_id");if(x>=0)s.createdByUserId=c.getLong(x);x=c.getColumnIndex("created_by_user_name");if(x>=0)s.createdByUserName=c.getString(x);x=c.getColumnIndex("completed_by_user_id");if(x>=0)s.completedByUserId=c.getLong(x);x=c.getColumnIndex("completed_by_user_name");if(x>=0)s.completedByUserName=c.getString(x);
        return s;
    }

    private static String dayKey(long time){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date(time));}
    public static long startOfToday(){return startOfDay(System.currentTimeMillis());}
    public static long startOfTomorrow(){Calendar c=Calendar.getInstance();c.setTimeInMillis(startOfToday());c.add(Calendar.DATE,1);return c.getTimeInMillis();}
    public static long startOfDay(long time){Calendar c=Calendar.getInstance();c.setTimeInMillis(time);c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.getTimeInMillis();}
    public static long startOfMonth(){return startOfMonth(System.currentTimeMillis());}
    public static long startOfMonth(long time){Calendar c=Calendar.getInstance();c.setTimeInMillis(time);c.set(Calendar.DAY_OF_MONTH,1);c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.getTimeInMillis();}
    public static long startOfNextMonth(){return startOfNextMonth(System.currentTimeMillis());}
    public static long startOfNextMonth(long time){Calendar c=Calendar.getInstance();c.setTimeInMillis(startOfMonth(time));c.add(Calendar.MONTH,1);return c.getTimeInMillis();}

    private static class Totals{double subtotal,discountValue,discountAmount,total;String type,reason;Totals(double s,String t,double dv,double da,String r,double total){subtotal=s;type=t;discountValue=dv;discountAmount=da;reason=r;this.total=total;}}
    public static class Employee{public long id;public String name;public boolean active;public Employee(long id,String name,boolean active){this.id=id;this.name=name;this.active=active;}@Override public String toString(){return name;}}
    public static class WashType{public long id;public String nameAr,nameEn;public double price;public boolean active;public WashType(long id,String ar,String en,double price,boolean active){this.id=id;nameAr=ar;nameEn=en;this.price=price;this.active=active;}@Override public String toString(){return nameAr+" - "+price;}}
    public static class Product{public long id;public String nameAr,nameEn;public double price;public boolean active;public Product(long id,String ar,String en,double price,boolean active){this.id=id;nameAr=ar;nameEn=en;this.price=price;this.active=active;}}
    public static class Sale{
        public long id,createdAt,completedAt,workerId,refundedAt,createdByUserId,completedByUserId;public int invoiceNo;
        public String invoiceDay,status,plate,phone,carSize,workerName,paymentMethod,discountType,discountReason,refundReason,createdByUserName="",completedByUserName="";
        public boolean leaving,refunded;public double basePrice,subtotal,discountValue,discountAmount,total,cashAmount,cardAmount;public List<Product> items=new ArrayList<>();
        public boolean isPending(){return "pending".equals(status);} public long durationMs(){return completedAt>createdAt?completedAt-createdAt:Math.max(0,System.currentTimeMillis()-createdAt);}
    }
    public static class AppUser{
        public long id;public String name,role;public boolean active,canNewSale,canViewInvoices,canReports,canSearch,canRefund,canDiscount;
        public boolean isManager(){return "manager".equals(role);}@Override public String toString(){return name;}
    }
    public static class WorkerCount{public String name;public int count,refundCount,totalCount;public WorkerCount(String n,int c,int r,int total){name=n;count=c;refundCount=r;totalCount=total;}}
    public static class DailySummary{
        public int cars,totalCars,refundedCars;public double sales,grossSales,refunds,cashGross,cardGross,cashRefunds,cardRefunds,cashNet,cardNet,paymentNet;
        public String topAddOnAr="",topAddOnEn="",topCarSize="";public int topAddOnCount,topCarSizeCount;public List<WorkerCount> workerCounts=new ArrayList<>();
    }
    public static class DaySummary{public long dayStart;public DailySummary summary;public DaySummary(long dayStart,DailySummary summary){this.dayStart=dayStart;this.summary=summary;}}
}
