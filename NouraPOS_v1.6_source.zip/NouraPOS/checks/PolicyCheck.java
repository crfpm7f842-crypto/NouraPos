import java.util.*;
import com.noura.carwash.pos.AccessPolicy;
public class PolicyCheck {
 static long at(int y,int m,int d,int h,int min){Calendar c=Calendar.getInstance();c.clear();c.set(y,m-1,d,h,min);return c.getTimeInMillis();}
 static void check(boolean condition,String message){if(!condition)throw new AssertionError(message);}
 public static void main(String[] args){
  TimeZone.setDefault(TimeZone.getTimeZone("Asia/Riyadh"));
  long before=at(2026,11,2,23,59),after=at(2026,11,3,0,0);
  long[] a=AccessPolicy.reportRange(false,0,Long.MAX_VALUE,before);
  check(a[0]==at(2026,11,2,0,0)&&a[1]==after,"Employee month request must resolve to today");
  long[] b=AccessPolicy.reportRange(false,a[0],a[1],after);
  check(b[0]==after&&b[1]==at(2026,11,4,0,0),"Stale PDF request after midnight must use new day");
  long[] m=AccessPolicy.reportRange(true,100,500,before);check(m[0]==100&&m[1]==500,"Manager keeps custom time range");
  try{AccessPolicy.reportRange(true,500,100,before);throw new AssertionError("Invalid range accepted");}catch(IllegalArgumentException expected){}
  TimeZone.setDefault(TimeZone.getTimeZone("America/New_York"));
  long[] dst=AccessPolicy.reportRange(false,0,1,at(2026,11,1,12,0));check(dst[1]-dst[0]==25L*60*60*1000,"Calendar boundary must handle DST");
  System.out.println("PASS: today restriction, stale export at midnight, manager ranges, invalid range, DST (5)");
 }
}
