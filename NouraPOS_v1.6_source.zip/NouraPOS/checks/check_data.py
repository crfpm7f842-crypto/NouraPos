from pathlib import Path
import re, sqlite3, json, zipfile, copy
root=Path(__file__).resolve().parent.parent
new=(root/'app/src/main/java/com/noura/carwash/pos/DBHelper.java').read_text()
def method(text,signature):
 a=text.index(signature); a=text.index('{',a); depth=1;i=a+1
 # Java SQL strings have no braces in these specific schema methods.
 while depth:
  depth += (text[i]=='{')-(text[i]=='}');i+=1
 return text[a+1:i-1]
def literal(expression): return ''.join(json.loads(t) for t in re.findall(r'"(?:[^"\\]|\\.)*"',expression))
def execs(db,body):
 for expr in re.findall(r'(?:db|database)\.execSQL\((.*?)\);',body,re.S): db.execute(literal(expr))
db=sqlite3.connect(':memory:')
db.executescript((root/'checks/schema_v9.sql').read_text())
# Actual existing rows, including customized prices, disabled entries and old invoices.
db.execute("INSERT INTO employees VALUES(7,'Mahbob',1)")
db.execute("INSERT INTO wash_types VALUES(21,'غسيل صغير','Small Wash',33,1)")
db.execute("INSERT INTO products VALUES(50,'إضافة خاصة','Custom extra',8,0)")
db.execute("INSERT INTO app_users(id,name,pin_hash,role,can_reports) VALUES(1,'Manager',?,'manager',1)",('a'*64,))
db.execute("INSERT INTO app_users(id,name,pin_hash,role,can_reports) VALUES(2,'Cashier',?,'employee',0)",('b'*64,))
db.execute("INSERT INTO sales(id,invoice_day,invoice_no,created_at,completed_at,status,plate,car_size,base_price,subtotal,total,worker_id,worker_name,payment_method,cash_amount) VALUES(91,'2026-10-01',1,100,200,'completed','1234','غسيل صغير',33,41,41,7,'Mahbob','Cash',41)")
db.execute("INSERT INTO sale_items VALUES(1,91,50,'إضافة خاصة','Custom extra',8)")
tables=['employees','wash_types','products','sales','sale_items']
snapshot={t:db.execute('SELECT * FROM '+t).fetchall() for t in tables}
execs(db,method(new,'void createAuditTable('))
upgrade=re.search(r'if \(oldVersion < 10\) \{(.*?)\n        \}',new,re.S).group(1);execs(db,upgrade);execs(db,method(new,'void createIndexes('))
for t,rows in snapshot.items(): assert rows==db.execute('SELECT * FROM '+t).fetchall(),t
assert db.execute('SELECT can_reports FROM app_users WHERE id=2').fetchone()[0]==1
print('PASS: v9→v10 preserves customized prices, inactive extras, workers, invoices and sale items; employee reports enabled')
tables=['employees','products','wash_types','app_users','sales','sale_items','audit_log']
for table in tables:
 c=db.execute('SELECT * FROM '+table);cols=[d[0] for d in c.description]
 snapshot[table]=[dict(zip(cols,row)) for row in c.fetchall()]
validators=[literal(x) for x in re.findall(r'assertNoRows\(database,(".*?")\);',new)]
def restore(data):
 with db:
  for table in tables:db.execute('DELETE FROM '+table)
  db.execute('DELETE FROM sqlite_sequence')
  for table in tables:
   for row in data[table]: db.execute('INSERT INTO '+table+'('+','.join(row)+') VALUES('+','.join('?' for _ in row)+')',list(row.values()))
  for sql in validators: assert db.execute(sql).fetchone() is None,sql
  assert db.execute("SELECT 1 FROM app_users WHERE role='manager' AND active=1").fetchone()
restore(snapshot)
original=db.execute('SELECT * FROM sales').fetchall()
for label,change in [
 ('orphan item',lambda x:x['sale_items'][0].update(sale_id=999)),
 ('bad payment',lambda x:x['sales'][0].update(cash_amount=999)),
 ('invalid PIN',lambda x:x['app_users'][0].update(pin_hash='broken')),
 ('no manager',lambda x:x['app_users'][0].update(active=0)),
 ('duplicate invoice',lambda x:x['sales'].append(dict(x['sales'][0],id=92))),
 ('negative price',lambda x:x['products'][0].update(price=-5))]:
 bad=copy.deepcopy(snapshot);change(bad)
 try:restore(bad)
 except (AssertionError,sqlite3.IntegrityError):pass
 else:raise AssertionError('accepted '+label)
 assert db.execute('SELECT * FROM sales').fetchall()==original,'rollback '+label
print('PASS: SQL round trip and rollback on six malformed backups')
# The conditional updates and the audit insert must commit as a single transaction.
try:
 with db:
  db.execute("UPDATE sales SET refunded=1,refunded_at=300 WHERE id=91 AND refunded=0")
  db.execute("INSERT INTO audit_log(occurred_at,actor_id,actor_name,action,reason) VALUES(300,1,NULL,'refund','test')")
except sqlite3.IntegrityError:pass
assert db.execute('SELECT refunded FROM sales WHERE id=91').fetchone()[0]==0
with db:
 changed=db.execute("UPDATE sales SET refunded=1,refunded_at=300,refund_reason='test' WHERE id=91 AND status='completed' AND refunded=0").rowcount
 assert changed==1
 db.execute("INSERT INTO audit_log(occurred_at,actor_id,actor_name,action,sale_id,reason) VALUES(300,1,'Manager','refund',91,'test')")
 assert db.execute("UPDATE sales SET refunded=1 WHERE id=91 AND refunded=0").rowcount==0
assert db.execute('SELECT COUNT(*) FROM audit_log').fetchone()[0]==1
print('PASS: audit failure rolls back refund; duplicate refund changes no rows')
# Verify report export routes use the shared authorization policy.
ui=(root/'app/src/main/java/com/noura/carwash/pos/MainActivity.java').read_text()
export=(root/'app/src/main/java/com/noura/carwash/pos/DocumentExporter.java').read_text()
assert ui.count('createReportPdf(this,db,currentUser.id,')==3
assert 'db.reportRange(actorId,start,end)' in export
assert 'worker.getSelectedItem' not in ui
print('PASS: all three PDF entry points carry user identity; worker spinner removed')
