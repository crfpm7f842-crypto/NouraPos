package com.noura.carwash.pos;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import org.json.JSONObject;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int RED = Color.rgb(236,34,36);
    private static final int GRAY = Color.rgb(51,51,51);
    private static final int SMOKE = Color.rgb(242,242,242);

    private DBHelper db;
    private SharedPreferences prefs;
    private SunmiPrinterBridge printer;
    private boolean arabic = true;
    private LinearLayout root;
    private DBHelper.AppUser currentUser;
    private static final int SAVE_BACKUP=2001,OPEN_BACKUP=2002;
    private boolean reportScreen=false;
    private final Handler reportClock=new Handler();
    private final Runnable reportRefresh=()->{if(reportScreen && !isFinishing())showReports();};

    @Override protected void onResume(){super.onResume();if(reportScreen)showReports();}


    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new DBHelper(this);
        prefs = getSharedPreferences("noura_settings", MODE_PRIVATE);
        arabic = prefs.getBoolean("arabic", true);
        printer = new SunmiPrinterBridge(this);
        printer.connect();
        requestLegacyStoragePermissionIfNeeded();
        bootstrapAccounts();
    }

    private void bootstrapAccounts() {
        if (!db.hasAnyAppUsers()) {
            String oldPin = prefs.getString("admin_pin", "");
            if (oldPin.matches("\\d{4}")) {
                try {
                    long id = db.createManager("المدير", oldPin);
                    prefs.edit().putLong("session_user_id", id).apply();
                } catch (Exception ignored) { }
            }
        }
        long sessionId = prefs.getLong("session_user_id", 0);
        if (sessionId > 0) {
            DBHelper.AppUser session = db.getAppUser(sessionId);
            if (session != null && session.active) currentUser = session;
            else prefs.edit().remove("session_user_id").apply();
        }
        if (!db.hasAnyAppUsers()) showManagerSetup();
        else if (currentUser == null) showLogin();
        else showHome();
    }

    private void showManagerSetup() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18),dp(28),dp(18),dp(18));
        root.setBackgroundColor(Color.WHITE);
        ImageView logo = new ImageView(this); logo.setImageResource(R.drawable.noura_logo); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        root.addView(logo,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(90)));
        root.addView(heading(t("إنشاء حساب المدير", "Create Manager Account")));
        root.addView(text(t("هذا الإعداد يتم مرة واحدة فقط. حساب المدير يملك جميع الصلاحيات.", "This setup is required once. The manager account has all permissions."),15,Color.GRAY));
        EditText name = field(t("اسم المدير", "Manager name"),false); root.addView(name);
        EditText pin = pinField(t("PIN المدير - 4 أرقام", "Manager PIN - 4 digits")); root.addView(pin);
        EditText confirm = pinField(t("تأكيد PIN", "Confirm PIN")); root.addView(confirm);
        Button save = primaryButton(t("إنشاء الحساب", "Create Account")); root.addView(save);
        save.setOnClickListener(v -> {
            String p1=pin.getText().toString().trim(),p2=confirm.getText().toString().trim();
            if(!p1.matches("\\d{4}")){toast(t("PIN يجب أن يكون 4 أرقام","PIN must be 4 digits"));return;}
            if(!p1.equals(p2)){toast(t("رمزا PIN غير متطابقين","PINs do not match"));return;}
            try{
                long id=db.createManager(name.getText().toString(),p1);
                currentUser=db.getAppUser(id);
                prefs.edit().putLong("session_user_id",id).apply();
                LocalBackupManager.backup(this,db);
                showHome();
            }catch(Exception e){toast(t("تعذر إنشاء الحساب","Could not create account"));}
        });
        Button lang=smallButton(arabic?"EN":"عربي");lang.setOnClickListener(v->{arabic=!arabic;prefs.edit().putBoolean("arabic",arabic).apply();showManagerSetup();});
        root.addView(lang,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(48)));
        setContentView(root);
    }

    private void showLogin() {
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(30),dp(18),dp(18));root.setBackgroundColor(Color.WHITE);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.noura_logo);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);root.addView(logo,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(100)));
        root.addView(heading(t("تسجيل الدخول","Login")));
        root.addView(text(t("أدخل رقمك الخاص للدخول","Enter your personal PIN"),16,Color.GRAY));
        EditText pin=pinField(t("PIN من 4 أرقام","4-digit PIN"));root.addView(pin);
        Button login=primaryButton(t("دخول","Login"));root.addView(login);
        login.setOnClickListener(v->{
            DBHelper.AppUser u=db.authenticateUser(pin.getText().toString().trim());
            if(u==null){toast(t("الرقم غير صحيح أو الحساب موقوف","Incorrect PIN or account is disabled"));return;}
            currentUser=u;prefs.edit().putLong("session_user_id",u.id).apply();showHome();
        });
        pin.setOnEditorActionListener((v,actionId,event)->{if(actionId==EditorInfo.IME_ACTION_DONE){login.performClick();return true;}return false;});
        Button lang=smallButton(arabic?"EN":"عربي");lang.setOnClickListener(v->{arabic=!arabic;prefs.edit().putBoolean("arabic",arabic).apply();showLogin();});
        root.addView(lang,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(48)));
        setContentView(root);
        pin.requestFocus();
    }

    private void logout() {
        prefs.edit().remove("session_user_id").apply();
        currentUser=null;
        showLogin();
    }

    private boolean isManager(){return currentUser!=null&&currentUser.isManager();}
    private boolean require(boolean allowed){
        if(currentUser==null){showLogin();return false;}
        if(!allowed){toast(t("ليس لديك صلاحية لهذه العملية","You do not have permission for this action"));return false;}
        return true;
    }

    private void requestLegacyStoragePermissionIfNeeded() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1001);
        }
    }

    @Override protected void onDestroy() {
        reportClock.removeCallbacks(reportRefresh);
        printer.disconnect();
        db.close();
        super.onDestroy();
    }

    private String t(String ar,String en){return arabic?ar:en;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}

    private void baseScreen(boolean home) {
        reportScreen=false;reportClock.removeCallbacks(reportRefresh);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.WHITE);
        root.setLayoutDirection(arabic?View.LAYOUT_DIRECTION_RTL:View.LAYOUT_DIRECTION_LTR);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(12),dp(6),dp(12),dp(6));header.setBackgroundColor(Color.rgb(24,24,24));
        TextView title=text(t("مغسلة نوره","NOURA CAR WASH"),24,Color.WHITE);title.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(title,new LinearLayout.LayoutParams(0,dp(52),1));title.setGravity(Gravity.CENTER_VERTICAL);
        Button action=smallButton(home?(arabic?"EN":"عربي"):t("رجوع","Back"));action.setTextColor(Color.WHITE);action.setBackgroundColor(Color.TRANSPARENT);
        action.setOnClickListener(v->{if(home){arabic=!arabic;prefs.edit().putBoolean("arabic",arabic).apply();}showHome();});header.addView(action,new LinearLayout.LayoutParams(dp(72),dp(48)));
        root.addView(header);setContentView(root);
    }
    private ScrollView contentScroll(){ScrollView sv=new ScrollView(this);root.addView(sv,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));return sv;}
    private LinearLayout stack(ScrollView sv){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),dp(8),dp(12),dp(18));sv.addView(box,new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));return box;}

    private void showHome() {
        if(currentUser==null){showLogin();return;}
        currentUser=db.getAppUser(currentUser.id);
        if(currentUser==null||!currentUser.active){logout();return;}
        baseScreen(true);LinearLayout box=stack(contentScroll());
        TextView account=text(currentUser.name+" • "+(isManager()?t("مدير","Manager"):t("موظف","Employee")),16,GRAY);account.setPadding(0,dp(8),0,dp(12));box.addView(account);
        LinearLayout summary=card();summary.setBackground(round(Color.rgb(24,24,24),Color.rgb(24,24,24),10));summary.setGravity(Gravity.CENTER_VERTICAL);
        TextView label=text(t("سيارات اليوم","Cars today"),22,Color.WHITE);summary.addView(label,new LinearLayout.LayoutParams(0,dp(84),1));label.setGravity(Gravity.CENTER_VERTICAL);
        TextView count=text(String.valueOf(db.getTodayWashCount()),40,Color.WHITE);summary.addView(count);box.addView(summary);
        if(currentUser.canNewSale){Button order=primaryButton(t("فاتورة جديدة","New invoice"));order.setOnClickListener(v->showOrder());box.addView(order);}
        List<Button> tiles=new ArrayList<>();
        if(currentUser.canNewSale){Button x=homeTile(t("قيد التحضير","In preparation")+"\n"+db.getPendingCount());x.setOnClickListener(v->showPendingOrders());tiles.add(x);}
        if(currentUser.canViewInvoices){Button x=homeTile(t("الفواتير","Invoices"));x.setOnClickListener(v->showInvoices());tiles.add(x);}
        if(currentUser.canReports){Button x=homeTile(t("التقارير","Reports"));x.setOnClickListener(v->showReports());tiles.add(x);}
        if(isManager()){Button x=homeTile(t("الإعدادات","Settings"));x.setOnClickListener(v->showAdmin());tiles.add(x);}
        addButtonGrid(box,tiles,108);
        if(currentUser.canSearch){Button search=smallButton(t("البحث عن فاتورة","Find invoice"));search.setOnClickListener(v->showSearch());box.addView(search,new LinearLayout.LayoutParams(-1,dp(48)));}
        Button exit=smallButton(t("تسجيل الخروج","Log out"));exit.setTextColor(RED);exit.setOnClickListener(v->logout());box.addView(exit,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView version=text("Noura POS 1.6.0",12,Color.GRAY);version.setGravity(Gravity.CENTER);box.addView(version);
    }

    private Button homeTile(String label){Button b=menuButton(label);b.setGravity(Gravity.CENTER);b.setTextSize(21);b.setTypeface(Typeface.DEFAULT_BOLD);b.setBackground(round(Color.WHITE,RED,10));return b;}
    private void addButtonGrid(LinearLayout parent,List<Button> buttons,int height){
        for(int i=0;i<buttons.size();i+=2){LinearLayout row=new LinearLayout(this);parent.addView(row);
            for(int j=i;j<Math.min(i+2,buttons.size());j++){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(height),1);lp.setMargins(dp(3),dp(4),dp(3),dp(4));row.addView(buttons.get(j),lp);}
            if(i+1==buttons.size())row.addView(new View(this),new LinearLayout.LayoutParams(0,dp(height),1));
        }
    }

    private void showOrder() {
        if(!require(currentUser!=null && currentUser.canNewSale))return;
        baseScreen(false);LinearLayout box=stack(contentScroll());box.addView(heading(t("فاتورة جديدة","New Order")));
        EditText plate=plateField();box.addView(plate);
        List<DBHelper.Employee> employees=db.getEmployees(true);
        final DBHelper.Employee[] selectedWorker={null};
        box.addView(sectionTitle(t("اختر العامل","Choose worker")));
        TextView workerStatus=text(t("اضغط على اسم العامل","Tap a worker's name"),15,GRAY);box.addView(workerStatus);
        List<Button> workerButtons=new ArrayList<>();
        for(DBHelper.Employee employee:employees){
            Button button=menuButton(employee.name);button.setGravity(Gravity.CENTER);button.setTextSize(18);button.setPadding(dp(4),0,dp(4),0);
            button.setBackground(round(Color.WHITE,Color.LTGRAY,10));
            button.setOnClickListener(v->{
                selectedWorker[0]=employee;workerStatus.setText(t("العامل المختار: ","Selected worker: ")+employee.name);
                for(int i=0;i<workerButtons.size();i++){boolean chosen=employees.get(i).id==employee.id;Button item=workerButtons.get(i);item.setSelected(chosen);item.setTextColor(chosen?Color.WHITE:GRAY);item.setBackground(round(chosen?RED:Color.WHITE,chosen?RED:Color.LTGRAY,10));}
            });workerButtons.add(button);
        }
        addButtonGrid(box,workerButtons,64);
        if(employees.isEmpty())box.addView(text(t("أضف العمال من الإعدادات أولاً","Add workers in Settings first"),15,RED));
        RadioGroup stayGroup=new RadioGroup(this);stayGroup.setOrientation(LinearLayout.HORIZONTAL);
        RadioButton waiting=radio(t("ينتظر","Waiting")),leaving=radio(t("سيغادر","Leaving"));stayGroup.addView(waiting);stayGroup.addView(leaving);waiting.setChecked(true);box.addView(stayGroup);
        EditText phone=field(t("رقم العميل (مطلوب عند المغادرة)","Phone (required if leaving)"),true);box.addView(phone);
        LinearLayout tabs=new LinearLayout(this);Button washesTab=primaryButton(t("الغسيل","Wash")),extrasTab=smallButton(t("الإضافات","Extras"));tabs.addView(washesTab,new LinearLayout.LayoutParams(0,dp(48),1));tabs.addView(extrasTab,new LinearLayout.LayoutParams(0,dp(48),1));box.addView(tabs);
        LinearLayout washPanel=new LinearLayout(this);washPanel.setOrientation(LinearLayout.VERTICAL);box.addView(washPanel);
        List<DBHelper.WashType> washes=db.getWashTypes(true);final DBHelper.WashType[] selected={washes.isEmpty()?null:washes.get(0)};
        final String[] discountType={"none"},discountReason={""};final double[] discountValue={0};
        List<Button> washButtons=new ArrayList<>();
        LinearLayout extrasPanel=new LinearLayout(this);extrasPanel.setOrientation(LinearLayout.VERTICAL);
        extrasPanel.addView(sectionTitle(t("الإضافات","Extras")));List<CheckBox> checks=addProductChecks(extrasPanel,db.getProducts(true),null);
        TextView total=text("",21,GRAY);total.setTypeface(Typeface.DEFAULT_BOLD);total.setGravity(Gravity.CENTER);total.setPadding(0,dp(4),0,dp(4));
        Runnable refresh=()->{total.setText(t("الإجمالي: ","Total: ")+money(calculateTotal(selected[0]==null?0:selected[0].price,checks,discountType[0],discountValue[0])));
            for(int i=0;i<washButtons.size();i++){boolean active=washes.get(i)==selected[0];Button btn=washButtons.get(i);btn.setTextColor(active?Color.WHITE:GRAY);btn.setBackground(round(active?RED:Color.WHITE,active?RED:Color.LTGRAY,10));}};
        for(DBHelper.WashType wt:washes){Button btn=menuButton((arabic?wt.nameAr:wt.nameEn)+"\n"+money(wt.price));btn.setTextSize(16);btn.setGravity(Gravity.CENTER);btn.setPadding(dp(4),0,dp(4),0);btn.setOnClickListener(v->{selected[0]=wt;refresh.run();});washButtons.add(btn);}
        addButtonGrid(washPanel,washButtons,76);box.addView(extrasPanel);
        washesTab.setOnClickListener(v->{washPanel.setVisibility(View.VISIBLE);washesTab.setTextColor(Color.WHITE);washesTab.setBackground(round(RED,RED,10));extrasTab.setTextColor(GRAY);extrasTab.setBackground(round(SMOKE,Color.LTGRAY,10));});
        extrasTab.setOnClickListener(v->{washPanel.setVisibility(View.GONE);extrasTab.setTextColor(Color.WHITE);extrasTab.setBackground(round(RED,RED,10));washesTab.setTextColor(GRAY);washesTab.setBackground(round(SMOKE,Color.LTGRAY,10));});
        for(CheckBox cb:checks)cb.setOnCheckedChangeListener((v,on)->refresh.run());
        if(currentUser.canDiscount){TextView status=text(t("بدون خصم","No discount"),14,GRAY);box.addView(status);status.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){refresh.run();}public void afterTextChanged(Editable e){}});
            Button discount=smallButton(t("تعديل الخصم","Edit discount"));discount.setOnClickListener(v->requestDiscount(discountType,discountValue,discountReason,status));box.addView(discount,new LinearLayout.LayoutParams(-1,dp(48)));}
        LinearLayout footer=new LinearLayout(this);footer.setOrientation(LinearLayout.VERTICAL);footer.setPadding(dp(10),0,dp(10),dp(6));footer.setBackground(round(Color.WHITE,Color.LTGRAY,0));footer.addView(total);
        LinearLayout actions=new LinearLayout(this);Button prepare=smallButton(t("إرسال للتحضير","Preparation")),pay=primaryButton(t("الدفع مباشرة","Pay now"));prepare.setTextSize(16);actions.addView(prepare,new LinearLayout.LayoutParams(0,dp(54),1));LinearLayout.LayoutParams payLp=new LinearLayout.LayoutParams(0,dp(54),1);payLp.setMargins(dp(6),0,dp(6),0);actions.addView(pay,payLp);footer.addView(actions);root.addView(footer);refresh.run();
        final boolean[] submitted={false};
        View.OnClickListener submit=v->{
            if(submitted[0])return;
            if(plate.getText().toString().trim().isEmpty()){toast(t("أدخل رقم اللوحة","Enter plate number"));return;}
            if(leaving.isChecked()&&phone.getText().toString().trim().isEmpty()){toast(t("أدخل رقم العميل","Enter customer phone"));return;}
            if(selected[0]==null){toast(t("اختر نوع الغسيل","Choose wash type"));return;}
            if(selectedWorker[0]==null){toast(t("أضف العمال من الإعدادات واختر العامل","Add workers in Settings and choose one"));return;}
            DBHelper.WashType wt=selected[0];DBHelper.Employee emp=selectedWorker[0];
            if(v==prepare){try{submitted[0]=true;db.createPendingSale(plate.getText().toString(),phone.getText().toString(),leaving.isChecked(),wt.nameAr,wt.price,emp.id,emp.name,selectedProducts(checks),discountType[0],discountValue[0],discountReason[0],currentUser.id,currentUser.name);LocalBackupManager.backup(this,db);showPendingOrders();}catch(Exception e){submitted[0]=false;toast(t("تعذر حفظ الفاتورة","Could not save invoice"));}return;}
            double amount=calculateTotal(wt.price,checks,discountType[0],discountValue[0]);
            new AlertDialog.Builder(this).setTitle(t("الدفع مباشرة: ","Pay now: ")+money(amount)).setItems(new String[]{t("نقدي","Cash"),t("شبكة","Card"),t("نقدي + شبكة","Cash + Card")},(dialog,which)->{
                if(which==2)requestSplitPayment(amount,(cash,card)->saveDirectOrder(plate,phone,leaving,wt,emp,checks,discountType,discountValue,discountReason,"Split",cash,card,submitted));
                else saveDirectOrder(plate,phone,leaving,wt,emp,checks,discountType,discountValue,discountReason,which==0?"Cash":"Card",-1,-1,submitted);
            }).setNegativeButton(t("إلغاء","Cancel"),null).show();
        };prepare.setOnClickListener(submit);pay.setOnClickListener(submit);
    }

    private void saveDirectOrder(EditText plate,EditText phone,RadioButton leaving,DBHelper.WashType wt,DBHelper.Employee emp,List<CheckBox> checks,String[] type,double[] value,String[] reason,String method,double cash,double card,boolean[] submitted){
        if(submitted[0])return;
        try{submitted[0]=true;long id=db.createCompletedSale(plate.getText().toString(),phone.getText().toString(),leaving.isChecked(),wt.nameAr,wt.price,emp.id,emp.name,selectedProducts(checks),type[0],value[0],reason[0],currentUser.id,currentUser.name,method,cash,card);LocalBackupManager.backup(this,db);showPaidDialog(db.getSale(id));}
        catch(Exception e){submitted[0]=false;toast(t("تعذر حفظ الدفع، راجع المبالغ","Could not save payment; check amounts"));}
    }

    private List<CheckBox> addProductChecks(LinearLayout box,List<DBHelper.Product> products,List<DBHelper.Product> selected) {
        List<CheckBox> checks=new ArrayList<>();
        for(DBHelper.Product p:products){
            boolean wasSelected=containsProduct(selected,p.id);
            if(!p.active&&!wasSelected)continue;
            CheckBox cb=new CheckBox(this);cb.setText((arabic?p.nameAr:p.nameEn)+"  •  "+money(p.price));cb.setTextSize(17);cb.setTag(p);cb.setChecked(wasSelected);cb.setPadding(dp(16),dp(12),dp(12),dp(12));LinearLayout.LayoutParams productParams=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(64));productParams.bottomMargin=dp(8);box.addView(cb,productParams);checks.add(cb);
        }
        if(checks.isEmpty())box.addView(text(t("لا توجد خدمات إضافية حالياً","No additional services yet"),14,Color.GRAY));
        return checks;
    }
    private boolean containsProduct(List<DBHelper.Product> list,long id){if(list==null)return false;for(DBHelper.Product p:list)if(p.id==id)return true;return false;}
    private List<DBHelper.Product> selectedProducts(List<CheckBox> checks){List<DBHelper.Product> out=new ArrayList<>();for(CheckBox cb:checks)if(cb.isChecked())out.add((DBHelper.Product)cb.getTag());return out;}

    private void showPendingOrders() {
        if(!require(currentUser!=null && currentUser.canNewSale))return;
        baseScreen(false);LinearLayout box=stack(contentScroll());box.addView(heading(t("فواتير قيد التحضير","Invoices In Preparation")));
        List<DBHelper.Sale> pending=db.getPendingSales();
        if(pending.isEmpty()){box.addView(text(t("لا توجد فواتير قيد التحضير","No invoices in preparation"),16,Color.GRAY));return;}
        for(DBHelper.Sale sale:pending){
            LinearLayout c=card();c.setOrientation(LinearLayout.VERTICAL);
            TextView first=text(sale.plate+"  •  "+sale.workerName,18,GRAY);first.setTypeface(Typeface.DEFAULT_BOLD);c.addView(first);
            c.addView(text(t("بدأت: ","Started: ")+formatDateTime(sale.createdAt)+"  •  "+t("المدة حتى الآن: ","Elapsed: ")+durationText(sale.durationMs()),14,Color.GRAY));
            c.addView(text(t("القيمة الحالية: ","Current total: ")+money(sale.total),14,Color.GRAY));
            Button open=primaryButton(t("فتح / إضافة خدمات / إنهاء","Open / Add Services / Finish"));open.setOnClickListener(v->showPendingOrder(sale.id));c.addView(open);box.addView(c);
        }
    }

    private void showPendingOrder(long id) {
        if(!require(currentUser!=null && currentUser.canNewSale))return;
        DBHelper.Sale sale=db.getSale(id);if(sale==null||!sale.isPending()){toast(t("هذه الفاتورة لم تعد قيد التحضير","This invoice is no longer pending"));showPendingOrders();return;}
        baseScreen(false);LinearLayout box=stack(contentScroll());box.addView(heading(t("إنهاء الفاتورة","Finish Invoice")));
        box.addView(summaryCard(sale.plate,t("بدأت: ","Started: ")+formatDateTime(sale.createdAt),t("المدة حتى الآن: ","Elapsed: ")+durationText(sale.durationMs())));
        box.addView(text(t("العامل: ","Worker: ")+sale.workerName+"  •  "+t("نوع الغسيل: ","Wash: ")+sale.carSize+"  •  "+money(sale.basePrice),15,GRAY));

        box.addView(sectionTitle(t("الخدمات الإضافية","Additional Services")));
        List<CheckBox> checks=addProductChecks(box,db.getProducts(false),sale.items);

        final String[] discountType={sale.discountType==null?"none":sale.discountType};
        final double[] discountValue={sale.discountValue};
        final String[] discountReason={sale.discountReason==null?"":sale.discountReason};
        TextView discountStatus=text(discountValue[0]>0?t("الخصم الحالي: ","Current discount: ")+("percent".equals(discountType[0])?String.format(Locale.US,"%.0f%%",discountValue[0]):money(discountValue[0])):t("بدون خصم","No discount"),15,Color.GRAY);
        if(currentUser.canDiscount){
            box.addView(sectionTitle(t("الخصم","Discount")));box.addView(discountStatus);
            Button discount=menuButton(t("إضافة / تعديل الخصم","Add / Edit Discount"));discount.setOnClickListener(v->requestDiscount(discountType,discountValue,discountReason,discountStatus));box.addView(discount);
            Button clear=smallButton(t("إلغاء الخصم","Clear Discount"));clear.setOnClickListener(v->requestReason(t("سبب إلغاء الخصم","Reason for clearing discount"),reason->{discountType[0]="none";discountValue[0]=0;discountReason[0]=reason;discountStatus.setText(t("بدون خصم","No discount"));}));box.addView(clear,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(48)));
        }

        TextView totalPreview=text("",19,GRAY);totalPreview.setTypeface(Typeface.DEFAULT_BOLD);totalPreview.setPadding(dp(4),dp(16),dp(4),dp(6));box.addView(totalPreview);
        Runnable updateTotal=()->totalPreview.setText(t("الإجمالي الحالي: ","Current total: ")+money(calculateTotal(sale.basePrice,checks,discountType[0],discountValue[0])));
        discountStatus.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){updateTotal.run();}public void afterTextChanged(Editable e){}});
        updateTotal.run();
        for(CheckBox cb:checks)cb.setOnCheckedChangeListener((b,c)->updateTotal.run());

        box.addView(sectionTitle(t("إنهاء الفاتورة وطريقة الدفع","Complete Invoice & Payment")));
        Button cash=primaryButton(t("تأكيد - نقدي","Confirm - Cash"));cash.setOnClickListener(v->finishPending(sale,checks,discountType,discountValue,discountReason,"Cash",-1,-1));box.addView(cash);
        Button card=primaryButton(t("تأكيد - شبكة","Confirm - Card"));card.setOnClickListener(v->finishPending(sale,checks,discountType,discountValue,discountReason,"Card",-1,-1));box.addView(card);
        Button split=primaryButton(t("تأكيد - كاش + شبكة","Confirm - Cash + Card"));split.setOnClickListener(v->{
            double total=calculateTotal(sale.basePrice,checks,discountType[0],discountValue[0]);
            requestSplitPayment(total,(c1,c2)->finishPending(sale,checks,discountType,discountValue,discountReason,"Split",c1,c2));
        });box.addView(split);
        if(currentUser.canRefund){Button cancel=menuButton(t("إلغاء فاتورة التحضير","Cancel pending invoice"));cancel.setTextColor(RED);cancel.setOnClickListener(v->requestReason(t("تأكيد إلغاء فاتورة التحضير","Confirm cancellation"),reason->{try{if(db.cancelPendingSale(sale.id,reason,currentUser.id)){LocalBackupManager.backup(this,db);showPendingOrders();}else toast(t("لم تعد الفاتورة معلقة","Invoice is no longer pending"));}catch(Exception e){toast(t("تعذر الإلغاء","Could not cancel"));}}));box.addView(cancel);}
    }

    private double calculateTotal(double base,List<CheckBox> checks,String type,double value){
        double subtotal=base;for(CheckBox cb:checks)if(cb.isChecked())subtotal+=((DBHelper.Product)cb.getTag()).price;
        double discount=0;if("percent".equals(type))discount=subtotal*Math.max(0,Math.min(100,value))/100.0;else if("fixed".equals(type))discount=Math.max(0,Math.min(subtotal,value));return Math.max(0,subtotal-discount);
    }

    private void finishPending(DBHelper.Sale sale,List<CheckBox> checks,String[] discountType,double[] discountValue,String[] discountReason,String method,double cash,double card){
        try{
            boolean ok=db.completePendingSale(sale.id,selectedProducts(checks),discountType[0],discountValue[0],discountReason[0],method,cash,card,currentUser.id,currentUser.name);
            if(!ok){toast(t("تعذر إنهاء الفاتورة أو تم إنهاؤها مسبقاً","Could not complete invoice or it was already completed"));showPendingOrders();return;}
            LocalBackupManager.backup(this,db);showPaidDialog(db.getSale(sale.id));
        }catch(Exception e){toast(t("تعذر حفظ العملية، تحقق من مبالغ الدفع","Could not save sale; check payment amounts"));}
    }

    private RadioButton findChecked(RadioGroup g){int id=g.getCheckedRadioButtonId();return id==-1?null:g.findViewById(id);}
    private interface SplitPaymentPicked{void onPicked(double cash,double card);}
    private void requestSplitPayment(double total,SplitPaymentPicked callback){
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(18),dp(8),dp(18),0);
        TextView tv=text(t("الإجمالي: ","Total: ")+money(total),19,GRAY);tv.setTypeface(Typeface.DEFAULT_BOLD);form.addView(tv);
        EditText cash=numberField("");cash.setHint(t("المبلغ كاش","Cash amount"));form.addView(cash);EditText card=numberField("");card.setHint(t("المبلغ شبكة","Card amount"));form.addView(card);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(t("تقسيم الدفع","Split Payment")).setView(form).setPositiveButton(t("حفظ","Save"),null).setNegativeButton(t("إلغاء","Cancel"),null).create();
        d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{double c=Double.parseDouble(cash.getText().toString().trim()),k=Double.parseDouble(card.getText().toString().trim());if(Double.isNaN(c)||Double.isInfinite(c)||Double.isNaN(k)||Double.isInfinite(k)||c<0||k<0||Math.abs(c+k-total)>0.01){toast(t("مجموع الكاش والشبكة يجب أن يساوي الإجمالي","Cash + card must equal the total"));return;}callback.onPicked(c,k);d.dismiss();}catch(Exception e){toast(t("أدخل مبلغ الكاش ومبلغ الشبكة","Enter cash and card amounts"));}}));d.show();
    }

    private void showPaidDialog(DBHelper.Sale sale){
        AlertDialog d=new AlertDialog.Builder(this).setTitle(t("تم تأكيد الفاتورة ✓","Invoice completed ✓"))
                .setMessage(t("رقم الفاتورة: ","Invoice #: ")+sale.invoiceNo+"\n"+t("من: ","From: ")+formatTime(sale.createdAt)+"  "+t("إلى: ","To: ")+formatTime(sale.completedAt)+"\n"+t("المدة: ","Duration: ")+durationText(sale.durationMs())+"\n"+t("الإجمالي: ","Total: ")+money(sale.total))
                .setPositiveButton(t("طباعة الفاتورة","Print Receipt"),null).setNegativeButton(t("الرئيسية بدون طباعة","Home - No Print"),(x,w)->showHome()).setNeutralButton(t("حفظ كصورة","Save as Image"),null).create();
        d.setOnShowListener(x->{d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{if(printer.printReceipt(sale))toast(t("تم إرسال الفاتورة للطابعة","Receipt sent to printer"));else toast(t("الطابعة غير متصلة حالياً","Printer is not connected"));});d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->saveInvoiceImage(sale,false));});d.show();
    }

    private void showReports() {
        if(!require(currentUser!=null && currentUser.canReports))return;
        baseScreen(false);reportScreen=true;
        reportClock.postDelayed(reportRefresh,Math.max(1000,DBHelper.startOfTomorrow()-System.currentTimeMillis()+100));
        LinearLayout box=stack(contentScroll());box.addView(heading(isManager()?t("التقارير","Reports"):t("تقارير اليوم فقط","Today's reports only")));
        if(!isManager())box.addView(text(t("يمكنك عرض وطباعة وحفظ ومشاركة تقرير اليوم الحالي فقط.","You can view, print, save and share the current day's report only."),15,GRAY));
        final long[] range={DBHelper.startOfToday(),DBHelper.startOfTomorrow()};final long[] custom={DBHelper.startOfToday(),DBHelper.startOfTomorrow()-60_000L};final Calendar monthCursor=Calendar.getInstance();monthCursor.setTimeInMillis(range[0]);
        TextView period=text("",16,GRAY);period.setTypeface(Typeface.DEFAULT_BOLD);period.setGravity(Gravity.CENTER);period.setPadding(dp(4),dp(8),dp(4),dp(8));box.addView(period);
        LinearLayout nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);Button prev=smallButton(t("‹ شهر","‹ Month")),today=smallButton(t("اليوم","Today")),current=smallButton(t("هذا الشهر","This Month")),next=smallButton(t("شهر ›","Month ›"));
        nav.addView(prev,new LinearLayout.LayoutParams(0,dp(52),1));nav.addView(today,new LinearLayout.LayoutParams(0,dp(52),1));nav.addView(current,new LinearLayout.LayoutParams(0,dp(52),1));nav.addView(next,new LinearLayout.LayoutParams(0,dp(52),1));if(isManager())box.addView(nav);
        if(isManager())box.addView(sectionTitle(t("بحث بالتاريخ والوقت","Search by Date & Time")));LinearLayout customRow=new LinearLayout(this);customRow.setOrientation(LinearLayout.HORIZONTAL);Button from=smallButton(""),to=smallButton("");customRow.addView(from,new LinearLayout.LayoutParams(0,dp(58),1));customRow.addView(to,new LinearLayout.LayoutParams(0,dp(58),1));if(isManager())box.addView(customRow);Button applyCustom=primaryButton(t("عرض الفترة المحددة","Show Selected Range"));if(isManager())box.addView(applyCustom);
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);box.addView(body);
        SimpleDateFormat dt=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US);final Runnable[] render=new Runnable[1];
        Runnable labels=()->{from.setText(t("من: ","From: ")+dt.format(new Date(custom[0])));to.setText(t("إلى: ","To: ")+dt.format(new Date(custom[1])));};labels.run();

        render[0]=()->{
            long[] allowed=db.reportRange(currentUser.id,range[0],range[1]);range[0]=allowed[0];range[1]=allowed[1];
            body.removeAllViews();period.setText(dt.format(new Date(range[0]))+"  →  "+dt.format(new Date(Math.max(range[0],range[1]-1))));
            DBHelper.DailySummary s=db.getSummary(range[0],range[1]);
            body.addView(sectionTitle(t("ملخص التقرير","Report Summary")));
            List<String[]> summaryRows=new ArrayList<>();summaryRows.add(new String[]{t("إجمالي المبيعات قبل المرتجع","Gross sales"),money(s.grossSales)});summaryRows.add(new String[]{t("عدد فواتير المرتجع","Refunded invoices"),String.valueOf(s.refundedCars)});summaryRows.add(new String[]{t("قيمة المرتجعات","Refund amount"),money(s.refunds)});summaryRows.add(new String[]{t("صافي المبيعات بعد المرتجع","Net sales"),money(s.sales)});summaryRows.add(new String[]{t("عدد السيارات المغسولة","Cars washed"),String.valueOf(s.totalCars)});body.addView(reportTable(new String[]{t("البند","Item"),t("القيمة","Value")},summaryRows,dp(440)));

            body.addView(sectionTitle(t("تفصيل الكاش والشبكة","Cash & Card Breakdown")));
            List<String[]> payRows=new ArrayList<>();payRows.add(new String[]{t("الكاش قبل المرتجع","Cash gross"),money(s.cashGross)});payRows.add(new String[]{t("مرتجع الكاش","Cash refunds"),money(s.cashRefunds)});payRows.add(new String[]{t("صافي الكاش","Net cash"),money(s.cashNet)});payRows.add(new String[]{t("الشبكة قبل المرتجع","Card gross"),money(s.cardGross)});payRows.add(new String[]{t("مرتجع الشبكة","Card refunds"),money(s.cardRefunds)});payRows.add(new String[]{t("صافي الشبكة","Net card"),money(s.cardNet)});payRows.add(new String[]{t("صافي الكاش + الشبكة","Cash + Card net"),money(s.paymentNet)});body.addView(reportTable(new String[]{t("طريقة الدفع","Payment"),t("القيمة","Value")},payRows,dp(450)));

            body.addView(sectionTitle(t("الأكثر طلباً","Most Requested")));String addon=arabic?s.topAddOnAr:s.topAddOnEn;List<String[]> popular=new ArrayList<>();popular.add(new String[]{t("أكثر إضافة/خدمة","Top add-on/service"),addon==null||addon.isEmpty()?"-":addon+" × "+s.topAddOnCount});popular.add(new String[]{t("أكثر نوع غسيل","Top wash type"),s.topCarSize==null||s.topCarSize.isEmpty()?"-":s.topCarSize+" × "+s.topCarSizeCount});body.addView(reportTable(new String[]{t("البند","Item"),t("النتيجة","Result")},popular,dp(460)));

            body.addView(sectionTitle(t("أداء العمال","Worker Performance")));List<String[]> workers=new ArrayList<>();int rank=1;for(DBHelper.WorkerCount w:s.workerCounts)workers.add(new String[]{String.valueOf(rank++),w.name,String.valueOf(w.count),String.valueOf(w.refundCount)});body.addView(reportTable(new String[]{"#",t("العامل","Worker"),t("الغسلات","Washes"),t("مرتجع","Refunds")},workers,dp(560)));

            body.addView(sectionTitle(t("تفاصيل الأيام","Daily Breakdown")));List<String[]> days=new ArrayList<>();SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd",Locale.US);for(DBHelper.DaySummary d:db.getDailyBreakdown(range[0],range[1])){DBHelper.DailySummary x=d.summary;days.add(new String[]{df.format(new Date(d.dayStart)),String.valueOf(x.cars),money(x.grossSales),money(x.refunds),money(x.sales)});}body.addView(reportTable(new String[]{t("التاريخ","Date"),t("السيارات","Cars"),t("الإجمالي","Gross"),t("المرتجع","Refunds"),t("الصافي","Net")},days,dp(760)));

            body.addView(sectionTitle(t("طباعة وحفظ التقرير","Print & Save Report")));
            Button print=primaryButton(t("طباعة التقرير A4","Print A4 Report"));print.setOnClickListener(v->{try{File f=DocumentExporter.createReportPdf(this,db,currentUser.id,range[0],range[1],t("تقرير مغسلة نوره","NOURA Car Wash Report"),arabic);DocumentExporter.printPdf(this,f,"Noura Report");}catch(Exception e){toast(t("تعذر إنشاء التقرير","Could not create report"));}});body.addView(print);
            Button save=menuButton(t("حفظ التقرير PDF على الجهاز","Save Report as PDF"));save.setOnClickListener(v->{try{File f=DocumentExporter.createReportPdf(this,db,currentUser.id,range[0],range[1],t("تقرير مغسلة نوره","NOURA Car Wash Report"),arabic);String n=DocumentExporter.saveReportPdfToDevice(this,f);toast(t("تم حفظ التقرير: ","Saved report: ")+n);}catch(Exception e){toast(t("تعذر حفظ التقرير","Could not save report"));}});body.addView(save);
            Button share=menuButton(t("مشاركة التقرير / إيميل","Share Report / Email"));share.setOnClickListener(v->{try{File f=DocumentExporter.createReportPdf(this,db,currentUser.id,range[0],range[1],t("تقرير مغسلة نوره","NOURA Car Wash Report"),arabic);DocumentExporter.shareFile(this,f,"application/pdf",t("مشاركة التقرير","Share Report"));}catch(Exception e){toast(t("تعذر مشاركة التقرير","Could not share report"));}});body.addView(share);
        };
        prev.setOnClickListener(v->{monthCursor.add(Calendar.MONTH,-1);range[0]=DBHelper.startOfMonth(monthCursor.getTimeInMillis());range[1]=DBHelper.startOfNextMonth(monthCursor.getTimeInMillis());render[0].run();});
        next.setOnClickListener(v->{monthCursor.add(Calendar.MONTH,1);range[0]=DBHelper.startOfMonth(monthCursor.getTimeInMillis());range[1]=DBHelper.startOfNextMonth(monthCursor.getTimeInMillis());render[0].run();});
        today.setOnClickListener(v->{range[0]=DBHelper.startOfToday();range[1]=DBHelper.startOfTomorrow();render[0].run();});
        current.setOnClickListener(v->{monthCursor.setTimeInMillis(System.currentTimeMillis());range[0]=DBHelper.startOfMonth();range[1]=DBHelper.startOfNextMonth();render[0].run();});
        from.setOnClickListener(v->pickDateTime(custom[0],value->{custom[0]=value;labels.run();}));to.setOnClickListener(v->pickDateTime(custom[1],value->{custom[1]=value;labels.run();}));
        applyCustom.setOnClickListener(v->{if(custom[1]<=custom[0]){toast(t("وقت النهاية يجب أن يكون بعد البداية","End time must be after start time"));return;}range[0]=custom[0];range[1]=custom[1]+60_000L;render[0].run();});
        render[0].run();
    }

    private View reportTable(String[] headers,List<String[]> rows,int minWidth){
        HorizontalScrollView scroll=new HorizontalScrollView(this);TableLayout table=new TableLayout(this);table.setMinimumWidth(minWidth);int cellWidth=Math.max(dp(88),minWidth/Math.max(1,headers.length));table.addView(reportTableRow(headers,true,cellWidth));
        if(rows==null||rows.isEmpty()){String[] empty=new String[headers.length];for(int i=0;i<empty.length;i++)empty[i]=i==0?t("لا توجد بيانات","No data"):"-";table.addView(reportTableRow(empty,false,cellWidth));}else for(String[] row:rows)table.addView(reportTableRow(row,false,cellWidth));
        scroll.addView(table,new HorizontalScrollView.LayoutParams(minWidth,ViewGroup.LayoutParams.WRAP_CONTENT));return scroll;
    }
    private TableRow reportTableRow(String[] values,boolean header,int cellWidth){TableRow row=new TableRow(this);for(String value:values){TextView cell=text(value==null?"":value,header?14:13,GRAY);cell.setGravity(Gravity.CENTER);cell.setPadding(dp(8),dp(10),dp(8),dp(10));if(header)cell.setTypeface(Typeface.DEFAULT_BOLD);cell.setBackground(round(header?SMOKE:Color.WHITE,Color.LTGRAY,0));row.addView(cell,new TableRow.LayoutParams(cellWidth,ViewGroup.LayoutParams.WRAP_CONTENT));}return row;}

    private void showInvoices(){
        if(!require(currentUser!=null && currentUser.canViewInvoices))return;
        baseScreen(false);LinearLayout box=stack(contentScroll());box.addView(heading(t("فواتير اليوم","Today's Invoices")));
        List<DBHelper.Sale> sales=db.getSalesInRange(DBHelper.startOfToday(),DBHelper.startOfTomorrow(),0);if(sales.isEmpty()){box.addView(text(t("لا توجد فواتير اليوم","No invoices today"),16,Color.GRAY));return;}
        for(DBHelper.Sale sale:sales){LinearLayout c=card();c.setOrientation(LinearLayout.VERTICAL);String state=sale.refunded?"  •  "+t("مرتجع","REFUNDED"):"";TextView first=text(t("فاتورة #","Invoice #")+sale.invoiceNo+"  •  "+sale.plate+"  •  "+money(sale.total)+state,17,sale.refunded?RED:GRAY);first.setTypeface(Typeface.DEFAULT_BOLD);c.addView(first);c.addView(text(formatTime(sale.completedAt)+"  •  "+sale.workerName+"  •  "+durationText(sale.durationMs()),14,Color.GRAY));Button details=smallButton(t("التفاصيل","Details"));details.setOnClickListener(v->showSaleDetails(sale.id));c.addView(details);box.addView(c);}
    }

    private void showSearch(){
        if(!require(currentUser!=null && currentUser.canSearch))return;
        baseScreen(false);LinearLayout box=stack(contentScroll());box.addView(heading(t("البحث عن فاتورة","Find an Invoice")));
        EditText q=field(t("رقم الفاتورة أو اللوحة أو رقم العميل (اختياري)","Invoice #, plate or phone (optional)"),false);box.addView(q);
        if(isManager())box.addView(sectionTitle(t("البحث بالتاريخ (اختياري)","Search by date (optional)")));else box.addView(text(t("البحث في فواتير اليوم فقط","Search today’s invoices only"),15,GRAY));
        final long[] range={DBHelper.startOfToday(),DBHelper.startOfTomorrow()};final boolean[] byDate={!isManager()};
        Button date=menuButton(t("اختيار تاريخ الفواتير","Choose invoice date"));if(isManager())box.addView(date);
        Button clear=smallButton(t("إلغاء تحديد التاريخ","Clear date filter"));if(isManager())box.addView(clear);
        date.setOnClickListener(v->{Calendar c=Calendar.getInstance();c.setTimeInMillis(range[0]);new DatePickerDialog(this,(picker,y,m,d)->{Calendar day=Calendar.getInstance();day.set(y,m,d,0,0,0);day.set(Calendar.MILLISECOND,0);range[0]=day.getTimeInMillis();day.add(Calendar.DAY_OF_MONTH,1);range[1]=day.getTimeInMillis();byDate[0]=true;date.setText(t("التاريخ المحدد: ","Selected date: ")+new java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US).format(new java.util.Date(range[0])));},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();});
        clear.setOnClickListener(v->{byDate[0]=false;date.setText(t("اختيار تاريخ الفواتير","Choose invoice date"));});
        Button go=primaryButton(t("بحث","Search"));box.addView(go);LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);box.addView(results);
        go.setOnClickListener(v->{results.removeAllViews();if(!isManager()){range[0]=DBHelper.startOfToday();range[1]=DBHelper.startOfTomorrow();byDate[0]=true;}String query=q.getText().toString().trim();if(query.isEmpty()&&!byDate[0]){toast(t("أدخل بيانات البحث أو اختر تاريخاً","Enter search text or select a date"));return;}
            List<DBHelper.Sale> sales=byDate[0]?db.getSalesInRange(range[0],range[1],0):db.searchSales(query,100);
            int shown=0;for(DBHelper.Sale sale:sales){if(!query.isEmpty()&&byDate[0]&&!(String.valueOf(sale.invoiceNo).contains(query)||(sale.plate!=null&&sale.plate.contains(query))||(sale.phone!=null&&sale.phone.contains(query))))continue;
                LinearLayout c=card();c.setOrientation(LinearLayout.VERTICAL);String state=sale.refunded?" • "+t("مرتجع","REFUNDED"):"";TextView first=text("#"+sale.invoiceNo+" • "+sale.plate+" • "+money(sale.total)+state,17,sale.refunded?RED:GRAY);first.setTypeface(Typeface.DEFAULT_BOLD);c.addView(first);c.addView(text(formatDateTime(sale.completedAt)+" • "+sale.workerName,14,Color.GRAY));Button detail=smallButton(t("التفاصيل","Details"));detail.setOnClickListener(x->showSaleDetails(sale.id));c.addView(detail);results.addView(c);shown++;}
            if(shown==0)results.addView(text(t("لا توجد نتائج","No results"),16,Color.GRAY));});
    }

    private void showSaleDetails(long id){
        DBHelper.Sale s=db.getSale(id);if(s==null||!require(currentUser!=null&&(currentUser.canViewInvoices||currentUser.canSearch)&&db.canAccessInvoice(currentUser.id,s)))return;StringBuilder b=new StringBuilder();if(s.refunded)b.append(t("الحالة: مرتجع","Status: REFUNDED")).append("\n\n");
        b.append(t("اللوحة: ","Plate: ")).append(s.plate).append("\n");b.append(t("العامل: ","Worker: ")).append(s.workerName).append("\n");b.append(t("نوع الغسيل: ","Wash type: ")).append(s.carSize).append("\n");
        b.append(t("وقت البداية: ","Start time: ")).append(formatDateTime(s.createdAt)).append("\n");b.append(t("وقت النهاية: ","End time: ")).append(formatDateTime(s.completedAt)).append("\n");b.append(t("مدة الخدمة: ","Service duration: ")).append(durationText(s.durationMs())).append("\n");
        if(s.createdByUserName!=null&&!s.createdByUserName.isEmpty())b.append(t("فتحها المستخدم: ","Started by: ")).append(s.createdByUserName).append("\n");if(s.completedByUserName!=null&&!s.completedByUserName.isEmpty())b.append(t("أنهاها المستخدم: ","Completed by: ")).append(s.completedByUserName).append("\n");
        for(DBHelper.Product x:s.items)b.append("• ").append(arabic?x.nameAr:x.nameEn).append(" - ").append(money(x.price)).append("\n");
        b.append(t("المجموع قبل الخصم: ","Subtotal: ")).append(money(s.subtotal)).append("\n");if(s.discountAmount>0){String dsc="percent".equals(s.discountType)?String.format(Locale.US,"%.0f%%",s.discountValue):money(s.discountValue);b.append(t("الخصم: ","Discount: ")).append(dsc).append(" (-").append(money(s.discountAmount)).append(")\n");if(s.discountReason!=null&&!s.discountReason.trim().isEmpty())b.append(t("سبب الخصم: ","Discount reason: ")).append(s.discountReason).append("\n");}
        b.append(t("طريقة الدفع: ","Payment: ")).append(paymentLabel(s.paymentMethod)).append("\n");b.append(t("كاش: ","Cash: ")).append(money(s.cashAmount)).append("\n");b.append(t("شبكة: ","Card: ")).append(money(s.cardAmount)).append("\n");b.append(t("الإجمالي: ","Total: ")).append(money(s.total));
        if(s.refunded){b.append("\n\n").append(t("وقت المرتجع: ","Refunded at: ")).append(formatDateTime(s.refundedAt));if(s.refundReason!=null&&!s.refundReason.isEmpty())b.append("\n").append(t("سبب المرتجع: ","Refund reason: ")).append(s.refundReason);}
        AlertDialog d=new AlertDialog.Builder(this).setTitle(t("تفاصيل الفاتورة #","Invoice #")+s.invoiceNo).setMessage(b.toString()).setPositiveButton(t("طباعة","Print"),null).setNeutralButton(t("خيارات","Options"),null).setNegativeButton(t("إغلاق","Close"),null).create();
        d.setOnShowListener(x->{d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{if(!require(db.canAccessInvoice(currentUser.id,s)))return;if(!printer.printReceipt(s))toast(t("الطابعة غير متصلة","Printer not connected"));});d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->showInvoiceActions(s));});d.show();
    }

    private void showInvoiceActions(DBHelper.Sale sale){
        List<String> labels=new ArrayList<>();labels.add(t("حفظ الفاتورة كصورة","Save Invoice as Image"));labels.add(t("مشاركة صورة الفاتورة","Share Invoice Image"));if(!sale.refunded&&currentUser!=null&&currentUser.canRefund)labels.add(t("تسجيل الفاتورة كمرتجع","Mark Invoice as Refunded"));
        new AlertDialog.Builder(this).setTitle(t("خيارات الفاتورة","Invoice Options")).setItems(labels.toArray(new String[0]),(d,which)->{if(which==0)saveInvoiceImage(sale,false);else if(which==1)saveInvoiceImage(sale,true);else if(!sale.refunded&&currentUser!=null&&currentUser.canRefund)requestRefund(sale);}).setNegativeButton(t("إلغاء","Cancel"),null).show();
    }
    private void saveInvoiceImage(DBHelper.Sale sale,boolean share){if(!require(currentUser!=null&&db.canAccessInvoice(currentUser.id,sale)))return;try{if(share){File f=DocumentExporter.saveReceiptImage(this,sale);DocumentExporter.shareFile(this,f,"image/png",t("مشاركة الفاتورة","Share Invoice"));}else{String name=DocumentExporter.saveReceiptImageToDevice(this,sale);toast(t("تم حفظ الفاتورة: ","Saved invoice: ")+name);}}catch(Exception e){toast(t("تعذر حفظ صورة الفاتورة","Could not save invoice image"));}}
    private void requestRefund(DBHelper.Sale sale){
        if(!require(currentUser!=null && currentUser.canRefund))return;
        requestReason(t("تأكيد مرتجع الفاتورة #","Refund invoice #")+sale.invoiceNo,reason->{
            try{
                if(db.refundSale(sale.id,reason,currentUser.id)){LocalBackupManager.backup(this,db);toast(t("تم تسجيل المرتجع","Refund recorded"));showSaleDetails(sale.id);}
                else toast(t("تعذر المرتجع أو سبق تسجيله","Refund unavailable or already recorded"));
            }catch(Exception error){toast(t("تعذر حفظ المرتجع","Could not save refund"));}
        });
    }

    private interface ReasonAction{void run(String reason);}
    private void requestReason(String title,ReasonAction action){
        EditText reason=field(t("السبب (مطلوب)","Reason (required)"),false);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(title).setView(reason).setPositiveButton(t("تأكيد","Confirm"),null).setNegativeButton(t("رجوع","Back"),null).create();
        dialog.setOnShowListener(x->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String value=reason.getText().toString().trim();if(value.isEmpty()){reason.setError(t("اكتب السبب","Enter a reason"));return;}action.run(value);dialog.dismiss();}));dialog.show();
    }

    private interface TimePicked{void onPicked(long value);}
    private void pickDateTime(long initial,TimePicked callback){Calendar c=Calendar.getInstance();c.setTimeInMillis(initial);new DatePickerDialog(this,(view,year,month,day)->{Calendar picked=Calendar.getInstance();picked.set(year,month,day,c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),0);picked.set(Calendar.MILLISECOND,0);new TimePickerDialog(this,(tv,hour,minute)->{picked.set(Calendar.HOUR_OF_DAY,hour);picked.set(Calendar.MINUTE,minute);callback.onPicked(picked.getTimeInMillis());},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show();},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}

    private void requestDiscount(final String[] type,final double[] value,final String[] reason,final TextView status){if(!require(currentUser!=null && currentUser.canDiscount))return;showDiscountEditor(type,value,reason,status);}
    private void showDiscountEditor(final String[] type,final double[] value,final String[] reason,final TextView status){
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(18),dp(8),dp(18),0);RadioGroup group=new RadioGroup(this);RadioButton percent=radio(t("نسبة مئوية %","Percentage %"));percent.setTag("percent");RadioButton fixed=radio(t("مبلغ ثابت (ريال)","Fixed amount (SAR)"));fixed.setTag("fixed");group.addView(percent);group.addView(fixed);if("fixed".equals(type[0]))fixed.setChecked(true);else percent.setChecked(true);form.addView(group);
        EditText amount=numberField(value[0]>0?String.valueOf(value[0]):"");amount.setHint(t("قيمة الخصم","Discount value"));form.addView(amount);EditText why=field(t("سبب الخصم *","Discount reason *"),false);why.setText(reason[0]);form.addView(why);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(t("الخصم","Discount")).setView(form).setPositiveButton(t("حفظ","Save"),null).setNegativeButton(t("إلغاء","Cancel"),null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{double av=Double.parseDouble(amount.getText().toString());RadioButton selected=findChecked(group);String st=selected==null?"percent":(String)selected.getTag();String rs=why.getText().toString().trim();if(Double.isNaN(av)||Double.isInfinite(av)||av<=0||("percent".equals(st)&&av>100)){toast(t("تأكد من قيمة الخصم","Check the discount value"));return;}if(rs.isEmpty()){toast(t("اكتب سبب الخصم","Enter a discount reason"));return;}type[0]=st;value[0]=av;reason[0]=rs;status.setText(t("خصم ","Discount ")+("percent".equals(st)?String.format(Locale.US,"%.0f%%",av):money(av))+" • "+rs);d.dismiss();}catch(Exception e){toast(t("تأكد من قيمة الخصم","Check the discount value"));}}));d.show();
    }

    private void showAdmin(){
        if(!require(isManager()))return;
        baseScreen(false);LinearLayout box=stack(contentScroll());box.addView(heading(t("الإدارة","Admin")));
        Button audit=menuButton(t("سجل العمليات","Activity log"));audit.setOnClickListener(v->showAuditLog());box.addView(audit);
        Button backups=menuButton(t("النسخ الاحتياطي والاسترجاع","Backup & Restore"));backups.setOnClickListener(v->showBackupScreen());box.addView(backups);

        box.addView(sectionTitle(t("حسابات الدخول والصلاحيات","Login Accounts & Permissions")));
        box.addView(text(t("حساب المدير يملك جميع الصلاحيات. يمكنك إضافة عدد غير محدود من حسابات الموظفين وتحديد صلاحية كل حساب.","The manager has all permissions. Add unlimited employee accounts and choose each account's permissions."),14,Color.GRAY));
        Button addAccount=primaryButton(t("إضافة حساب موظف","Add Employee Account"));addAccount.setOnClickListener(v->showAddUserDialog());box.addView(addAccount);
        LinearLayout users=new LinearLayout(this);users.setOrientation(LinearLayout.VERTICAL);box.addView(users);renderAppUsers(users);

        box.addView(sectionTitle(t("أسعار الغسيل","Wash Prices")));
        EditText washAr=field("اسم نوع الغسيل بالعربي",false),washEn=field("Wash type name in English",false),washPrice=numberField("");washPrice.setHint(t("السعر","Price"));box.addView(washAr);box.addView(washEn);box.addView(washPrice);Button addWash=primaryButton(t("إضافة نوع غسيل","Add Wash Type"));box.addView(addWash);LinearLayout washList=new LinearLayout(this);washList.setOrientation(LinearLayout.VERTICAL);box.addView(washList);Runnable rw=()->renderWashTypes(washList);addWash.setOnClickListener(v->{try{String a=washAr.getText().toString().trim(),e=washEn.getText().toString().trim();if(a.isEmpty()){toast(t("اكتب اسم نوع الغسيل","Enter wash type name"));return;}if(e.isEmpty())e=a;db.addWashType(a,e,Double.parseDouble(washPrice.getText().toString()));washAr.setText("");washEn.setText("");washPrice.setText("");LocalBackupManager.backup(this,db);rw.run();}catch(Exception ex){toast(t("تأكد من الاسم والسعر","Check name and price"));}});rw.run();

        box.addView(sectionTitle(t("عمال الغسيل","Wash Workers")));EditText workerName=field(t("اسم العامل","Worker name"),false);box.addView(workerName);Button addWorker=primaryButton(t("إضافة عامل","Add Worker"));box.addView(addWorker);LinearLayout workers=new LinearLayout(this);workers.setOrientation(LinearLayout.VERTICAL);box.addView(workers);Runnable rworkers=()->renderWorkers(workers);addWorker.setOnClickListener(v->{if(workerName.getText().toString().trim().isEmpty())return;db.addEmployee(workerName.getText().toString());workerName.setText("");LocalBackupManager.backup(this,db);rworkers.run();});rworkers.run();

        box.addView(sectionTitle(t("المنتجات والخدمات الإضافية","Products & Additional Services")));EditText ar=field("الاسم بالعربي",false),en=field("English name",false),price=numberField("");price.setHint(t("السعر","Price"));box.addView(ar);box.addView(en);box.addView(price);Button addProduct=primaryButton(t("إضافة خدمة","Add Service"));box.addView(addProduct);LinearLayout products=new LinearLayout(this);products.setOrientation(LinearLayout.VERTICAL);box.addView(products);Runnable rp=()->renderProducts(products);addProduct.setOnClickListener(v->{try{if(ar.getText().toString().trim().isEmpty()||en.getText().toString().trim().isEmpty()){toast(t("اكتب اسم الخدمة بالعربي والإنجليزي","Enter Arabic and English names"));return;}db.addProduct(ar.getText().toString(),en.getText().toString(),Double.parseDouble(price.getText().toString()));ar.setText("");en.setText("");price.setText("");LocalBackupManager.backup(this,db);rp.run();}catch(Exception e){toast(t("تأكد من السعر","Check the price"));}});rp.run();

        box.addView(sectionTitle(t("الأمان والنسخ الاحتياطي","Security & Backup")));Button pin=menuButton(t("تغيير PIN المدير","Change Manager PIN"));pin.setOnClickListener(v->changePin());box.addView(pin);TextView backup=text(t("✓ يتم إنشاء نسخة احتياطية محلية تلقائياً بعد كل عملية أو تعديل.","✓ A local backup is created automatically after each sale or edit."),14,Color.GRAY);backup.setPadding(dp(8),dp(10),dp(8),dp(12));box.addView(backup);
    }

    private void showAddUserDialog(){
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(18),dp(8),dp(18),0);EditText name=field(t("اسم الموظف","Employee name"),false),pin=pinField(t("PIN من 4 أرقام","4-digit PIN"));form.addView(name);form.addView(pin);
        CheckBox sale=permissionCheck(t("إنشاء وإنهاء الفواتير + قيد التحضير","Create/complete invoices + preparation"),true),inv=permissionCheck(t("عرض فواتير اليوم","View today's invoices"),true),reports=permissionCheck(t("تقارير اليوم فقط","Today’s reports only"),true),search=permissionCheck(t("البحث عن الفواتير","Search invoices"),true),refund=permissionCheck(t("المرتجع وإلغاء التحضير","Refunds & pending cancellation"),false),discount=permissionCheck(t("إضافة الخصومات","Apply discounts"),false);
        form.addView(sale);form.addView(inv);form.addView(reports);form.addView(search);form.addView(refund);form.addView(discount);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(t("حساب موظف جديد","New Employee Account")).setView(form).setPositiveButton(t("إضافة","Add"),null).setNegativeButton(t("إلغاء","Cancel"),null).create();
        d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String n=name.getText().toString().trim(),p=pin.getText().toString().trim();if(n.isEmpty()){toast(t("اكتب اسم الموظف","Enter employee name"));return;}if(!p.matches("\\d{4}")){toast(t("PIN يجب أن يكون 4 أرقام","PIN must be 4 digits"));return;}try{db.addAppUser(n,p,sale.isChecked(),inv.isChecked(),reports.isChecked(),search.isChecked(),refund.isChecked(),discount.isChecked());LocalBackupManager.backup(this,db);d.dismiss();showAdmin();}catch(Exception e){toast(t("تعذر إضافة الحساب. تأكد أن PIN غير مستخدم.","Could not add account. Make sure the PIN is unique."));}}));d.show();
    }
    private CheckBox permissionCheck(String label,boolean checked){CheckBox c=new CheckBox(this);c.setText(label);c.setChecked(checked);c.setTextSize(15);return c;}

    private void renderAppUsers(LinearLayout list){
        list.removeAllViews();for(DBHelper.AppUser u:db.getAppUsers()){LinearLayout row=card();row.setGravity(Gravity.CENTER_VERTICAL);String label=u.name+" • "+(u.isManager()?t("مدير","Manager"):t("موظف","Employee"));TextView n=text(label,16,GRAY);row.addView(n,new LinearLayout.LayoutParams(0,dp(54),1));if(u.isManager()){TextView all=text(t("كل الصلاحيات","All"),13,RED);row.addView(all);}else{Button edit=smallButton(t("الصلاحيات","Permissions"));edit.setOnClickListener(v->editAppUser(u));row.addView(edit);Switch sw=new Switch(this);sw.setChecked(u.active);sw.setOnCheckedChangeListener((b,c)->{db.setAppUserActive(u.id,c);LocalBackupManager.backup(this,db);});row.addView(sw);}list.addView(row);}
    }
    private void editAppUser(DBHelper.AppUser u){
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(18),dp(8),dp(18),0);EditText name=field(t("اسم الموظف","Employee name"),false);name.setText(u.name);EditText pin=pinField(t("PIN جديد (اتركه فارغاً بدون تغيير)","New PIN (leave blank to keep current)"));form.addView(name);form.addView(pin);
        CheckBox sale=permissionCheck(t("إنشاء وإنهاء الفواتير + قيد التحضير","Create/complete invoices + preparation"),u.canNewSale),inv=permissionCheck(t("عرض فواتير اليوم","View today's invoices"),u.canViewInvoices),reports=permissionCheck(t("تقارير اليوم فقط","Today’s reports only"),u.canReports),search=permissionCheck(t("البحث عن الفواتير","Search invoices"),u.canSearch),refund=permissionCheck(t("المرتجع وإلغاء التحضير","Refunds & pending cancellation"),u.canRefund),discount=permissionCheck(t("إضافة الخصومات","Apply discounts"),u.canDiscount);form.addView(sale);form.addView(inv);form.addView(reports);form.addView(search);form.addView(refund);form.addView(discount);
        AlertDialog d=new AlertDialog.Builder(this).setTitle(t("تعديل حساب الموظف","Edit Employee Account")).setView(form).setPositiveButton(t("حفظ","Save"),null).setNegativeButton(t("إلغاء","Cancel"),null).create();
        d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String n=name.getText().toString().trim(),p=pin.getText().toString().trim();if(n.isEmpty()){toast(t("اكتب الاسم","Enter name"));return;}if(!p.isEmpty()&&!p.matches("\\d{4}")){toast(t("PIN يجب أن يكون 4 أرقام","PIN must be 4 digits"));return;}try{db.updateAppUser(u.id,n,sale.isChecked(),inv.isChecked(),reports.isChecked(),search.isChecked(),refund.isChecked(),discount.isChecked());if(!p.isEmpty())db.updateUserPin(u.id,p);LocalBackupManager.backup(this,db);d.dismiss();showAdmin();}catch(Exception e){toast(t("تعذر الحفظ. قد يكون PIN مستخدماً.","Could not save. PIN may already be in use."));}}));d.show();
    }

    private void renderWorkers(LinearLayout list){list.removeAllViews();for(DBHelper.Employee e:db.getEmployees(false)){LinearLayout row=card();row.setGravity(Gravity.CENTER_VERTICAL);TextView name=text(e.name,17,GRAY);row.addView(name,new LinearLayout.LayoutParams(0,dp(52),1));Button edit=smallButton(t("تعديل","Edit"));edit.setOnClickListener(v->editEmployee(e));row.addView(edit);Switch sw=new Switch(this);sw.setChecked(e.active);sw.setOnCheckedChangeListener((b,c)->{db.setEmployeeActive(e.id,c);LocalBackupManager.backup(this,db);});row.addView(sw);list.addView(row);}}
    private void editEmployee(DBHelper.Employee e){EditText f=new EditText(this);f.setText(e.name);new AlertDialog.Builder(this).setTitle(t("تعديل العامل","Edit Worker")).setView(f).setPositiveButton(t("حفظ","Save"),(d,w)->{if(!f.getText().toString().trim().isEmpty()){db.updateEmployee(e.id,f.getText().toString());LocalBackupManager.backup(this,db);showAdmin();}}).setNegativeButton(t("إلغاء","Cancel"),null).show();}
    private void renderWashTypes(LinearLayout list){list.removeAllViews();for(DBHelper.WashType wt:db.getWashTypes(false)){LinearLayout row=card();row.setGravity(Gravity.CENTER_VERTICAL);String name=arabic?wt.nameAr:wt.nameEn;if(name==null||name.trim().isEmpty())name=arabic?wt.nameEn:wt.nameAr;TextView n=text(name+" • "+money(wt.price),16,GRAY);row.addView(n,new LinearLayout.LayoutParams(0,dp(56),1));Button edit=smallButton(t("تعديل","Edit"));edit.setOnClickListener(v->editWashType(wt));row.addView(edit);Switch sw=new Switch(this);sw.setChecked(wt.active);sw.setOnCheckedChangeListener((b,c)->{db.setWashTypeActive(wt.id,c);LocalBackupManager.backup(this,db);});row.addView(sw);list.addView(row);}}
    private void editWashType(DBHelper.WashType wt){LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(18),dp(8),dp(18),0);EditText ar=field("اسم نوع الغسيل بالعربي",false);ar.setText(wt.nameAr);EditText en=field("Wash type name in English",false);en.setText(wt.nameEn);EditText price=numberField(String.valueOf(wt.price));form.addView(ar);form.addView(en);form.addView(price);new AlertDialog.Builder(this).setTitle(t("تعديل نوع الغسيل","Edit Wash Type")).setView(form).setPositiveButton(t("حفظ","Save"),(d,w)->{try{String a=ar.getText().toString().trim(),e=en.getText().toString().trim();if(a.isEmpty())return;if(e.isEmpty())e=a;db.updateWashType(wt.id,a,e,Double.parseDouble(price.getText().toString()));LocalBackupManager.backup(this,db);showAdmin();}catch(Exception ex){toast(t("تأكد من البيانات","Check details"));}}).setNegativeButton(t("إلغاء","Cancel"),null).show();}
    private void renderProducts(LinearLayout list){list.removeAllViews();for(DBHelper.Product p:db.getProducts(false)){LinearLayout row=card();row.setGravity(Gravity.CENTER_VERTICAL);TextView n=text((arabic?p.nameAr:p.nameEn)+" • "+money(p.price),16,GRAY);row.addView(n,new LinearLayout.LayoutParams(0,dp(56),1));Button edit=smallButton(t("تعديل","Edit"));edit.setOnClickListener(v->editProduct(p));row.addView(edit);Switch sw=new Switch(this);sw.setChecked(p.active);sw.setOnCheckedChangeListener((b,c)->{db.setProductActive(p.id,c);LocalBackupManager.backup(this,db);});row.addView(sw);list.addView(row);}}
    private void editProduct(DBHelper.Product p){LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(18),dp(8),dp(18),0);EditText ar=field("الاسم بالعربي",false);ar.setText(p.nameAr);EditText en=field("English name",false);en.setText(p.nameEn);EditText price=numberField(String.valueOf(p.price));form.addView(ar);form.addView(en);form.addView(price);new AlertDialog.Builder(this).setTitle(t("تعديل الخدمة","Edit Service")).setView(form).setPositiveButton(t("حفظ","Save"),(d,w)->{try{db.updateProduct(p.id,ar.getText().toString(),en.getText().toString(),Double.parseDouble(price.getText().toString()));LocalBackupManager.backup(this,db);showAdmin();}catch(Exception ex){toast(t("تأكد من البيانات","Check details"));}}).setNegativeButton(t("إلغاء","Cancel"),null).show();}

    private void changePin(){
        EditText f=pinField(t("PIN جديد من 4 أرقام","New 4-digit PIN"));new AlertDialog.Builder(this).setTitle(t("تغيير PIN المدير","Change Manager PIN")).setView(f).setPositiveButton(t("حفظ","Save"),(d,w)->{String x=f.getText().toString().trim();if(!x.matches("\\d{4}")){toast(t("يجب أن يكون 4 أرقام","Must be 4 digits"));return;}try{db.updateUserPin(currentUser.id,x);LocalBackupManager.backup(this,db);toast(t("تم تغيير الرمز","PIN changed"));}catch(Exception e){toast(t("هذا PIN مستخدم لحساب آخر","This PIN is used by another account"));}}).setNegativeButton(t("إلغاء","Cancel"),null).show();
    }

    private void showAuditLog(){
        if(!require(isManager()))return;
        baseScreen(false);LinearLayout box=stack(contentScroll());box.addView(heading(t("سجل العمليات","Activity log")));
        box.addView(text(t("يبدأ تسجيل العمليات من هذا التحديث. لا يمكن تعديل السجل من البرنامج.","Activity recording starts with this update. Entries cannot be edited in the app."),14,Color.GRAY));
        final long[] range={DBHelper.startOfToday(),DBHelper.startOfTomorrow()};final int[] offset={0};
        Button from=menuButton(""),to=menuButton(""),apply=primaryButton(t("عرض السجل","Show log"));box.addView(from);box.addView(to);box.addView(apply);
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);box.addView(body);
        LinearLayout paging=new LinearLayout(this);Button prev=smallButton(t("السابق","Previous")),next=smallButton(t("التالي","Next"));paging.addView(prev,new LinearLayout.LayoutParams(0,dp(52),1));paging.addView(next,new LinearLayout.LayoutParams(0,dp(52),1));box.addView(paging);
        Runnable labels=()->{from.setText(t("من: ","From: ")+formatDateTime(range[0]));to.setText(t("إلى: ","To: ")+formatDateTime(range[1]-1));};labels.run();
        final Runnable[] render={null};render[0]=()->{
            if(!require(isManager()))return;body.removeAllViews();
            List<DBHelper.AuditEntry> rows=db.getAuditEntries(currentUser.id,range[0],range[1],offset[0]);
            prev.setEnabled(offset[0]>0);next.setEnabled(rows.size()==100);
            if(rows.isEmpty())body.addView(text(t("لا توجد عمليات في هذه الفترة","No activity in this period"),16,GRAY));
            for(DBHelper.AuditEntry entry:rows){
                LinearLayout card=card();card.setOrientation(LinearLayout.VERTICAL);
                String action="discount".equals(entry.action)?t("خصم / تعديل خصم","Discount / adjustment"):"refund".equals(entry.action)?t("مرتجع","Refund"):"cancel".equals(entry.action)?t("إلغاء فاتورة التحضير","Pending cancellation"):t("استرجاع نسخة احتياطية","Backup restored");
                card.addView(sectionTitle(action));card.addView(text(t("المستخدم: ","User: ")+entry.actor,17,GRAY));card.addView(text(formatDateTime(entry.time),15,GRAY));
                if(entry.saleId>0){card.addView(text(entry.invoiceNo>0?t("الفاتورة: ","Invoice: ")+entry.day+" / #"+entry.invoiceNo:t("طلب التحضير: #","Pending order: #")+entry.saleId,15,GRAY));card.addView(text(t("اللوحة: ","Plate: ")+(entry.plate==null?"-":entry.plate),15,GRAY));card.addView(text(t("المبلغ قبل: ","Amount before: ")+money(entry.before)+t(" — بعد: "," — after: ")+money(entry.after),15,GRAY));}
                card.addView(text(t("السبب: ","Reason: ")+entry.reason,15,GRAY));body.addView(card);
            }
        };
        from.setOnClickListener(v->pickDateTime(range[0],time->{range[0]=time;labels.run();}));to.setOnClickListener(v->pickDateTime(range[1]-60_000,time->{range[1]=time+60_000;labels.run();}));
        apply.setOnClickListener(v->{if(range[1]<=range[0]){toast(t("تأكد من الفترة","Check the date range"));return;}offset[0]=0;render[0].run();});
        prev.setOnClickListener(v->{offset[0]=Math.max(0,offset[0]-100);render[0].run();});next.setOnClickListener(v->{offset[0]+=100;render[0].run();});render[0].run();
    }

    private void showBackupScreen(){
        if(!require(isManager()))return;
        baseScreen(false);LinearLayout box=stack(contentScroll());box.addView(heading(t("النسخ الاحتياطي والاسترجاع","Backup & Restore")));
        box.addView(text(t("تشمل النسخة المنتجات والإضافات والعمال والفواتير والحسابات والصلاحيات وسجل العمليات ولغة البرنامج. احفظها في مكان آمن خارج التطبيق.","Includes products, extras, workers, invoices, accounts, permissions, activity log and app language. Keep a copy in a safe location outside the app."),16,GRAY));
        Button save=primaryButton(t("حفظ نسخة احتياطية","Save backup"));box.addView(save);save.setOnClickListener(v->{
            Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");intent.putExtra(Intent.EXTRA_TITLE,LocalBackupManager.filename());
            try{startActivityForResult(intent,SAVE_BACKUP);}catch(Exception e){toast(t("لا يوجد تطبيق لاختيار الملفات","No file picker is available"));}
        });
        Button restore=menuButton(t("استرجاع نسخة من ملف","Restore from file"));box.addView(restore);restore.setOnClickListener(v->{
            Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("*/*");
            try{startActivityForResult(intent,OPEN_BACKUP);}catch(Exception e){toast(t("لا يوجد تطبيق لاختيار الملفات","No file picker is available"));}
        });
        Button local=menuButton(t("استرجاع نسخة محلية تلقائية","Restore an automatic local backup"));box.addView(local);local.setOnClickListener(v->chooseLocalBackup());
        box.addView(text(t("الاسترجاع يستبدل البيانات الحالية ببيانات النسخة، ويحفظ نسخة أمان قبل الاسترجاع. بعدها تسجل الدخول برمز الحساب الموجود في النسخة.","Restore replaces current data with the backup and saves a safety copy first. Afterwards, sign in using an account PIN from that backup."),15,GRAY));
    }

    private interface BackupJob{Object run(DBHelper database)throws Exception;}
    private interface BackupDone{void run(Object result);}
    private boolean backupBusy=false;
    private void runBackupJob(BackupJob job,BackupDone done){
        if(backupBusy||!require(isManager()))return;backupBusy=true;
        final long actorId=currentUser.id;
        android.app.ProgressDialog progress=new android.app.ProgressDialog(this);progress.setMessage(t("جارٍ تنفيذ العملية…","Working…"));progress.setCancelable(false);progress.show();
        new Thread(()->{
            Object result=null;Exception failure=null;
            try(DBHelper database=new DBHelper(getApplicationContext())){
                DBHelper.AppUser actor=database.getAppUser(actorId);if(actor==null||!actor.active||!actor.isManager())throw new SecurityException("Manager required");
                result=job.run(database);
            }catch(Exception error){failure=error;}
            final Object value=result;final Exception error=failure;
            runOnUiThread(()->{backupBusy=false;if(isFinishing()||isDestroyed())return;progress.dismiss();if(error!=null){android.util.Log.w("NouraBackup","Backup operation failed",error);new AlertDialog.Builder(this).setMessage(t("تعذرت العملية. تأكد من صلاحية الملف والمساحة المتاحة. لم يتم اعتماد استرجاع غير صالح.","Operation failed. Check the backup file and free space. An invalid restore is not committed.")).setPositiveButton(t("حسناً","OK"),null).show();}else done.run(value);});
        },"noura-backup").start();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if((requestCode!=SAVE_BACKUP&&requestCode!=OPEN_BACKUP)||resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        if(!require(isManager()))return;Uri uri=data.getData();
        if(requestCode==SAVE_BACKUP)runBackupJob(database->{LocalBackupManager.saveTo(getApplicationContext(),database,uri);return null;},value->toast(t("تم حفظ النسخة الاحتياطية","Backup saved")));
        else readBackup(uri);
    }

    private void chooseLocalBackup(){
        if(!require(isManager()))return;
        List<File> files=new ArrayList<>();
        for(String folder:new String[]{"restore-safety","backups"}){File[] found=new File(getFilesDir(),folder).listFiles((dir,name)->name.endsWith(".json"));if(found!=null)java.util.Collections.addAll(files,found);}
        java.util.Collections.sort(files,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
        if(files.isEmpty()){toast(t("لا توجد نسخ محلية","No local backups"));return;}
        String[] labels=new String[files.size()];for(int i=0;i<files.size();i++){File file=files.get(i);labels[i]=formatDateTime(file.lastModified())+(file.getParentFile().getName().equals("restore-safety")?t(" • قبل الاسترجاع"," • before restore"):"");}
        new AlertDialog.Builder(this).setTitle(t("اختر نسخة للاسترجاع","Choose a backup")).setItems(labels,(d,i)->readBackup(Uri.fromFile(files.get(i)))).setNegativeButton(t("رجوع","Back"),null).show();
    }

    private void readBackup(Uri uri){
        runBackupJob(database->LocalBackupManager.read(getApplicationContext(),uri,database),value->{
            JSONObject backup=(JSONObject)value;
            String summary=t("تاريخ النسخة: ","Backup date: ")+formatDateTime(backup.optLong("exported_at"))+"\n"+t("الفواتير: ","Invoices: ")+backup.optJSONArray("sales").length()+"\n"+t("أنواع الغسيل: ","Wash types: ")+backup.optJSONArray("wash_types").length()+"\n"+t("الإضافات: ","Extras: ")+backup.optJSONArray("products").length()+"\n\n"+t("سيتم استبدال البيانات الحالية وحفظ نسخة أمان قبل الاسترجاع. تحتاج رمز الدخول الموجود في النسخة.","Current data will be replaced after a safety copy is saved. You will need a login PIN from the backup.");
            new AlertDialog.Builder(this).setTitle(t("تأكيد استرجاع النسخة","Confirm restore")).setMessage(summary).setNegativeButton(t("إلغاء","Cancel"),null).setPositiveButton(t("استرجاع","Restore"),(d,w)->{
                final long actorId=currentUser.id;
                runBackupJob(database->{
                    LocalBackupManager.snapshot(getApplicationContext(),database,true);
                    // Invalidate the old session before swapping account IDs, including process death.
                    if(!prefs.edit().remove("session_user_id").remove("admin_pin").commit())throw new java.io.IOException("Cannot clear old session");
                    database.restoreBackup(backup,actorId);
                    boolean language=backup.getJSONObject("settings").getBoolean("arabic");
                    prefs.edit().putBoolean("arabic",language).commit();return language;
                },restored->{
                    arabic=(Boolean)restored;currentUser=null;toast(t("تم الاسترجاع. سجل الدخول برمز النسخة.","Restored. Sign in with the backup's PIN."));showLogin();
                });
            }).show();
        });
    }

    private String paymentLabel(String method){if("Cash".equals(method))return t("نقدي","Cash");if("Card".equals(method))return t("شبكة","Card");if("Split".equals(method))return t("كاش + شبكة","Cash + Card");return method==null?"-":method;}
    private String money(double v){return String.format(Locale.US,"%.0f SAR",v);}
    private String formatTime(long v){return new SimpleDateFormat("HH:mm",Locale.US).format(new Date(v));}
    private String formatDateTime(long v){return v<=0?"-":new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date(v));}
    private String durationText(long ms){long totalMinutes=Math.max(0,ms/60_000L),h=totalMinutes/60,m=totalMinutes%60;if(h>0)return h+t(" س "," h ")+m+t(" د"," m");return m+t(" دقيقة"," min");}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    private TextView heading(String s){TextView v=text(s,25,GRAY);v.setTypeface(Typeface.DEFAULT_BOLD);v.setGravity(arabic?Gravity.RIGHT:Gravity.LEFT);v.setPadding(dp(4),dp(12),dp(4),dp(8));return v;}
    private TextView sectionTitle(String s){TextView v=text(s,18,GRAY);v.setTypeface(Typeface.DEFAULT_BOLD);v.setGravity(arabic?Gravity.RIGHT:Gravity.LEFT);v.setPadding(dp(4),dp(22),dp(4),dp(8));return v;}
    private TextView text(String s,int sp,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(color);return v;}
    private EditText field(String hint,boolean phone){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(17);e.setSingleLine(true);e.setPadding(dp(14),0,dp(14),0);e.setInputType(phone?InputType.TYPE_CLASS_PHONE:InputType.TYPE_CLASS_TEXT);e.setBackground(round(Color.WHITE,Color.LTGRAY,12));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(56));p.setMargins(0,dp(5),0,dp(5));e.setLayoutParams(p);return e;}
    private EditText plateField(){EditText e=field(t("رقم اللوحة *","Plate number *"),false);e.setInputType(InputType.TYPE_CLASS_NUMBER);e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4)});e.setImeOptions(EditorInfo.IME_ACTION_NEXT);return e;}
    private EditText pinField(String hint){EditText e=field(hint,false);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4)});e.setImeOptions(EditorInfo.IME_ACTION_DONE);return e;}
    private EditText numberField(String value){EditText e=field(t("السعر","Price"),false);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);e.setText(value);return e;}
    private RadioButton radio(String s){RadioButton r=new RadioButton(this);r.setText(s);r.setTextSize(17);r.setPadding(dp(8),0,dp(8),0);return r;}
    private Button primaryButton(String s){Button b=new Button(this);b.setBackgroundTintList(null);b.setText(s);b.setTextSize(17);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT_BOLD);b.setBackground(round(RED,RED,14));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(58));p.setMargins(0,dp(6),0,dp(6));b.setLayoutParams(p);return b;}
    private Button menuButton(String s){Button b=new Button(this);b.setBackgroundTintList(null);b.setText(s);b.setTextSize(18);b.setGravity(arabic?Gravity.RIGHT|Gravity.CENTER_VERTICAL:Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setPadding(dp(18),0,dp(18),0);b.setTextColor(GRAY);b.setAllCaps(false);b.setBackground(round(SMOKE,Color.LTGRAY,16));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(72));p.setMargins(0,dp(6),0,dp(6));b.setLayoutParams(p);return b;}
    private Button smallButton(String s){Button b=new Button(this);b.setBackgroundTintList(null);b.setText(s);b.setTextSize(14);b.setAllCaps(false);b.setTextColor(GRAY);b.setBackground(round(SMOKE,Color.LTGRAY,12));return b;}
    private LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setPadding(dp(12),dp(7),dp(12),dp(7));l.setBackground(round(SMOKE,Color.LTGRAY,14));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);p.setMargins(0,dp(4),0,dp(4));l.setLayoutParams(p);return l;}
    private LinearLayout summaryCard(String title,String value,String subtitle){LinearLayout c=card();c.setOrientation(LinearLayout.VERTICAL);TextView t=text(title,15,Color.GRAY),v=text(value,24,GRAY),s=text(subtitle,14,Color.GRAY);v.setTypeface(Typeface.DEFAULT_BOLD);c.addView(t);c.addView(v);c.addView(s);return c;}
    private GradientDrawable round(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
}