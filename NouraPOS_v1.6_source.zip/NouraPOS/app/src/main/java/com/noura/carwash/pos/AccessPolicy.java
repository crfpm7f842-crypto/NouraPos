package com.noura.carwash.pos;

import java.util.Calendar;

/** One range policy shared by on-screen reports and every PDF action. */
public final class AccessPolicy {
    private AccessPolicy() { }

    public static long[] reportRange(boolean manager,long start,long end,long now) {
        if(manager) {
            if(end<=start)throw new IllegalArgumentException("Invalid report range");
            return new long[]{start,end};
        }
        Calendar day=Calendar.getInstance();day.setTimeInMillis(now);
        day.set(Calendar.HOUR_OF_DAY,0);day.set(Calendar.MINUTE,0);
        day.set(Calendar.SECOND,0);day.set(Calendar.MILLISECOND,0);
        long today=day.getTimeInMillis();day.add(Calendar.DATE,1);
        return new long[]{today,day.getTimeInMillis()};
    }
}
