package com.noura.carwash.pos;

import android.content.Context;
import android.net.Uri;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public class LocalBackupManager {
    private static final long MAX_BYTES=32L*1024*1024;

    public static String export(Context context,DBHelper db)throws Exception{
        JSONObject root=new JSONObject(db.exportAllJson());
        JSONObject settings=new JSONObject();
        settings.put("arabic",context.getSharedPreferences("noura_settings",Context.MODE_PRIVATE).getBoolean("arabic",true));
        root.put("settings",settings);
        String json=root.toString();
        if(json.getBytes(StandardCharsets.UTF_8).length>MAX_BYTES)throw new IOException("Backup too large");
        return json;
    }

    public static String filename(){return "Noura_Backup_"+new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss",Locale.US).format(new Date())+".json";}

    public static File snapshot(Context context,DBHelper db,boolean beforeRestore)throws Exception{
        File dir=new File(context.getFilesDir(),beforeRestore?"restore-safety":"backups");
        if(!dir.isDirectory()&&!dir.mkdirs())throw new IOException("Cannot create backup folder");
        File temp=File.createTempFile("noura-",".tmp",dir);
        try{
            byte[] data=export(context,db).getBytes(StandardCharsets.UTF_8);
            try(FileOutputStream out=new FileOutputStream(temp)){out.write(data);out.flush();out.getFD().sync();}
            File file=new File(dir,filename().replace(".json","-"+System.nanoTime()+".json"));
            if(!temp.renameTo(file))throw new IOException("Cannot finish backup");
            return file;
        }finally{if(temp.exists())temp.delete();}
    }

    public static void backup(Context context,DBHelper db){
        try{
            snapshot(context,db,false);
            File[] files=new File(context.getFilesDir(),"backups").listFiles((dir,name)->name.endsWith(".json"));
            if(files!=null&&files.length>30){Arrays.sort(files,Comparator.comparingLong(File::lastModified));for(int i=0;i<files.length-30;i++)files[i].delete();}
        }catch(Exception error){android.util.Log.w("NouraBackup","Automatic backup failed",error);}
    }

    public static void saveTo(Context context,DBHelper db,Uri destination)throws Exception{
        byte[] bytes=export(context,db).getBytes(StandardCharsets.UTF_8);
        try(OutputStream out=context.getContentResolver().openOutputStream(destination,"wt")){
            if(out==null)throw new IOException("Cannot open destination");out.write(bytes);out.flush();
        }
    }

    public static JSONObject read(Context context,Uri source,DBHelper db)throws Exception{
        try(InputStream in=context.getContentResolver().openInputStream(source)){
            if(in==null)throw new IOException("Cannot open backup");
            ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int count;
            while((count=in.read(buffer))!=-1){if(out.size()+(long)count>MAX_BYTES)throw new IOException("Backup too large");out.write(buffer,0,count);}
            JSONObject backup=new JSONObject(new String(out.toByteArray(),StandardCharsets.UTF_8));db.validateBackup(backup);return backup;
        }
    }
}
